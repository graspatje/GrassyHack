# Closes Geometry Dash normally (so it saves), installs the latest build of
# GrassyHack and starts GD again with its window in front. Usage: .\tools\restart-gd.ps1
$ErrorActionPreference = "Stop"

$gdDir = "C:\Program Files (x86)\Steam\steamapps\common\Geometry Dash"
$mod = Join-Path $PSScriptRoot "..\out\graspatje.grassyhack.geode"

$running = Get-Process GeometryDash -ErrorAction SilentlyContinue
if ($running) {
    # A normal close, like clicking the X, so GD saves first
    $running | ForEach-Object { $_.CloseMainWindow() | Out-Null }
    $running | Wait-Process -Timeout 30 -ErrorAction SilentlyContinue
    if (Get-Process GeometryDash -ErrorAction SilentlyContinue) { throw "Geometry Dash didn't close" }
}

Copy-Item $mod (Join-Path $gdDir "geode\mods") -Force
Start-Process -FilePath (Join-Path $gdDir "GeometryDash.exe") -WorkingDirectory $gdDir

Add-Type @'
using System; using System.Runtime.InteropServices;
public static class GdWindow {
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
}
'@
$window = $null
for ($i = 0; $i -lt 60 -and -not $window; $i++) {
    Start-Sleep -Milliseconds 500
    $window = Get-Process GeometryDash -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1
}
if (-not $window) { throw "Geometry Dash didn't open a window" }
# Give it time to load before it can take focus
Start-Sleep -Seconds 8
[GdWindow]::ShowWindow($window.MainWindowHandle, 9) | Out-Null
[GdWindow]::SetForegroundWindow($window.MainWindowHandle) | Out-Null
"Geometry Dash restarted (process $($window.Id))"
