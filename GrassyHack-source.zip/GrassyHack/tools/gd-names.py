# Turns GeometryDash.exe offsets from the bot's profiler into function names,
# using the Windows addresses in Geode's bindings. Usage: gd-names.py 0x243970 ...
import os, re, sys, bisect

BINDINGS = os.path.join(os.environ["LOCALAPPDATA"], "practice-tools-build", "_deps", "bindings-src", "bindings", "2.2081")

functions = []
for file in ("GeometryDash.bro",):
    current = None
    for line in open(os.path.join(BINDINGS, file), encoding="utf-8"):
        match = re.match(r"^class (\S+)", line)
        if match:
            current = match.group(1)
            continue
        match = re.search(r"([\w~]+)\(.*?win (0x[0-9a-f]+)", line)
        if match and current:
            functions.append((int(match.group(2), 16), f"{current}::{match.group(1)}"))
functions.sort()
starts = [address for address, _ in functions]

for arg in sys.argv[1:]:
    address = int(arg, 16)
    i = bisect.bisect_right(starts, address) - 1
    if i < 0:
        print(f"{arg}: before the first known function")
        continue
    start, name = functions[i]
    print(f"{arg}: {name}" + (f" +0x{address - start:x}" if address != start else ""))
