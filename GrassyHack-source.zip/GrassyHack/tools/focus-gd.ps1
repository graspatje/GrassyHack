# Brings the running Geometry Dash window to the front (restoring it if minimized)
Add-Type @'
using System; using System.Runtime.InteropServices;
public static class GdFocus {
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
}
'@
$window = Get-Process GeometryDash -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1
if (-not $window) { throw "Geometry Dash isn't running" }
if ([GdFocus]::IsIconic($window.MainWindowHandle)) { [GdFocus]::ShowWindow($window.MainWindowHandle, 9) | Out-Null }
[GdFocus]::SetForegroundWindow($window.MainWindowHandle) | Out-Null
