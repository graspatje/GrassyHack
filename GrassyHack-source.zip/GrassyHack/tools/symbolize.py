# Puts GD function names next to the addresses in the bot's profiler output,
# using the address list Geode's bindings come with. Developer tool.
# Usage: python tools/symbolize.py [log file]  (default: GD's newest Geode log)
import bisect
import glob
import os
import re
import struct
import sys

CODEGEN = os.path.join(os.environ["LOCALAPPDATA"], "grassyhack-build", "bindings", "bindings", "Geode", "CodegenData.txt")
GD = r"C:\Program Files (x86)\Steam\steamapps\common\Geometry Dash"
LOGS = os.path.join(GD, "geode", "logs")


def demangle(name):
    # Just enough of MSVC's scheme for "?update@CCScheduler@cocos2d@@UEAAXM@Z"
    match = re.match(r"\?(\?[0-9A-Z_]|[^@?]+)@((?:[^@?]+@)*)@", name)
    if not match:
        return name
    scopes = [part for part in match.group(2).split("@") if part][::-1]
    special = {"?0": scopes[-1] if scopes else "ctor", "?1": "~" + (scopes[-1] if scopes else "dtor")}
    return "::".join(scopes + [special.get(match.group(1), match.group(1))])


def exports(path):
    # The DLL's export table: function offset -> name
    data = open(path, "rb").read()
    pe = struct.unpack_from("<I", data, 0x3C)[0]
    sections = struct.unpack_from("<H", data, pe + 6)[0]
    optional = pe + 24
    first_section = optional + struct.unpack_from("<H", data, pe + 20)[0]
    export_rva = struct.unpack_from("<I", data, optional + 112)[0]

    def offset(rva):
        for i in range(sections):
            entry = first_section + 40 * i
            size, address, _, raw = struct.unpack_from("<IIII", data, entry + 8)
            if address <= rva < address + max(size, 1):
                return rva - address + raw
        raise ValueError(rva)

    directory = offset(export_rva)
    count, name_count, functions, names, ordinals = struct.unpack_from("<IIIII", data, directory + 20)
    result = {}
    for i in range(name_count):
        name_at = offset(struct.unpack_from("<I", data, offset(names) + 4 * i)[0])
        name = data[name_at:data.index(b"\0", name_at)].decode()
        ordinal = struct.unpack_from("<H", data, offset(ordinals) + 2 * i)[0]
        result.setdefault(struct.unpack_from("<I", data, offset(functions) + 4 * ordinal)[0], demangle(name))
    return result


def load_names():
    modules = {"GeometryDash.exe": {}, "libcocos2d.dll": exports(os.path.join(GD, "libcocos2d.dll"))}
    for line in open(CODEGEN, encoding="utf-8"):
        match = re.match(r"(\S+) - 0x([0-9a-f]+)$", line.strip())
        if not match:
            continue
        name, address = match.group(1), int(match.group(2), 16)
        module = "libcocos2d.dll" if name.startswith("cocos2d::") else "GeometryDash.exe"
        modules[module].setdefault(address, name)
    return {module: (sorted(names), names) for module, names in modules.items()}


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else max(glob.glob(os.path.join(LOGS, "*.log")), key=os.path.getmtime)
    names = load_names()

    def name_of(match):
        module, address = match.group(1), int(match.group(2), 16)
        starts, table = names[module]
        if address in table:
            return f"{match.group(0)} {table[address]}"
        # Not a function the bindings know; the nearest one before it is a hint at best
        i = bisect.bisect_right(starts, address) - 1
        if i >= 0 and address - starts[i] < 0x2000:
            return f"{match.group(0)} (after {table[starts[i]]}+0x{address - starts[i]:x}?)"
        return match.group(0)

    for line in open(path, encoding="utf-8", errors="replace"):
        print(re.sub(r"(GeometryDash\.exe|libcocos2d\.dll)\+0x([0-9a-f]+)", name_of, line.rstrip()))


main()
