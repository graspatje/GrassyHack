@echo off
setlocal
set "PY=python"
%PY% --version >nul 2>&1
if errorlevel 1 (
    echo Python isn't installed. Installing it now...
    winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
    set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
)
"%PY%" --version >nul 2>&1
if errorlevel 1 (
    echo Couldn't install Python. Get it from https://www.python.org/downloads/ and run this again.
    pause
    exit /b 1
)
"%PY%" "%~dp0tools\to-megahack.py"
pause
