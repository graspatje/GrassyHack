#include "Rulesets.hpp"
#include "Config.hpp"

#include <algorithm>

using namespace geode::prelude;

namespace {
    using namespace grassy::rulesets;

    std::vector<CheatInfo> const kCheats = {
        { Noclip, "noclip", "Noclip" },
        { Speedhack, "speedhack", "Speedhack (any speed but 1x)" },
        { FrameStepper, "stepper", "Frame Stepper" },
        { AutoBot, "bot", "Auto Bot" },
        { StartPos, "startpos", "Starting from a start position" },
        { Respawn, "respawn", "Instant respawn or a custom respawn time" },
        { MacroPlayback, "macro", "Playing a macro" },
        { AutoClicker, "autoclicker", "Auto Clicker" },
        { JumpHack, "jump-hack", "Jump Hack" },
        { InstantComplete, "instant-complete", "Instant Complete" },
        { Platformer, "platformer", "Force Platformer" },
        { Tps, "tps", "TPS Bypass (any TPS but 240)" },
        { Hitboxes, "hitboxes", "Show Hitboxes (always on)" },
        { Trajectory, "trajectory", "Show Trajectory" },
        { ShowLayout, "layout", "Show Layout" },
        { NoMirror, "no-mirror", "No Mirror" },
    };

    std::vector<Ruleset> s_rulesets;
    bool s_loaded = false;

    void load() {
        if (s_loaded) return;
        s_loaded = true;
        // GD: anything that plays the level for you or makes it easier. Start
        // positions are GD's own, and it already doesn't save runs from them.
        // Pointercrate: the same, and records have to start from 0%, without
        // hitboxes, the trajectory, the layout or no mirror. It allows a
        // faster reset ("Fast Reset" in its list of allowed hacks).
        uint32_t gameplay = Noclip | Speedhack | FrameStepper | AutoBot | MacroPlayback | AutoClicker | JumpHack |
            InstantComplete | Platformer | Tps;
        s_rulesets = {
            { "GD", gameplay, true },
            { "Pointercrate", gameplay | StartPos | Hitboxes | Trajectory | ShowLayout | NoMirror, true },
        };

        auto saved = Mod::get()->getSavedValue<matjson::Value>("rulesets");
        if (!saved.isArray()) return;
        for (auto const& entry : saved) {
            Ruleset ruleset;
            ruleset.name = entry["name"].asString().unwrapOr("Custom");
            auto const& banned = entry["banned"];
            for (size_t i = 0; banned.isArray() && i < banned.size(); i++) {
                auto text = banned[i].asString().unwrapOr("");
                for (auto const& info : kCheats) {
                    if (text == info.id) ruleset.banned |= info.cheat;
                }
            }
            s_rulesets.push_back(std::move(ruleset));
        }
    }
}

namespace grassy::rulesets {
    std::vector<CheatInfo> const& cheats() {
        return kCheats;
    }

    std::vector<Ruleset>& all() {
        load();
        return s_rulesets;
    }

    int selectedIndex() {
        auto count = static_cast<int64_t>(all().size());
        return static_cast<int>(std::clamp<int64_t>(config::getInt("cheat-indicator.ruleset"), 0, count - 1));
    }

    Ruleset const& selected() {
        return all()[selectedIndex()];
    }

    void select(int index) {
        config::setInt("cheat-indicator.ruleset", index);
    }

    void addCustom() {
        auto& rulesets = all();
        int number = 1;
        auto taken = [&](std::string const& name) {
            return std::any_of(rulesets.begin(), rulesets.end(), [&](Ruleset const& r) { return r.name == name; });
        };
        while (taken(fmt::format("Custom {}", number))) number++;
        rulesets.push_back({ fmt::format("Custom {}", number), selected().banned, false });
        select(static_cast<int>(rulesets.size()) - 1);
        save();
    }

    void removeSelected() {
        auto& rulesets = all();
        int index = selectedIndex();
        if (rulesets[index].builtIn) return;
        rulesets.erase(rulesets.begin() + index);
        select(index - 1);
        save();
    }

    void save() {
        auto custom = matjson::Value::array();
        for (auto const& ruleset : all()) {
            if (ruleset.builtIn) continue;
            auto banned = matjson::Value::array();
            for (auto const& info : kCheats) {
                if (ruleset.banned & info.cheat) banned.push(info.id);
            }
            custom.push(matjson::makeObject({ { "name", ruleset.name }, { "banned", banned } }));
        }
        Mod::get()->setSavedValue("rulesets", custom);
    }
}
