#pragma once

#include <Geode/Geode.hpp>

#include <string>
#include <vector>

// A ruleset says which hacks count as cheating for the cheat indicator. GD and
// Pointercrate are built in, custom ones are kept with the options.
namespace grassy::rulesets {
    // Everything a ruleset can allow or ban, as bits
    enum Cheat : uint32_t {
        Noclip = 1 << 0,
        Speedhack = 1 << 1,
        FrameStepper = 1 << 2,
        AutoBot = 1 << 3,
        StartPos = 1 << 4,
        Respawn = 1 << 5,
        MacroPlayback = 1 << 6,
        AutoClicker = 1 << 7,
        JumpHack = 1 << 8,
        InstantComplete = 1 << 9,
        Platformer = 1 << 10,
        Tps = 1 << 11,
        Hitboxes = 1 << 12,
        Trajectory = 1 << 13,
        ShowLayout = 1 << 14,
        NoMirror = 1 << 15,
    };

    struct CheatInfo {
        Cheat cheat;
        // How it's kept in the save, so the bits can change
        char const* id;
        char const* name;
    };

    std::vector<CheatInfo> const& cheats();

    struct Ruleset {
        std::string name;
        uint32_t banned = 0;
        bool builtIn = false;
    };

    // The built-in ones come first
    std::vector<Ruleset>& all();
    // The one the cheat indicator uses
    int selectedIndex();
    Ruleset const& selected();
    void select(int index);
    // Adds a custom ruleset copied from the selected one and selects it
    void addCustom();
    void removeSelected();
    // Saves the custom rulesets after one was changed
    void save();
}
