#include "Player.hpp"
#include "../Config.hpp"
#include "../Hacks.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/ui/Notification.hpp>

#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <unordered_map>

using namespace geode::prelude;
using namespace grassy;

// Inputs go in and out at the start of each physics tick. Ticks are counted
// from the start of the attempt in GJBaseGameLayer::processCommands, which GD
// runs once per tick. Respawning at a practice checkpoint goes back to the
// tick the checkpoint was made at: a recording forgets what came after, and
// playback picks up from there.

namespace {
    using macro::Input;
    using macro::Macro;
    using macro::State;

    constexpr double kTicksPerSecond = 240.0;

    State s_state = State::Off;
    // Ticks started this attempt. While a tick runs, it's one past that tick.
    uint64_t s_ticks = 0;
    bool s_inTick = false;
    // Set while the macro presses buttons, so that isn't recorded or blocked
    bool s_macroPressing = false;
    std::unordered_map<CheckpointObject*, uint64_t> s_checkpointTicks;
    bool s_loadedCheckpoint = false;

    Macro s_recording;
    std::optional<macro::Loaded> s_loaded;
    // The opened macro in GD's ticks
    std::vector<Input> s_playInputs;
    size_t s_nextInput = 0;
    std::vector<macro::File> s_files;
    bool s_scanned = false;
    // With a debug.txt in the macros folder, every input is logged with where the player was
    bool s_debug = false;

    void logInput(char const* what, PlayLayer* pl, Input const& input) {
        if (!s_debug || !pl->m_player1) return;
        log::info("{} tick {} button {}{} {}: x {:.4f} y {:.4f}", what, input.frame, int(input.button), input.player2 ? " p2" : "",
            input.down ? "down" : "up", pl->m_player1->m_position.x, pl->m_player1->m_position.y);
    }

    void notify(std::string const& text, NotificationIcon icon = NotificationIcon::Info) {
        Notification::create(text, icon, 2.5f)->show();
    }

    bool twoPlayer(PlayLayer* pl) {
        return pl->m_levelSettings && pl->m_levelSettings->m_twoPlayerMode;
    }

    bool holding(PlayLayer* pl, bool player2, int button) {
        auto player = player2 ? pl->m_player2 : pl->m_player1;
        if (!player) return false;
        auto it = player->m_holdingButtons.find(button);
        return it != player->m_holdingButtons.end() && it->second;
    }

    void press(PlayLayer* pl, bool down, int button, bool player2) {
        s_macroPressing = true;
        pl->handleButton(down, button, !player2);
        s_macroPressing = false;
    }

    // Whether each button is held after the inputs before a tick, [player2][button]
    std::array<std::array<bool, 4>, 2> heldBefore(std::vector<Input> const& inputs, uint64_t tick) {
        std::array<std::array<bool, 4>, 2> held = {};
        for (auto const& input : inputs) {
            if (input.frame >= tick) break;
            held[input.player2][input.button] = input.down;
        }
        return held;
    }

    // Player 2's buttons only exist on their own in two-player levels
    template <class F>
    void forEachButton(PlayLayer* pl, F&& f) {
        for (bool player2 : { false, true }) {
            if (player2 && !twoPlayer(pl)) continue;
            for (int button = 1; button <= 3; button++) f(player2, button);
        }
    }

    // Playback

    void startPlayback(PlayLayer* pl) {
        s_nextInput = std::lower_bound(s_playInputs.begin(), s_playInputs.end(), s_ticks, [](Input const& input, uint64_t tick) {
            return input.frame < tick;
        }) - s_playInputs.begin();
        // Respawned partway: hold what the macro holds at this point
        auto held = heldBefore(s_playInputs, s_ticks);
        forEachButton(pl, [&](bool player2, int button) {
            if (holding(pl, player2, button) != held[player2][button]) press(pl, held[player2][button], button, player2);
        });
    }

    void playInputs(PlayLayer* pl, uint64_t tick) {
        while (s_nextInput < s_playInputs.size() && s_playInputs[s_nextInput].frame <= tick) {
            auto const& input = s_playInputs[s_nextInput++];
            if (input.player2 && !twoPlayer(pl)) continue;
            logInput("Played", pl, input);
            press(pl, input.down, input.button, input.player2);
        }
    }

    void preparePlayback() {
        s_playInputs.clear();
        if (!s_loaded) return;
        auto const& macro = s_loaded->macro;
        double scale = kTicksPerSecond / macro.fps;
        for (auto input : macro.inputs) {
            input.frame = static_cast<uint64_t>(std::llround(static_cast<double>(input.frame) * scale));
            s_playInputs.push_back(input);
        }
    }

    // Recording

    void record(Input input) {
        auto& inputs = s_recording.inputs;
        // Only changes matter
        bool current = false;
        for (auto it = inputs.rbegin(); it != inputs.rend(); ++it) {
            if (it->player2 == input.player2 && it->button == input.button) {
                current = it->down;
                break;
            }
        }
        if (current == input.down) return;
        inputs.push_back(input);
    }

    // After respawning: drop what came after this point, and note the buttons
    // that are held now but weren't then (or the other way round)
    void rewindRecording(PlayLayer* pl, uint64_t tick) {
        auto& inputs = s_recording.inputs;
        std::erase_if(inputs, [&](Input const& input) { return input.frame >= tick; });
        auto held = heldBefore(inputs, tick);
        forEachButton(pl, [&](bool player2, int button) {
            bool now = holding(pl, player2, button);
            if (now != held[player2][button]) inputs.push_back({ tick, static_cast<uint8_t>(button), player2, now });
        });
    }

    void beginRecording(PlayLayer* pl) {
        s_recording = {};
        s_recording.fps = kTicksPerSecond;
        if (pl && pl->m_level) {
            s_recording.levelName = pl->m_level->m_levelName;
            s_recording.levelID = static_cast<uint64_t>(std::max(0, pl->m_level->m_levelID.value()));
        }
    }

    macro::Format saveFormat() {
        auto value = static_cast<int>(config::getInt("macro.format"));
        for (auto const& format : macro::formats()) {
            if (static_cast<int>(format.format) == value && format.canWrite) return format.format;
        }
        return macro::Format::GDR;
    }

    std::string safeName(std::string name) {
        for (auto& c : name) {
            if (std::string_view("<>:\"/\\|?*").find(c) != std::string_view::npos || static_cast<unsigned char>(c) < 32) c = '_';
        }
        while (!name.empty() && (name.back() == ' ' || name.back() == '.')) name.pop_back();
        return name.empty() ? "macro" : name;
    }

    std::filesystem::path freePath(std::string const& name, macro::Format format) {
        auto extension = macro::info(format).extension;
        auto path = macro::folder() / (safeName(name) + extension);
        for (int number = 2; std::filesystem::exists(path); number++) {
            path = macro::folder() / (safeName(name) + " " + std::to_string(number) + extension);
        }
        return path;
    }

    // Tries every macro in the macros folder's "selftest" folder and writes
    // what came out to results.txt there. For testing the formats.
    void runSelfTest() {
        auto dir = macro::folder() / "selftest";
        std::error_code error;
        if (!std::filesystem::is_directory(dir, error)) return;
        std::ofstream out(dir / "results.txt", std::ios::trunc);
        for (auto const& entry : std::filesystem::directory_iterator(dir, error)) {
            if (!entry.is_regular_file() || entry.path().filename() == "results.txt") continue;
            macro::Format format;
            auto result = macro::load(entry.path(), &format);
            out << "== " << entry.path().filename().string() << "\n";
            if (!result) {
                out << "couldn't read: " << result.unwrapErr() << "\n";
                continue;
            }
            auto const& macro = result.unwrap();
            out << macro::info(format).name << ", " << macro.inputs.size() << " inputs, " << macro.fps << " fps, "
                << macro.seconds() << " s, level \"" << macro.levelName << "\", bot \"" << macro.botName << "\"\n";
            for (size_t i = 0; i < std::min<size_t>(macro.inputs.size(), 6); i++) {
                auto const& input = macro.inputs[i];
                out << "  frame " << input.frame << " button " << int(input.button) << (input.player2 ? " p2" : " p1")
                    << (input.down ? " down" : " up") << "\n";
            }
            for (auto const& line : macro::roundTrip(macro)) out << "  " << line << "\n";
        }
    }
}

namespace grassy::macro {
    State state() {
        return s_state;
    }

    void setState(State next) {
        if (next == s_state) return;
        auto pl = PlayLayer::get();
        if (next != State::Off && bot::isRunning()) {
            notify("Stop the bot first", NotificationIcon::Warning);
            return;
        }
        if (next == State::Playing && !s_loaded) {
            notify("Pick a macro to play first", NotificationIcon::Warning);
            return;
        }
        // Let go of whatever the macro was holding
        if (s_state == State::Playing && pl) {
            forEachButton(pl, [&](bool player2, int button) {
                if (holding(pl, player2, button)) press(pl, false, button, player2);
            });
        }
        s_state = next;
        if (next == State::Recording) {
            beginRecording(pl);
            notify(pl ? "Recording from the start of the level" : "Recording starts in the next level");
            if (pl) pl->resetLevelFromStart();
        }
        else if (next == State::Playing) {
            notify(pl ? "Playing " + stem(s_loaded->path) : "The macro plays in the next level");
            if (pl) pl->resetLevelFromStart();
        }
        startpos::refresh();
    }

    Loaded const* loaded() {
        return s_loaded ? &*s_loaded : nullptr;
    }

    geode::Result<> open(std::filesystem::path const& path) {
        Format format;
        auto result = load(path, &format);
        if (!result) return geode::Err(result.unwrapErr());
        s_loaded = Loaded{ std::move(result.unwrap()), path, format };
        preparePlayback();
        // Playing something else now: start it over
        if (s_state == State::Playing) {
            if (auto pl = PlayLayer::get()) pl->resetLevelFromStart();
        }
        return geode::Ok();
    }

    Macro const& recording() {
        return s_recording;
    }

    geode::Result<std::filesystem::path> saveRecording(std::string const& name, Format format) {
        if (s_recording.inputs.empty()) return geode::Err("Nothing has been recorded yet");
        std::error_code error;
        std::filesystem::create_directories(folder(), error);
        auto path = freePath(name, format);
        if (auto result = save(s_recording, format, path); !result) return geode::Err(result.unwrapErr());
        s_scanned = false;
        return geode::Ok(path);
    }

    geode::Result<std::filesystem::path> convertLoaded(Format format) {
        if (!s_loaded) return geode::Err("Pick a macro first");
        std::error_code error;
        std::filesystem::create_directories(folder(), error);
        auto path = freePath(stem(s_loaded->path), format);
        if (auto result = save(s_loaded->macro, format, path); !result) return geode::Err(result.unwrapErr());
        s_scanned = false;
        return geode::Ok(path);
    }

    std::filesystem::path folder() {
        return Mod::get()->getSaveDir() / "macros";
    }

    std::vector<File> const& files(bool rescan) {
        if (s_scanned && !rescan) return s_files;
        s_scanned = true;
        s_files.clear();
        std::error_code error;
        std::filesystem::create_directories(folder(), error);
        std::vector<std::pair<std::filesystem::file_time_type, File>> found;
        for (auto const& entry : std::filesystem::directory_iterator(folder(), error)) {
            if (!entry.is_regular_file(error)) continue;
            auto name = entry.path().filename().string();
            std::string lowered = name;
            std::transform(lowered.begin(), lowered.end(), lowered.begin(), [](unsigned char c) { return std::tolower(c); });
            // The longest matching ending names the format
            FormatInfo const* match = nullptr;
            for (auto const& format : formats()) {
                std::string_view extension = format.extension;
                if (lowered.size() > extension.size() && lowered.ends_with(extension) &&
                        (!match || extension.size() > std::string_view(match->extension).size())) {
                    match = &format;
                }
            }
            if (!match) continue;
            // Many kinds of files end in these, what's inside tells them apart
            std::string formatName = match->name;
            if (match->format == Format::TASBot) formatName = "JSON";
            found.push_back({ entry.last_write_time(error), File{ entry.path(), stem(entry.path()), formatName } });
        }
        std::sort(found.begin(), found.end(), [](auto const& a, auto const& b) { return a.first > b.first; });
        for (auto& [time, file] : found) s_files.push_back(std::move(file));
        return s_files;
    }

    std::string status() {
        if (s_state == State::Recording) {
            return fmt::format("Recording: {} inputs, tick {}", s_recording.inputs.size(), s_ticks);
        }
        if (s_state == State::Playing && s_loaded) {
            return fmt::format("Playing {}: input {} of {}", stem(s_loaded->path), s_nextInput, s_playInputs.size());
        }
        return "";
    }

    void saveBotRun(PlayLayer* pl, std::vector<Input> const& inputs) {
        Macro macro;
        macro.fps = kTicksPerSecond;
        macro.inputs = inputs;
        macro.botName = "GrassyHack Auto Bot";
        if (pl && pl->m_level) {
            macro.levelName = pl->m_level->m_levelName;
            macro.levelID = static_cast<uint64_t>(std::max(0, pl->m_level->m_levelID.value()));
        }
        std::error_code error;
        std::filesystem::create_directories(folder(), error);
        auto path = freePath(macro.levelName + " (Auto Bot)", Format::GDR);
        if (auto result = save(macro, Format::GDR, path); !result) {
            log::warn("Couldn't save the bot's run as a macro: {}", result.unwrapErr());
            return;
        }
        s_scanned = false;
        log::info("Saved the bot's run as {}", path.string());
    }
}

class $modify(MacroGameLayer, GJBaseGameLayer) {
    // Runs once per physics tick
    void processCommands(float dt, bool isHalfTick, bool isLastTick) {
        auto pl = PlayLayer::get();
        if (!pl || pl != static_cast<GJBaseGameLayer*>(this)) {
            return GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
        }
        if (s_state == State::Playing && !bot::isRunning()) playInputs(pl, s_ticks);
        s_ticks++;
        s_inTick = true;
        GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
        s_inTick = false;
    }

    void handleButton(bool down, int button, bool isPlayer1) {
        auto pl = PlayLayer::get();
        if (!pl || pl != static_cast<GJBaseGameLayer*>(this) || s_macroPressing || bot::isRunning()) {
            return GJBaseGameLayer::handleButton(down, button, isPlayer1);
        }
        // The macro has the controls
        if (s_state == State::Playing) return;
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
        if (s_state != State::Recording || pl->m_hasCompletedLevel || button < 1 || button > 3) return;
        // Pressed during a tick, it counts for that tick, otherwise for the next one
        uint64_t tick = s_inTick && s_ticks > 0 ? s_ticks - 1 : s_ticks;
        Input input{ tick, static_cast<uint8_t>(button), twoPlayer(pl) && !isPlayer1, down };
        logInput("Recorded", pl, input);
        record(input);
    }
};

class $modify(MacroPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        s_ticks = 0;
        s_checkpointTicks.clear();
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;
        if (s_state == State::Recording) beginRecording(this);
        if (s_state == State::Playing) startPlayback(this);
        return true;
    }

    void resetLevel() {
        s_loadedCheckpoint = false;
        PlayLayer::resetLevel();
        if (!s_loadedCheckpoint) s_ticks = 0;
        if (bot::isRunning()) return;
        if (s_state == State::Recording) {
            if (s_loadedCheckpoint) rewindRecording(this, s_ticks);
            else beginRecording(this);
        }
        if (s_state == State::Playing) startPlayback(this);
    }

    void loadFromCheckpoint(CheckpointObject* checkpoint) {
        PlayLayer::loadFromCheckpoint(checkpoint);
        if (auto it = s_checkpointTicks.find(checkpoint); it != s_checkpointTicks.end()) {
            s_ticks = it->second;
            s_loadedCheckpoint = true;
        }
    }

    CheckpointObject* createCheckpoint() {
        auto checkpoint = PlayLayer::createCheckpoint();
        // The bot makes thousands of these
        if (checkpoint && !bot::isRunning()) s_checkpointTicks[checkpoint] = s_ticks;
        return checkpoint;
    }

    void levelComplete() {
        PlayLayer::levelComplete();
        if (s_state == State::Playing) {
            notify("The macro beat the level", NotificationIcon::Success);
        }
        else if (s_state == State::Recording) {
            s_state = State::Off;
            if (!config::getBool("macro.autosave")) {
                notify("Recording done. Save it in the Bot window's Macro tab.", NotificationIcon::Success);
                return;
            }
            auto saved = macro::saveRecording(s_recording.levelName, saveFormat());
            if (saved) notify("Saved macro " + saved.unwrap().filename().string(), NotificationIcon::Success);
            else notify("Couldn't save the macro: " + saved.unwrapErr(), NotificationIcon::Error);
        }
    }

    void onQuit() {
        if (s_state != State::Off) s_state = State::Off;
        s_checkpointTicks.clear();
        PlayLayer::onQuit();
    }
};

$on_mod(Loaded) {
    std::error_code error;
    s_debug = std::filesystem::exists(macro::folder() / "debug.txt", error);
    runSelfTest();
}
