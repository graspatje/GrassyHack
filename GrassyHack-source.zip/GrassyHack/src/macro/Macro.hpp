#pragma once

#include <Geode/Result.hpp>

#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

// Macros: when to press and release the buttons, frame by frame. A frame is
// one physics tick from the start of the attempt, at "fps" ticks per second
// (GD 2.2 runs at 240 unless a TPS bypass changed it). An input at frame N
// happens right before tick N runs.
//
// Formats.cpp reads and writes the files of the popular bots. It doesn't use
// anything from GD, so it can be tested on its own.
namespace grassy::macro {
    struct Input {
        uint64_t frame = 0;
        // 1 jump, 2 left, 3 right (the last two in platformer levels)
        uint8_t button = 1;
        // The second player in two-player mode
        bool player2 = false;
        bool down = false;

        bool operator==(Input const&) const = default;
    };

    struct Macro {
        double fps = 240.0;
        // In frame order
        std::vector<Input> inputs;
        std::string levelName;
        uint64_t levelID = 0;
        std::string author;
        // The bot that made the file, when it says
        std::string botName;

        bool usesSideButtons() const;
        double seconds() const;
    };

    enum class Format {
        GDR,
        GDRJson,
        GDR2,
        ReplayEngine3,
        ReplayEngine4,
        Silicate,
        TCBot,
        YBot,
        FrameWindow,
        MegaHackJson,
        MegaHackBinary,
        TASBot,
        Echo,
        ZBot,
        XdBotOld,
        ReplayEngine,
        ReplayEngine2,
    };

    struct FormatInfo {
        Format format;
        // What it's called in the menu
        char const* name;
        // The end of the file name, like ".gdr"
        char const* extension;
        // Which bots use it
        char const* bots;
        bool canWrite;
    };

    // Every format, the ones today's bots use first
    std::vector<FormatInfo> const& formats();
    FormatInfo const& info(Format format);

    // Reads a macro file of any supported format, going by its contents and name
    geode::Result<Macro> load(std::filesystem::path const& path, Format* detected = nullptr);
    geode::Result<Macro> parse(std::vector<uint8_t> const& data, std::string const& fileName, Format* detected = nullptr);
    geode::Result<> save(Macro const& macro, Format format, std::filesystem::path const& path);
    geode::Result<std::vector<uint8_t>> serialize(Macro const& macro, Format format);

    // The file name without the format's ending, "Level.gdr.json" -> "Level"
    std::string stem(std::filesystem::path const& path);

    // Writes the macro in every format and reads it back, a line per format
    // saying whether the inputs came back the same. For testing.
    std::vector<std::string> roundTrip(Macro const& macro);
}
