#pragma once

#include "Macro.hpp"

#include <Geode/Geode.hpp>

#include <filesystem>
#include <optional>
#include <string>
#include <vector>

// Recording and playing macros in levels, and the macros folder
namespace grassy::macro {
    enum class State { Off, Recording, Playing };

    State state();
    // Starts or stops recording or playing. Outside a level it starts with the next one.
    void setState(State state);

    struct Loaded {
        Macro macro;
        std::filesystem::path path;
        Format format;
    };

    // The macro Play uses, nullptr until one is opened
    Loaded const* loaded();
    geode::Result<> open(std::filesystem::path const& path);

    // What was recorded last, kept until the next recording starts
    Macro const& recording();
    // Saves the recording in the macros folder and returns the file
    geode::Result<std::filesystem::path> saveRecording(std::string const& name, Format format);
    // Saves the opened macro in another format in the macros folder
    geode::Result<std::filesystem::path> convertLoaded(Format format);

    std::filesystem::path folder();

    struct File {
        std::filesystem::path path;
        std::string name;
        std::string formatName;
    };

    // The macros in the folder, newest first. Looks again when asked to.
    std::vector<File> const& files(bool rescan = false);

    // What's going on, for the menu. Empty when off.
    std::string status();

    // Saves the auto bot's finished run in the macros folder
    void saveBotRun(PlayLayer* pl, std::vector<Input> const& inputs);
}
