#include "Macro.hpp"

#include <matjson.hpp>

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iterator>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string_view>

using namespace grassy::macro;

// The layouts come from the bots' own code where it's public (Silicate's
// slc_oxide, TCBot's tcm-rs, xdBot's gdr.hpp) and from zcb3, a public domain
// click sound tool that reads and writes all of them. Real files from Eclipse,
// Mega Hack converters, Silicate and TCBot were checked against these readers.

namespace {
    // Thrown by the readers on a file they can't make sense of
    struct BadFile : std::runtime_error {
        using std::runtime_error::runtime_error;
    };

    template <class T>
    T swapBytes(T value) {
        uint8_t bytes[sizeof(T)];
        std::memcpy(bytes, &value, sizeof(T));
        std::reverse(std::begin(bytes), std::end(bytes));
        std::memcpy(&value, bytes, sizeof(T));
        return value;
    }

    class Reader {
        std::vector<uint8_t> const& m_data;
        size_t m_pos = 0;

    public:
        explicit Reader(std::vector<uint8_t> const& data) : m_data(data) {}

        size_t pos() const { return m_pos; }
        size_t size() const { return m_data.size(); }
        size_t remaining() const { return m_data.size() - m_pos; }
        bool atEnd() const { return m_pos >= m_data.size(); }

        void seek(size_t pos) {
            if (pos > m_data.size()) throw BadFile("the file ends too early");
            m_pos = pos;
        }

        void skip(uint64_t count) {
            if (count > remaining()) throw BadFile("the file ends too early");
            m_pos += static_cast<size_t>(count);
        }

        uint8_t const* take(size_t count) {
            if (count > remaining()) throw BadFile("the file ends too early");
            auto bytes = m_data.data() + m_pos;
            m_pos += count;
            return bytes;
        }

        // Windows PCs are little-endian, so that's the plain order
        template <class T>
        T le() {
            T value;
            std::memcpy(&value, take(sizeof(T)), sizeof(T));
            return value;
        }

        template <class T>
        T be() {
            return swapBytes(le<T>());
        }

        uint8_t byte() { return *take(1); }

        uint64_t varint() {
            uint64_t value = 0;
            for (int shift = 0; shift < 64; shift += 7) {
                uint8_t part = byte();
                value |= static_cast<uint64_t>(part & 0x7F) << shift;
                if (!(part & 0x80)) return value;
            }
            throw BadFile("a number in the file is too long");
        }

        // Bytes holding a little-endian number, for formats that pack inputs in 1 to 8 bytes
        uint64_t sized(size_t count) {
            uint64_t value = 0;
            std::memcpy(&value, take(count), count);
            return value;
        }

        std::string string(uint64_t length) {
            if (length > remaining()) throw BadFile("the file ends too early");
            auto bytes = take(static_cast<size_t>(length));
            return std::string(reinterpret_cast<char const*>(bytes), static_cast<size_t>(length));
        }
    };

    class Writer {
    public:
        std::vector<uint8_t> data;

        void bytes(void const* source, size_t count) {
            auto start = static_cast<uint8_t const*>(source);
            data.insert(data.end(), start, start + count);
        }

        template <class T>
        void le(T value) { bytes(&value, sizeof(T)); }

        template <class T>
        void be(T value) { le(swapBytes(value)); }

        void byte(uint8_t value) { data.push_back(value); }
        void zeros(size_t count) { data.insert(data.end(), count, 0); }
        void text(std::string_view value) { bytes(value.data(), value.size()); }

        void varint(uint64_t value) {
            do {
                uint8_t part = value & 0x7F;
                value >>= 7;
                if (value) part |= 0x80;
                data.push_back(part);
            } while (value);
        }

        void sized(uint64_t value, size_t count) { bytes(&value, count); }
    };

    uint8_t validButton(int64_t button) {
        return button >= 1 && button <= 3 ? static_cast<uint8_t>(button) : 1;
    }

    void sortInputs(Macro& macro) {
        std::stable_sort(macro.inputs.begin(), macro.inputs.end(), [](Input const& a, Input const& b) {
            return a.frame < b.frame;
        });
    }

    // Collects inputs from formats that keep everything that happened while
    // recording: a restart starts the macro over, and going back in time
    // (respawning at a practice checkpoint) replaces what came after
    class Timeline {
        Macro& m_macro;
        // Frames count on from the start of the recording in some formats
        uint64_t m_attemptStart = 0;

    public:
        explicit Timeline(Macro& macro) : m_macro(macro) {}

        void add(uint64_t frame, uint8_t button, bool player2, bool down) {
            frame = frame >= m_attemptStart ? frame - m_attemptStart : 0;
            auto& inputs = m_macro.inputs;
            if (!inputs.empty() && frame < inputs.back().frame) {
                std::erase_if(inputs, [&](Input const& input) { return input.frame >= frame; });
            }
            inputs.push_back({ frame, validButton(button), player2, down });
        }

        void restart(uint64_t frame = 0) {
            m_macro.inputs.clear();
            m_attemptStart = frame;
        }

        // The speed only counts from before the first input
        void tps(double value) {
            if (m_macro.inputs.empty() && value > 0.0 && std::isfinite(value)) m_macro.fps = value;
        }
    };

    // JSON helpers that never fail, for the fields bots may leave out
    double number(matjson::Value const& value, double fallback = 0.0) {
        return value.asDouble().unwrapOr(fallback);
    }

    uint64_t whole(matjson::Value const& value) {
        double result = number(value);
        return result > 0.0 ? static_cast<uint64_t>(std::llround(result)) : 0;
    }

    bool flag(matjson::Value const& value) {
        if (value.isNumber()) return number(value) != 0.0;
        return value.asBool().unwrapOr(false);
    }

    std::string text(matjson::Value const& value) {
        return value.asString().unwrapOr("");
    }

    matjson::Value parseJson(std::vector<uint8_t> const& data) {
        std::string_view source(reinterpret_cast<char const*>(data.data()), data.size());
        auto parsed = matjson::Value::parse(source);
        if (!parsed) throw BadFile("it isn't valid JSON: " + parsed.unwrapErr().message);
        return parsed.unwrap();
    }

    bool startsWith(std::vector<uint8_t> const& data, std::string_view prefix) {
        return data.size() >= prefix.size() && std::memcmp(data.data(), prefix.data(), prefix.size()) == 0;
    }

    bool looksLikeJson(std::vector<uint8_t> const& data) {
        for (auto c : data) {
            if (std::isspace(c)) continue;
            return c == '{';
        }
        return false;
    }

    // MessagePack, the binary JSON that GDR files are usually stored as

    matjson::Value readMsgpack(Reader& r, int depth = 0) {
        if (depth > 32) throw BadFile("it's nested too deeply");
        auto list = [&](uint64_t count) {
            std::vector<matjson::Value> items;
            for (uint64_t i = 0; i < count; i++) items.push_back(readMsgpack(r, depth + 1));
            return matjson::Value(std::move(items));
        };
        auto map = [&](uint64_t count) {
            auto object = matjson::Value::object();
            for (uint64_t i = 0; i < count; i++) {
                auto key = readMsgpack(r, depth + 1);
                auto value = readMsgpack(r, depth + 1);
                object.set(key.isString() ? text(key) : key.dump(), std::move(value));
            }
            return object;
        };

        uint8_t type = r.byte();
        if (type <= 0x7F) return matjson::Value(static_cast<int64_t>(type));
        if (type >= 0xE0) return matjson::Value(static_cast<int64_t>(static_cast<int8_t>(type)));
        if ((type & 0xF0) == 0x80) return map(type & 0x0F);
        if ((type & 0xF0) == 0x90) return list(type & 0x0F);
        if ((type & 0xE0) == 0xA0) return matjson::Value(r.string(type & 0x1F));
        switch (type) {
            case 0xC0: return matjson::Value(nullptr);
            case 0xC2: return matjson::Value(false);
            case 0xC3: return matjson::Value(true);
            case 0xC4: case 0xD9: return matjson::Value(r.string(r.byte()));
            case 0xC5: case 0xDA: return matjson::Value(r.string(r.be<uint16_t>()));
            case 0xC6: case 0xDB: return matjson::Value(r.string(r.be<uint32_t>()));
            case 0xCA: return matjson::Value(static_cast<double>(r.be<float>()));
            case 0xCB: return matjson::Value(r.be<double>());
            case 0xCC: return matjson::Value(static_cast<uint64_t>(r.byte()));
            case 0xCD: return matjson::Value(static_cast<uint64_t>(r.be<uint16_t>()));
            case 0xCE: return matjson::Value(static_cast<uint64_t>(r.be<uint32_t>()));
            case 0xCF: return matjson::Value(r.be<uint64_t>());
            case 0xD0: return matjson::Value(static_cast<int64_t>(static_cast<int8_t>(r.byte())));
            case 0xD1: return matjson::Value(static_cast<int64_t>(r.be<int16_t>()));
            case 0xD2: return matjson::Value(static_cast<int64_t>(r.be<int32_t>()));
            case 0xD3: return matjson::Value(r.be<int64_t>());
            case 0xDC: return list(r.be<uint16_t>());
            case 0xDD: return list(r.be<uint32_t>());
            case 0xDE: return map(r.be<uint16_t>());
            case 0xDF: return map(r.be<uint32_t>());
            // Extension types, which GDR doesn't use
            case 0xD4: r.skip(2); return matjson::Value(nullptr);
            case 0xD5: r.skip(3); return matjson::Value(nullptr);
            case 0xD6: r.skip(5); return matjson::Value(nullptr);
            case 0xD7: r.skip(9); return matjson::Value(nullptr);
            case 0xD8: r.skip(17); return matjson::Value(nullptr);
            case 0xC7: r.skip(1 + static_cast<uint64_t>(r.byte())); return matjson::Value(nullptr);
            case 0xC8: { auto size = r.be<uint16_t>(); r.skip(1 + static_cast<uint64_t>(size)); return matjson::Value(nullptr); }
            case 0xC9: { auto size = r.be<uint32_t>(); r.skip(1 + static_cast<uint64_t>(size)); return matjson::Value(nullptr); }
            default: throw BadFile("it isn't a GDR file");
        }
    }

    class Msgpack : public Writer {
    public:
        void map(size_t count) {
            if (count < 16) return byte(static_cast<uint8_t>(0x80 | count));
            byte(0xDE);
            be(static_cast<uint16_t>(count));
        }

        void array(size_t count) {
            if (count < 16) return byte(static_cast<uint8_t>(0x90 | count));
            if (count <= 0xFFFF) {
                byte(0xDC);
                return be(static_cast<uint16_t>(count));
            }
            byte(0xDD);
            be(static_cast<uint32_t>(count));
        }

        void string(std::string_view value) {
            if (value.size() < 32) byte(static_cast<uint8_t>(0xA0 | value.size()));
            else if (value.size() <= 0xFF) { byte(0xD9); byte(static_cast<uint8_t>(value.size())); }
            else if (value.size() <= 0xFFFF) { byte(0xDA); be(static_cast<uint16_t>(value.size())); }
            else { byte(0xDB); be(static_cast<uint32_t>(value.size())); }
            text(value);
        }

        void unsignedNumber(uint64_t value) {
            if (value <= 0x7F) return byte(static_cast<uint8_t>(value));
            if (value <= 0xFF) { byte(0xCC); return byte(static_cast<uint8_t>(value)); }
            if (value <= 0xFFFF) { byte(0xCD); return be(static_cast<uint16_t>(value)); }
            if (value <= 0xFFFFFFFF) { byte(0xCE); return be(static_cast<uint32_t>(value)); }
            byte(0xCF);
            be(value);
        }

        void floatNumber(double value) {
            byte(0xCB);
            be(value);
        }

        void boolean(bool value) { byte(value ? 0xC3 : 0xC2); }
    };

    // Version text like "v2.3.11" or "2.3.6-beta.1" is below major.minor.patch
    bool versionBefore(std::string version, int major, int minor, int patch) {
        if (!version.empty() && (version[0] == 'v' || version[0] == 'V')) version.erase(0, 1);
        int parts[3] = {};
        std::istringstream stream(version);
        for (int i = 0; i < 3; i++) {
            if (!(stream >> parts[i])) break;
            if (stream.peek() != '.') break;
            stream.get();
        }
        int wanted[3] = { major, minor, patch };
        return std::lexicographical_compare(parts, parts + 3, wanted, wanted + 3);
    }

    // GDR: Mega Hack, xdBot, zBot, Prism Menu, iCreate Pro. JSON fields, stored as
    // MessagePack in .gdr files.

    Macro readGDRJson(matjson::Value const& json) {
        if (!json.isObject() || !json.contains("inputs")) throw BadFile("it isn't a GDR file");
        Macro macro;
        macro.fps = number(json["framerate"], 240.0);
        macro.author = text(json["author"]);
        macro.botName = text(json["bot"]["name"]);
        macro.levelName = text(json["level"]["name"]);
        macro.levelID = whole(json["level"]["id"]);
        // xdBot before 2.3.6 counted frames one lower, and adds one when it loads them
        uint64_t offset = macro.botName == "xdBot" && versionBefore(text(json["bot"]["version"]), 2, 3, 6) ? 1 : 0;
        auto const& inputs = json["inputs"];
        for (size_t i = 0; inputs.isArray() && i < inputs.size(); i++) {
            auto const& input = inputs[i];
            if (!input.contains("frame")) continue;
            macro.inputs.push_back({ whole(input["frame"]) + offset, validButton(whole(input["btn"])), flag(input["2p"]),
                flag(input["down"]) });
        }
        sortInputs(macro);
        return macro;
    }

    Macro readGDR(std::vector<uint8_t> const& data) {
        if (looksLikeJson(data)) return readGDRJson(parseJson(data));
        Reader r(data);
        return readGDRJson(readMsgpack(r));
    }

    // Same fields and types as xdBot writes them, which every GDR bot reads
    std::vector<uint8_t> writeGDR(Macro const& macro, bool json) {
        if (json) {
            std::vector<matjson::Value> inputs;
            for (auto const& input : macro.inputs) {
                inputs.push_back(matjson::makeObject({
                    { "frame", input.frame },
                    { "btn", static_cast<int>(input.button) },
                    { "2p", input.player2 },
                    { "down", input.down },
                }));
            }
            auto replay = matjson::makeObject({
                { "gameVersion", 2.2081 },
                { "description", "" },
                { "version", 1.0 },
                { "duration", macro.seconds() },
                { "bot", matjson::makeObject({ { "name", "GrassyHack" }, { "version", "1.0.0" } }) },
                { "level", matjson::makeObject({ { "id", macro.levelID }, { "name", macro.levelName } }) },
                { "author", macro.author },
                { "seed", 0 },
                { "coins", 0 },
                { "ldm", false },
                { "framerate", macro.fps },
                { "inputs", matjson::Value(std::move(inputs)) },
            });
            auto dumped = replay.dump(matjson::NO_INDENTATION);
            return std::vector<uint8_t>(dumped.begin(), dumped.end());
        }

        Msgpack w;
        w.map(12);
        w.string("gameVersion"); w.floatNumber(2.2081);
        w.string("description"); w.string("");
        w.string("version"); w.floatNumber(1.0);
        w.string("duration"); w.floatNumber(macro.seconds());
        w.string("bot"); w.map(2);
        w.string("name"); w.string("GrassyHack");
        w.string("version"); w.string("1.0.0");
        w.string("level"); w.map(2);
        w.string("id"); w.unsignedNumber(macro.levelID);
        w.string("name"); w.string(macro.levelName);
        w.string("author"); w.string(macro.author);
        w.string("seed"); w.unsignedNumber(0);
        w.string("coins"); w.unsignedNumber(0);
        w.string("ldm"); w.boolean(false);
        w.string("framerate"); w.floatNumber(macro.fps);
        w.string("inputs"); w.array(macro.inputs.size());
        for (auto const& input : macro.inputs) {
            w.map(4);
            w.string("frame"); w.unsignedNumber(input.frame);
            w.string("btn"); w.unsignedNumber(input.button);
            w.string("2p"); w.boolean(input.player2);
            w.string("down"); w.boolean(input.down);
        }
        return std::move(w.data);
    }

    // GDR2: Eclipse. Varints, big-endian floats, player 1's inputs then player 2's.

    Macro readGDR2(std::vector<uint8_t> const& data) {
        Reader r(data);
        if (r.string(3) != "GDR") throw BadFile("it isn't a GDR2 file");
        if (auto version = r.varint(); version != 2) throw BadFile("it's GDR2 version " + std::to_string(version));
        auto readString = [&] { return r.string(r.varint()); };
        bool inputExtensions = !readString().empty();
        Macro macro;
        macro.author = readString();
        readString(); // description
        r.be<float>(); // duration
        r.varint(); // game version
        macro.fps = r.be<double>();
        r.varint(); // seed
        r.varint(); // coins
        r.byte(); // low detail mode
        bool platformer = r.byte() != 0;
        macro.botName = readString();
        r.varint(); // bot version
        macro.levelID = r.varint();
        macro.levelName = readString();
        r.skip(r.varint()); // replay extension

        auto deaths = r.varint();
        for (uint64_t i = 0; i < deaths; i++) r.varint();

        auto total = r.varint();
        auto player1Count = r.varint();
        uint64_t frame = 0;
        for (uint64_t i = 0; i < total; i++) {
            // Player 2's inputs count from 0 again
            if (i == player1Count) frame = 0;
            auto packed = r.varint();
            frame += platformer ? packed >> 3 : packed >> 1;
            uint8_t button = platformer ? static_cast<uint8_t>((packed >> 1) & 3) : 1;
            macro.inputs.push_back({ frame, validButton(button), i >= player1Count, (packed & 1) != 0 });
            if (inputExtensions) r.skip(r.varint());
        }
        sortInputs(macro);
        return macro;
    }

    std::vector<uint8_t> writeGDR2(Macro const& macro) {
        Writer w;
        auto writeString = [&](std::string_view value) {
            w.varint(value.size());
            w.text(value);
        };
        bool platformer = macro.usesSideButtons();
        w.text("GDR");
        w.varint(2);
        writeString(""); // no extension data on inputs
        writeString(macro.author);
        writeString(""); // description
        w.be(static_cast<float>(macro.seconds()));
        w.varint(0); // game version, Eclipse leaves it 0
        w.be(macro.fps);
        w.varint(0); // seed
        w.varint(0); // coins
        w.byte(0); // low detail mode
        w.byte(platformer);
        writeString("GrassyHack");
        w.varint(1); // bot version
        w.varint(macro.levelID);
        writeString(macro.levelName);
        w.varint(0); // no replay extension
        w.varint(0); // no deaths

        auto player1Count = std::count_if(macro.inputs.begin(), macro.inputs.end(), [](Input const& i) { return !i.player2; });
        w.varint(macro.inputs.size());
        w.varint(static_cast<uint64_t>(player1Count));
        for (bool player2 : { false, true }) {
            uint64_t previous = 0;
            for (auto const& input : macro.inputs) {
                if (input.player2 != player2) continue;
                uint64_t delta = input.frame - previous;
                uint64_t down = input.down ? 1 : 0;
                w.varint(platformer ? (delta << 3) | (static_cast<uint64_t>(input.button) << 1) | down : (delta << 1) | down);
                previous = input.frame;
            }
        }
        return std::move(w.data);
    }

    // ReplayEngine: GDH. Version 1 and 3 are copies of C++ structs, so they have padding.

    constexpr size_t kReplayEnginePhysicsSize = 32;

    // { u32 frame; bool down; i32 button; bool player; } with the struct's padding
    void readReplayEngineAction(Reader& r, Macro& macro, bool playerIsSecond, std::optional<bool> fixedPlayer2) {
        auto frame = r.le<uint32_t>();
        bool down = r.byte() != 0;
        r.skip(3);
        auto button = r.le<int32_t>();
        bool player = r.byte() != 0;
        r.skip(3);
        bool player2 = fixedPlayer2 ? *fixedPlayer2 : (playerIsSecond ? player : !player);
        macro.inputs.push_back({ frame, validButton(button), player2, down });
    }

    void writeReplayEngineAction(Writer& w, Input const& input, bool player) {
        w.le(static_cast<uint32_t>(input.frame));
        w.byte(input.down);
        w.zeros(3);
        w.le(static_cast<int32_t>(input.button));
        w.byte(player);
        w.zeros(3);
    }

    Macro readReplayEngine(std::vector<uint8_t> const& data) {
        Reader r(data);
        Macro macro;
        macro.fps = r.le<float>();
        auto physics = r.le<uint32_t>();
        auto actions = r.le<uint32_t>();
        r.skip(static_cast<uint64_t>(physics) * kReplayEnginePhysicsSize);
        for (uint32_t i = 0; i < actions; i++) readReplayEngineAction(r, macro, true, std::nullopt);
        sortInputs(macro);
        return macro;
    }

    Macro readReplayEngine2(std::vector<uint8_t> const& data) {
        Reader r(data);
        if (r.string(3) != "RE2") throw BadFile("it isn't a ReplayEngine 2 file");
        Macro macro;
        auto actions = r.le<uint32_t>();
        for (uint32_t i = 0; i < actions; i++) readReplayEngineAction(r, macro, true, std::nullopt);
        sortInputs(macro);
        return macro;
    }

    Macro readReplayEngine3(std::vector<uint8_t> const& data) {
        Reader r(data);
        Macro macro;
        macro.fps = r.le<float>();
        auto player1Physics = r.le<uint32_t>();
        auto player2Physics = r.le<uint32_t>();
        auto player1Actions = r.le<uint32_t>();
        auto player2Actions = r.le<uint32_t>();
        r.skip((static_cast<uint64_t>(player1Physics) + player2Physics) * kReplayEnginePhysicsSize);
        for (uint32_t i = 0; i < player1Actions; i++) readReplayEngineAction(r, macro, false, false);
        for (uint32_t i = 0; i < player2Actions; i++) readReplayEngineAction(r, macro, false, true);
        sortInputs(macro);
        return macro;
    }

    std::vector<uint8_t> writeReplayEngine3(Macro const& macro) {
        Writer w;
        auto player1Count = std::count_if(macro.inputs.begin(), macro.inputs.end(), [](Input const& i) { return !i.player2; });
        w.le(static_cast<float>(macro.fps));
        // No position corrections, only the inputs
        w.le<uint32_t>(0);
        w.le<uint32_t>(0);
        w.le(static_cast<uint32_t>(player1Count));
        w.le(static_cast<uint32_t>(macro.inputs.size() - player1Count));
        for (bool player2 : { false, true }) {
            for (auto const& input : macro.inputs) {
                if (input.player2 == player2) writeReplayEngineAction(w, input, !player2);
            }
        }
        return std::move(w.data);
    }

    Macro readReplayEngine4(std::vector<uint8_t> const& data) {
        Reader r(data);
        if (r.string(3) != "RE4") throw BadFile("it isn't a ReplayEngine 4 file");
        Macro macro;
        macro.fps = r.le<float>();
        auto physics = r.le<uint64_t>();
        // frame u64, x f32, y f32, y speed f64, player 2 u8
        r.skip(physics * 25);
        auto inputs = r.le<uint64_t>();
        for (uint64_t i = 0; i < inputs; i++) {
            auto frame = r.le<uint64_t>();
            bool down = r.byte() != 0;
            auto button = r.le<int32_t>();
            bool player2 = r.byte() != 0;
            macro.inputs.push_back({ frame, validButton(button), player2, down });
        }
        sortInputs(macro);
        return macro;
    }

    std::vector<uint8_t> writeReplayEngine4(Macro const& macro) {
        Writer w;
        w.text("RE4");
        w.le(static_cast<float>(macro.fps));
        w.le<uint64_t>(0);
        w.le(static_cast<uint64_t>(macro.inputs.size()));
        for (auto const& input : macro.inputs) {
            w.le(input.frame);
            w.byte(input.down);
            w.le(static_cast<int32_t>(input.button));
            w.byte(input.player2);
        }
        return std::move(w.data);
    }

    // Silicate: version 1 is plain packed inputs, 2 groups them by size,
    // 3 groups them into sections that can repeat

    constexpr char kSilicate3Header[] = "SLC3RPLY";

    Macro readSilicate1(std::vector<uint8_t> const& data) {
        Reader r(data);
        Macro macro;
        macro.fps = r.le<double>();
        auto count = r.le<uint32_t>();
        for (uint32_t i = 0; i < count; i++) {
            auto packed = r.le<uint32_t>();
            macro.inputs.push_back({ packed >> 4, validButton((packed >> 1) & 3), (packed & 8) != 0, (packed & 1) != 0 });
        }
        sortInputs(macro);
        return macro;
    }

    Macro readSilicate2(std::vector<uint8_t> const& data) {
        Reader r(data);
        r.skip(4); // "SILL"
        Macro macro;
        macro.fps = r.le<double>();
        r.skip(r.le<uint64_t>()); // meta
        auto count = r.le<uint64_t>();
        auto blobCount = r.le<uint64_t>();
        struct Blob { uint64_t byteSize, start, length; };
        std::vector<Blob> blobs;
        for (uint64_t i = 0; i < blobCount; i++) {
            Blob blob;
            blob.byteSize = r.le<uint64_t>();
            blob.start = r.le<uint64_t>();
            blob.length = r.le<uint64_t>();
            if (blob.byteSize < 1 || blob.byteSize > 8) throw BadFile("it has a broken input group");
            blobs.push_back(blob);
        }

        Timeline timeline(macro);
        uint64_t frame = 0;
        uint64_t read = 0;
        for (auto const& blob : blobs) {
            for (uint64_t i = 0; i < blob.length && read < count; i++, read++) {
                auto state = r.sized(static_cast<size_t>(blob.byteSize));
                frame += state >> 5;
                auto type = (state >> 2) & 7;
                if (type >= 1 && type <= 3) timeline.add(frame, static_cast<uint8_t>(type), (state & 2) != 0, (state & 1) != 0);
                else if (type == 4 || type == 5) timeline.restart(frame);
                else if (type == 7) timeline.tps(r.le<double>());
            }
        }
        if (r.string(3) != "EOM") throw BadFile("its end is missing");
        return macro;
    }

    Macro readSilicate3(std::vector<uint8_t> const& data) {
        Reader r(data);
        r.skip(8); // "SLC3RPLY"
        if (r.le<uint16_t>() != 64) throw BadFile("its header has the wrong size");
        Macro macro;
        macro.fps = r.le<double>();
        r.skip(56); // seed, version, build, randomness and padding
        if (data.empty() || data.back() != 0xCC) throw BadFile("its end is missing");
        size_t end = data.size() - 1;

        Timeline timeline(macro);
        while (r.pos() < end) {
            auto id = r.le<uint32_t>();
            auto size = r.le<uint64_t>() & 0x00FF'FFFF'FFFF'FFFF;
            if (size > end - r.pos()) throw BadFile("a part of it ends too late");
            size_t atomEnd = r.pos() + static_cast<size_t>(size);
            // Atom 1 holds the inputs, others hold things like markers
            if (id != 1) {
                r.seek(atomEnd);
                continue;
            }
            auto count = r.le<uint64_t>();
            uint64_t actions = 0;
            uint64_t frame = 0;
            // One player input: a delta in frames, then button (0 = a press
            // and release in the same frame), player 2 and holding
            auto playerInput = [&](uint64_t state, uint64_t base) {
                frame = base + (state >> 4);
                auto button = (state >> 2) & 3;
                bool player2 = (state & 2) != 0;
                if (button == 0) {
                    timeline.add(frame, 1, player2, true);
                    timeline.add(frame, 1, player2, false);
                    actions += 2;
                }
                else {
                    timeline.add(frame, static_cast<uint8_t>(button), player2, (state & 1) != 0);
                    actions++;
                }
            };
            while (actions < count && r.pos() < atomEnd) {
                auto header = r.le<uint16_t>();
                auto kind = header >> 14;
                if (kind == 0 || kind == 1) {
                    size_t byteSize = size_t(1) << ((header >> 12) & 3);
                    uint64_t length = uint64_t(1) << ((header >> 8) & 15);
                    if (kind == 0) {
                        for (uint64_t i = 0; i < length; i++) playerInput(r.sized(byteSize), frame);
                    }
                    else {
                        // The same inputs played over and over
                        uint64_t repeats = uint64_t(1) << ((header >> 3) & 31);
                        std::vector<uint64_t> states;
                        for (uint64_t i = 0; i < length; i++) states.push_back(r.sized(byteSize));
                        for (uint64_t repeat = 0; repeat < repeats && actions < count; repeat++) {
                            for (auto state : states) playerInput(state, frame);
                        }
                    }
                }
                else if (kind == 2) {
                    size_t byteSize = size_t(1) << ((header >> 8) & 3);
                    auto special = (header >> 10) & 15;
                    frame += r.sized(byteSize);
                    actions++;
                    // 0 restart, 1 full restart, 2 death (all with a seed), 3 TPS, 4 bug point
                    if (special <= 2) {
                        r.skip(8);
                        if (special <= 1) timeline.restart(frame);
                    }
                    else if (special == 3) {
                        timeline.tps(r.le<double>());
                    }
                }
                else {
                    throw BadFile("it has a section of an unknown kind");
                }
            }
            r.seek(atomEnd);
        }
        return macro;
    }

    Macro readSilicate(std::vector<uint8_t> const& data) {
        if (startsWith(data, "SILL")) return readSilicate2(data);
        if (startsWith(data, kSilicate3Header)) return readSilicate3(data);
        return readSilicate1(data);
    }

    std::vector<uint8_t> writeSilicate3(Macro const& macro) {
        Writer w;
        w.text(kSilicate3Header);
        w.le<uint16_t>(64);
        w.le(macro.fps);
        w.le<uint64_t>(0); // seed
        w.le<uint32_t>(1); // version, 1 for Silicate itself
        w.le<uint32_t>(81); // GD build (2.2081)
        w.le<uint32_t>(0); // randomness algorithm
        w.zeros(36);

        // One byte size for every input, the smallest the longest gap fits in
        uint64_t largest = 0;
        uint64_t previous = 0;
        for (auto const& input : macro.inputs) {
            largest = std::max(largest, input.frame - previous);
            previous = input.frame;
        }
        int sizeExponent = 0;
        while (sizeExponent < 3 && (largest << 4 | 15) >> (8 << sizeExponent) != 0) sizeExponent++;
        size_t byteSize = size_t(1) << sizeExponent;

        Writer body;
        body.le(static_cast<uint64_t>(macro.inputs.size()));
        size_t index = 0;
        previous = 0;
        while (index < macro.inputs.size()) {
            // Sections hold a power of two of inputs, up to 2^15
            int countExponent = 15;
            while ((size_t(1) << countExponent) > macro.inputs.size() - index) countExponent--;
            body.le(static_cast<uint16_t>((sizeExponent << 12) | (countExponent << 8)));
            for (size_t i = 0; i < (size_t(1) << countExponent); i++, index++) {
                auto const& input = macro.inputs[index];
                uint64_t state = ((input.frame - previous) << 4) | (static_cast<uint64_t>(input.button) << 2) |
                    (static_cast<uint64_t>(input.player2) << 1) | static_cast<uint64_t>(input.down);
                body.sized(state, byteSize);
                previous = input.frame;
            }
        }
        w.le<uint32_t>(1);
        w.le(static_cast<uint64_t>(body.data.size()));
        w.bytes(body.data.data(), body.data.size());
        w.byte(0xCC);
        return std::move(w.data);
    }

    // TCBot (ծbot)

    constexpr uint8_t kTCBotHeader[16] = { 0x9f, 0x88, 0x89, 0x84, 0x9f, 0x3b, 0x1d, 0xd8, 0xcc, 0xa1, 0x86, 0x8a, 0x88, 0x99,
        0x84, 0x00 };

    Macro readTCBot(std::vector<uint8_t> const& data) {
        Reader r(data);
        if (std::memcmp(r.take(16), kTCBotHeader, 16) != 0) throw BadFile("it isn't a TCBot file");
        Macro macro;
        auto metaStart = r.pos();
        auto version = r.byte();
        r.byte(); // how many times it was appended to
        auto flags = r.byte();
        r.seek(metaStart + 4);
        auto speed = r.le<float>();
        // Version 2 can store the length of a tick instead of the ticks per second
        macro.fps = version == 2 && !(flags & 2) && speed > 0.f ? 1.0 / speed : speed;
        r.seek(metaStart + 64);
        Timeline timeline(macro);

        if (version == 1) {
            auto count = r.varint();
            for (uint64_t i = 0; i < count; i++) {
                auto frame = r.varint();
                auto packed = r.byte();
                auto type = packed & 7;
                if (type < 3) timeline.add(frame, static_cast<uint8_t>(type + 1), (packed & 0x40) != 0, (packed & 0x80) != 0);
                // A full restart starts over. A plain one is a respawn: platformer
                // levels keep counting, practice mode goes back in time.
                else if (type == 4) timeline.restart();
            }
            return macro;
        }
        if (version != 2) throw BadFile("it's TCBot version " + std::to_string(version));

        // Each action byte says how the gap to the next one is stored: in 0,
        // 1, 2 or 4 bytes, and whether it's added to the previous gap
        uint64_t frame = r.atEnd() ? 0 : r.varint();
        uint64_t lastDelta = 0;
        while (!r.atEnd()) {
            auto packed = r.byte();
            auto deltaInfo = packed >> 5;
            auto button = packed & 3;
            if (button) {
                bool down = (packed & 4) != 0;
                bool player2 = (packed & 8) != 0;
                timeline.add(frame, static_cast<uint8_t>(button), player2, down);
                // A press and release in the same frame
                if (packed & 16) timeline.add(frame, static_cast<uint8_t>(button), player2, !down);
            }
            else {
                auto custom = (packed >> 2) & 3;
                bool extra = (packed & 16) != 0;
                if (custom == 3) {
                    if (!extra) timeline.tps(r.le<float>());
                }
                else {
                    if (extra) r.skip(8); // a new random seed
                    // 0 restart, 1 full restart, 2 death. A full restart starts over, the
                    // others are respawns: platformer levels keep counting, practice mode
                    // goes back in time.
                    if (custom == 1) timeline.restart();
                    frame = 0;
                }
            }
            auto sizeCode = (deltaInfo >> 1) & 3;
            bool addToLast = (deltaInfo & 1) != 0;
            uint64_t delta = addToLast ? lastDelta : 0;
            if (sizeCode && r.atEnd()) break;
            if (sizeCode == 1) delta += r.byte();
            else if (sizeCode == 2) delta += r.le<uint16_t>();
            else if (sizeCode == 3) delta += r.le<uint32_t>();
            if (sizeCode && delta) lastDelta = delta;
            frame += delta;
        }
        return macro;
    }

    std::vector<uint8_t> writeTCBot(Macro const& macro) {
        Writer w;
        w.bytes(kTCBotHeader, 16);
        w.byte(2); // version
        w.byte(0); // appended
        w.byte(2); // the next number is ticks per second
        w.byte(0);
        w.le(static_cast<float>(macro.fps));
        w.zeros(64 - 8);
        if (macro.inputs.empty()) return std::move(w.data);

        w.varint(macro.inputs.front().frame);
        for (size_t i = 0; i < macro.inputs.size(); i++) {
            auto const& input = macro.inputs[i];
            uint64_t delta = i + 1 < macro.inputs.size() ? macro.inputs[i + 1].frame - input.frame : 0;
            int sizeCode = delta == 0 ? 0 : delta <= 0xFF ? 1 : delta <= 0xFFFF ? 2 : 3;
            if (delta > 0xFFFFFFFF) throw BadFile("two inputs are too far apart for TCBot");
            w.byte(static_cast<uint8_t>((input.button & 3) | (input.down << 2) | (input.player2 << 3) | ((sizeCode << 1) << 5)));
            if (sizeCode) w.sized(delta, sizeCode == 3 ? 4 : static_cast<size_t>(sizeCode));
        }
        return std::move(w.data);
    }

    // yBot 2

    Macro readYBot(std::vector<uint8_t> const& data) {
        Reader r(data);
        if (r.string(4) != "ybot") throw BadFile("it isn't a yBot file");
        r.le<uint32_t>(); // version
        auto metaLength = r.le<uint32_t>();
        auto blobs = r.le<uint32_t>();
        Macro macro;
        auto metaStart = r.pos();
        // date, presses, frames, then the FPS
        if (metaLength >= 28) {
            r.seek(metaStart + 24);
            float fps = r.le<float>();
            if (fps > 0.f && std::isfinite(fps)) macro.fps = fps;
        }
        r.seek(metaStart);
        r.skip(metaLength);
        for (uint32_t i = 0; i < blobs; i++) r.skip(r.le<uint32_t>());

        uint64_t frame = 0;
        while (!r.atEnd()) {
            auto value = r.varint();
            frame += value >> 4;
            auto flags = value & 15;
            auto button = flags >> 2;
            // No button means the FPS changes
            if (button == 0) {
                float fps = r.le<float>();
                if (macro.inputs.empty() && fps > 0.f) macro.fps = fps;
                continue;
            }
            // The first bit is set for player 1
            macro.inputs.push_back({ frame, validButton(button), !(flags & 1), (flags & 2) != 0 });
        }
        return macro;
    }

    std::vector<uint8_t> writeYBot(Macro const& macro) {
        Writer w;
        w.text("ybot");
        w.le<uint32_t>(0); // version
        w.le<uint32_t>(36); // meta length
        w.le<uint32_t>(0); // blobs
        w.le<int64_t>(static_cast<int64_t>(std::time(nullptr)));
        w.le(static_cast<uint64_t>(macro.inputs.size()));
        w.le(macro.inputs.empty() ? uint64_t(0) : macro.inputs.back().frame + 1);
        w.le(static_cast<float>(macro.fps));
        w.le(static_cast<uint64_t>(macro.inputs.size()));
        uint64_t previous = 0;
        for (auto const& input : macro.inputs) {
            uint64_t flags = static_cast<uint64_t>(!input.player2) | (static_cast<uint64_t>(input.down) << 1) |
                (static_cast<uint64_t>(input.button) << 2);
            w.varint(((input.frame - previous) << 4) | flags);
            previous = input.frame;
        }
        return std::move(w.data);
    }

    // Frame Window: text, "FW1", the length, then "frame down button player2" lines

    Macro readFrameWindow(std::vector<uint8_t> const& data) {
        std::istringstream stream(std::string(data.begin(), data.end()));
        std::string line;
        std::vector<std::string> lines;
        while (std::getline(stream, line)) {
            if (!line.empty() && line.back() == '\r') line.pop_back();
            lines.push_back(line);
        }
        if (lines.size() < 3 || lines[0].rfind("FW", 0) != 0) throw BadFile("it isn't a Frame Window file");
        Macro macro;
        size_t count = std::stoul(lines[2]);
        if (count > lines.size() - 3) throw BadFile("it has fewer inputs than it says");
        for (size_t i = 0; i < count; i++) {
            std::istringstream fields(lines[3 + i]);
            uint64_t frame = 0;
            int down = 0, button = 1, player2 = 0;
            if (!(fields >> frame >> down >> button >> player2)) throw BadFile("an input line is broken");
            macro.inputs.push_back({ frame, validButton(button), player2 != 0, down != 0 });
        }
        for (auto const& rest : lines) {
            if (rest.rfind("tps ", 0) == 0) macro.fps = std::stod(rest.substr(4));
        }
        sortInputs(macro);
        return macro;
    }

    // Bots for GD 2.1 and before

    Macro readMegaHackJson(matjson::Value const& json) {
        Macro macro;
        macro.fps = number(json["meta"]["fps"], 240.0);
        auto const& events = json["events"];
        for (size_t i = 0; events.isArray() && i < events.size(); i++) {
            auto const& event = events[i];
            if (!event.contains("frame")) continue;
            macro.inputs.push_back({ whole(event["frame"]), validButton(event.contains("btn") ? whole(event["btn"]) : 1),
                flag(event["p2"]), flag(event["down"]) });
        }
        sortInputs(macro);
        return macro;
    }

    std::vector<uint8_t> writeMegaHackJson(Macro const& macro) {
        std::vector<matjson::Value> events;
        for (auto const& input : macro.inputs) {
            auto event = matjson::makeObject({ { "frame", input.frame }, { "down", input.down } });
            if (input.player2) event.set("p2", true);
            events.push_back(std::move(event));
        }
        auto replay = matjson::makeObject({
            { "meta", matjson::makeObject({ { "fps", macro.fps } }) },
            { "events", matjson::Value(std::move(events)) },
        });
        auto dumped = replay.dump();
        return std::vector<uint8_t>(dumped.begin(), dumped.end());
    }

    Macro readMegaHackBinary(std::vector<uint8_t> const& data) {
        if (looksLikeJson(data)) return readMegaHackJson(parseJson(data));
        Reader r(data);
        if (r.be<uint32_t>() != 0x4841434B) throw BadFile("it isn't a Mega Hack replay"); // "HACK"
        Macro macro;
        r.seek(12);
        macro.fps = r.le<uint32_t>();
        r.seek(28);
        auto count = r.le<uint32_t>();
        for (uint32_t i = 0; i < count; i++) {
            r.skip(2);
            bool down = r.byte() == 1;
            bool player2 = r.byte() != 0;
            auto frame = r.le<uint32_t>();
            r.skip(24);
            macro.inputs.push_back({ frame, 1, player2, down });
        }
        sortInputs(macro);
        return macro;
    }

    std::vector<uint8_t> writeMegaHackBinary(Macro const& macro) {
        Writer w;
        w.be<uint32_t>(0x4841434B);
        w.be<uint16_t>(1); // version
        w.zeros(6);
        w.le(static_cast<uint32_t>(std::lround(macro.fps)));
        w.zeros(12);
        w.le(static_cast<uint32_t>(macro.inputs.size()));
        for (auto const& input : macro.inputs) {
            w.zeros(2);
            w.byte(input.down);
            w.byte(input.player2);
            w.le(static_cast<uint32_t>(input.frame));
            w.zeros(24);
        }
        return std::move(w.data);
    }

    Macro readTASBot(matjson::Value const& json) {
        Macro macro;
        macro.fps = number(json["fps"], 60.0);
        auto const& frames = json["macro"];
        for (size_t i = 0; frames.isArray() && i < frames.size(); i++) {
            auto const& entry = frames[i];
            auto frame = whole(entry["frame"]);
            // 1 press, 2 release, 0 nothing
            for (bool player2 : { false, true }) {
                auto click = whole(entry[player2 ? "player_2" : "player_1"]["click"]);
                if (click == 1 || click == 2) macro.inputs.push_back({ frame, 1, player2, click == 1 });
            }
        }
        sortInputs(macro);
        return macro;
    }

    std::vector<uint8_t> writeTASBot(Macro const& macro) {
        std::vector<matjson::Value> frames;
        for (size_t i = 0; i < macro.inputs.size();) {
            auto frame = macro.inputs[i].frame;
            int clicks[2] = {};
            for (; i < macro.inputs.size() && macro.inputs[i].frame == frame; i++) {
                clicks[macro.inputs[i].player2] = macro.inputs[i].down ? 1 : 2;
            }
            frames.push_back(matjson::makeObject({
                { "frame", frame },
                { "player_1", matjson::makeObject({ { "click", clicks[0] } }) },
                { "player_2", matjson::makeObject({ { "click", clicks[1] } }) },
            }));
        }
        auto replay = matjson::makeObject({ { "fps", macro.fps }, { "macro", matjson::Value(std::move(frames)) } });
        auto dumped = replay.dump();
        return std::vector<uint8_t>(dumped.begin(), dumped.end());
    }

    Macro readEcho(std::vector<uint8_t> const& data) {
        if (!looksLikeJson(data)) throw BadFile("binary Echo files aren't supported, only Echo's JSON ones");
        auto json = parseJson(data);
        Macro macro;
        macro.fps = number(json["fps"], 60.0);
        auto const& inputs = json["inputs"];
        for (size_t i = 0; inputs.isArray() && i < inputs.size(); i++) {
            auto const& input = inputs[i];
            macro.inputs.push_back({ whole(input["frame"]), 1, flag(input["player_2"]), flag(input["holding"]) });
        }
        sortInputs(macro);
        return macro;
    }

    std::vector<uint8_t> writeEcho(Macro const& macro) {
        std::vector<matjson::Value> inputs;
        for (auto const& input : macro.inputs) {
            auto entry = matjson::makeObject({ { "frame", input.frame }, { "holding", input.down } });
            if (input.player2) entry.set("player_2", true);
            inputs.push_back(std::move(entry));
        }
        auto replay = matjson::makeObject({ { "fps", macro.fps }, { "inputs", matjson::Value(std::move(inputs)) } });
        auto dumped = replay.dump();
        return std::vector<uint8_t>(dumped.begin(), dumped.end());
    }

    Macro readZBot(std::vector<uint8_t> const& data) {
        Reader r(data);
        Macro macro;
        auto delta = r.le<float>();
        auto speedhack = r.le<float>();
        if (speedhack == 0.f) speedhack = 1.f;
        if (delta <= 0.f) throw BadFile("its frame length is broken");
        macro.fps = 1.0 / delta / speedhack;
        while (r.remaining() >= 6) {
            auto frame = r.le<int32_t>();
            bool down = r.byte() == 0x31;
            bool player1 = r.byte() == 0x31;
            macro.inputs.push_back({ static_cast<uint64_t>(std::max(frame, 0)), 1, !player1, down });
        }
        sortInputs(macro);
        return macro;
    }

    std::vector<uint8_t> writeZBot(Macro const& macro) {
        Writer w;
        w.le(static_cast<float>(1.0 / macro.fps));
        w.le(1.f); // speedhack
        for (auto const& input : macro.inputs) {
            w.le(static_cast<int32_t>(input.frame));
            w.byte(input.down ? 0x31 : 0x30);
            w.byte(input.player2 ? 0x30 : 0x31);
        }
        return std::move(w.data);
    }

    // xdBot before it used GDR: the FPS, then "frame|down|button|player1|..." lines
    Macro readXdBotOld(std::vector<uint8_t> const& data) {
        std::istringstream stream(std::string(data.begin(), data.end()));
        std::string line;
        Macro macro;
        while (std::getline(stream, line)) {
            if (!line.empty() && line.back() == '\r') line.pop_back();
            if (line.empty()) continue;
            std::vector<std::string> fields;
            std::istringstream parts(line);
            std::string field;
            while (std::getline(parts, field, '|')) fields.push_back(field);
            if (fields.size() == 1) {
                macro.fps = std::stod(fields[0]);
                continue;
            }
            if (fields.size() < 4) throw BadFile("an input line is broken");
            macro.inputs.push_back({ std::stoull(fields[0]), validButton(std::stoi(fields[2])), fields[3] != "1", fields[1] == "1" });
        }
        sortInputs(macro);
        return macro;
    }

    std::vector<uint8_t> writeXdBotOld(Macro const& macro) {
        std::string out = std::to_string(std::lround(macro.fps)) + "\n";
        for (auto const& input : macro.inputs) {
            out += std::to_string(input.frame) + "|" + (input.down ? "1" : "0") + "|" + std::to_string(input.button) + "|" +
                (input.player2 ? "0" : "1") + "|0|0|0|0|0|0|0|0|0|0|0|0|0\n";
        }
        return std::vector<uint8_t>(out.begin(), out.end());
    }

    std::vector<FormatInfo> const kFormats = {
        { Format::GDR, "GDR", ".gdr", "Mega Hack, xdBot, zBot, Prism Menu, iCreate Pro", true },
        { Format::GDR2, "GDR2", ".gdr2", "Eclipse", true },
        { Format::ReplayEngine3, "ReplayEngine 3", ".re3", "GDH", true },
        { Format::ReplayEngine4, "ReplayEngine 4", ".re4", "GDH (newer)", true },
        { Format::Silicate, "Silicate", ".slc", "Silicate", true },
        { Format::TCBot, "TCBot", ".tcm", "TCBot", true },
        { Format::YBot, "yBot 2", ".ybot", "yBot", true },
        { Format::GDRJson, "GDR as JSON", ".gdr.json", "Mega Hack, xdBot (readable text)", true },
        { Format::FrameWindow, "Frame Window", ".fwm", "Frame Window (open only)", false },
        { Format::MegaHackJson, "Mega Hack v7", ".mhr.json", "Mega Hack for GD 2.1", true },
        { Format::MegaHackBinary, "Mega Hack v7 binary", ".mhr", "Mega Hack for GD 2.1", true },
        { Format::TASBot, "TASBot", ".json", "TASBot (GD 2.1)", true },
        { Format::Echo, "Echo", ".echo", "Echo (GD 2.1)", true },
        { Format::ZBot, "zBot frame", ".zbf", "zBot for GD 2.1", true },
        { Format::XdBotOld, "xdBot old", ".xd", "xdBot before GDR", true },
        { Format::ReplayEngine, "ReplayEngine 1", ".re", "GDH (old, open only)", false },
        { Format::ReplayEngine2, "ReplayEngine 2", ".re2", "GDH (old, open only)", false },
    };

    std::string lower(std::string value) {
        std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        return value;
    }

    bool endsWith(std::string const& value, std::string_view ending) {
        return value.size() >= ending.size() && value.compare(value.size() - ending.size(), ending.size(), ending) == 0;
    }

    // Goes by the file's name, then by what's in it
    Format detect(std::vector<uint8_t> const& data, std::string const& fileName) {
        auto name = lower(fileName);
        if (startsWith(data, "GDR") && data.size() > 3 && data[3] == 2) return Format::GDR2;
        if (startsWith(data, "SILL") || startsWith(data, kSilicate3Header)) return Format::Silicate;
        if (startsWith(data, "ybot")) return Format::YBot;
        if (startsWith(data, "RE4")) return Format::ReplayEngine4;
        if (startsWith(data, "RE2")) return Format::ReplayEngine2;
        if (startsWith(data, "FW1")) return Format::FrameWindow;
        if (startsWith(data, "HACK")) return Format::MegaHackBinary;
        if (data.size() >= 16 && std::memcmp(data.data(), kTCBotHeader, 16) == 0) return Format::TCBot;

        // Longer endings first, ".gdr.json" before ".json"
        std::vector<FormatInfo const*> byEnding;
        for (auto const& format : kFormats) byEnding.push_back(&format);
        std::stable_sort(byEnding.begin(), byEnding.end(), [](FormatInfo const* a, FormatInfo const* b) {
            return std::strlen(a->extension) > std::strlen(b->extension);
        });
        for (auto format : byEnding) {
            if (!endsWith(name, format->extension)) continue;
            if (format->format == Format::TASBot || format->format == Format::GDR) break;
            return format->format;
        }

        if (looksLikeJson(data)) {
            auto json = parseJson(data);
            if (json.contains("macro")) return Format::TASBot;
            if (json.contains("events")) return Format::MegaHackJson;
            if (json.contains("inputs") && !json.contains("framerate") && !json.contains("bot") && json.contains("fps")) {
                return Format::Echo;
            }
            if (json.contains("inputs")) return Format::GDRJson;
            throw BadFile("it's JSON, but not from a bot GrassyHack knows");
        }
        // MessagePack starts with a map
        if (!data.empty() && ((data[0] & 0xF0) == 0x80 || data[0] == 0xDE || data[0] == 0xDF)) return Format::GDR;
        if (endsWith(name, ".gdr")) return Format::GDR;
        throw BadFile("GrassyHack doesn't know this kind of file");
    }

    Macro read(Format format, std::vector<uint8_t> const& data) {
        switch (format) {
            case Format::GDR: return readGDR(data);
            case Format::GDRJson: return readGDRJson(parseJson(data));
            case Format::GDR2: return readGDR2(data);
            case Format::ReplayEngine: return readReplayEngine(data);
            case Format::ReplayEngine2: return readReplayEngine2(data);
            case Format::ReplayEngine3: return readReplayEngine3(data);
            case Format::ReplayEngine4: return readReplayEngine4(data);
            case Format::Silicate: return readSilicate(data);
            case Format::TCBot: return readTCBot(data);
            case Format::YBot: return readYBot(data);
            case Format::FrameWindow: return readFrameWindow(data);
            case Format::MegaHackJson: return readMegaHackJson(parseJson(data));
            case Format::MegaHackBinary: return readMegaHackBinary(data);
            case Format::TASBot: return readTASBot(parseJson(data));
            case Format::Echo: return readEcho(data);
            case Format::ZBot: return readZBot(data);
            case Format::XdBotOld: return readXdBotOld(data);
        }
        throw BadFile("unknown format");
    }

    std::vector<uint8_t> write(Format format, Macro const& macro) {
        switch (format) {
            case Format::GDR: return writeGDR(macro, false);
            case Format::GDRJson: return writeGDR(macro, true);
            case Format::GDR2: return writeGDR2(macro);
            case Format::ReplayEngine3: return writeReplayEngine3(macro);
            case Format::ReplayEngine4: return writeReplayEngine4(macro);
            case Format::Silicate: return writeSilicate3(macro);
            case Format::TCBot: return writeTCBot(macro);
            case Format::YBot: return writeYBot(macro);
            case Format::MegaHackJson: return writeMegaHackJson(macro);
            case Format::MegaHackBinary: return writeMegaHackBinary(macro);
            case Format::TASBot: return writeTASBot(macro);
            case Format::Echo: return writeEcho(macro);
            case Format::ZBot: return writeZBot(macro);
            case Format::XdBotOld: return writeXdBotOld(macro);
            default: throw BadFile(std::string(info(format).name) + " files can only be opened, not made");
        }
    }
}

namespace grassy::macro {
    bool Macro::usesSideButtons() const {
        return std::any_of(inputs.begin(), inputs.end(), [](Input const& input) { return input.button != 1; });
    }

    double Macro::seconds() const {
        return inputs.empty() || fps <= 0.0 ? 0.0 : static_cast<double>(inputs.back().frame) / fps;
    }

    std::vector<FormatInfo> const& formats() {
        return kFormats;
    }

    FormatInfo const& info(Format format) {
        for (auto const& entry : kFormats) {
            if (entry.format == format) return entry;
        }
        return kFormats.front();
    }

    geode::Result<Macro> parse(std::vector<uint8_t> const& data, std::string const& fileName, Format* detected) {
        try {
            auto format = detect(data, fileName);
            if (detected) *detected = format;
            auto macro = read(format, data);
            if (!(macro.fps > 0.0) || !std::isfinite(macro.fps)) macro.fps = 240.0;
            return geode::Ok(std::move(macro));
        }
        catch (std::exception const& error) {
            return geode::Err(std::string(error.what()));
        }
    }

    geode::Result<Macro> load(std::filesystem::path const& path, Format* detected) {
        std::ifstream file(path, std::ios::binary);
        if (!file) return geode::Err("couldn't open the file");
        std::vector<uint8_t> data((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
        return parse(data, path.filename().string(), detected);
    }

    geode::Result<std::vector<uint8_t>> serialize(Macro const& macro, Format format) {
        try {
            return geode::Ok(write(format, macro));
        }
        catch (std::exception const& error) {
            return geode::Err(std::string(error.what()));
        }
    }

    geode::Result<> save(Macro const& macro, Format format, std::filesystem::path const& path) {
        auto data = serialize(macro, format);
        if (!data) return geode::Err(data.unwrapErr());
        std::ofstream file(path, std::ios::binary | std::ios::trunc);
        if (!file) return geode::Err("couldn't write the file");
        auto const& bytes = data.unwrap();
        file.write(reinterpret_cast<char const*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
        if (!file) return geode::Err("couldn't write the file");
        return geode::Ok();
    }

    std::string stem(std::filesystem::path const& path) {
        auto name = path.filename().string();
        auto lowered = lower(name);
        size_t longest = 0;
        for (auto const& format : kFormats) {
            size_t length = std::strlen(format.extension);
            if (length > longest && endsWith(lowered, format.extension)) longest = length;
        }
        return longest ? name.substr(0, name.size() - longest) : path.stem().string();
    }
}

namespace grassy::macro {
    std::vector<std::string> roundTrip(Macro const& macro) {
        // Formats from GD 2.1 bots only have the jump button
        auto jumpOnly = [](Format format) {
            return format == Format::MegaHackJson || format == Format::MegaHackBinary || format == Format::TASBot ||
                format == Format::Echo || format == Format::ZBot;
        };
        auto ordered = [](std::vector<Input> inputs, bool dropButtons) {
            if (dropButtons) {
                for (auto& input : inputs) input.button = 1;
            }
            std::stable_sort(inputs.begin(), inputs.end(), [](Input const& a, Input const& b) {
                return a.frame != b.frame ? a.frame < b.frame : a.player2 < b.player2;
            });
            return inputs;
        };

        std::vector<std::string> lines;
        for (auto const& format : kFormats) {
            if (!format.canWrite) continue;
            auto line = std::string(format.name) + ": ";
            auto data = serialize(macro, format.format);
            if (!data) {
                lines.push_back(line + "couldn't write: " + data.unwrapErr());
                continue;
            }
            Format detected;
            auto back = parse(data.unwrap(), std::string("test") + format.extension, &detected);
            if (!back) {
                lines.push_back(line + "couldn't read back: " + back.unwrapErr());
                continue;
            }
            auto expected = ordered(macro.inputs, jumpOnly(format.format));
            auto actual = ordered(back.unwrap().inputs, jumpOnly(format.format));
            size_t differences = expected.size() > actual.size() ? expected.size() - actual.size() : actual.size() - expected.size();
            for (size_t i = 0; i < std::min(expected.size(), actual.size()); i++) {
                if (!(expected[i] == actual[i])) differences++;
            }
            line += differences ? std::to_string(differences) + " of " + std::to_string(expected.size()) + " inputs differ"
                                : "same " + std::to_string(actual.size()) + " inputs";
            line += ", fps " + std::to_string(back.unwrap().fps);
            if (detected != format.format) line += ", read back as " + std::string(info(detected).name);
            lines.push_back(line);
        }
        return lines;
    }
}
