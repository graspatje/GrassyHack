#pragma once

#include <Geode/Geode.hpp>

#include <string>
#include <string_view>

// Every option in the menu, kept in the mod's saved values (saved.json in its
// save folder). The defaults are in Config.cpp. Keybinds are cocos key codes,
// KEY_None for no key.
namespace grassy::config {
    bool getBool(std::string_view key);
    void setBool(std::string_view key, bool value);
    int64_t getInt(std::string_view key);
    void setInt(std::string_view key, int64_t value);
    double getFloat(std::string_view key);
    void setFloat(std::string_view key, double value);
    std::string const& getString(std::string_view key);
    void setString(std::string_view key, std::string value);
    cocos2d::enumKeyCodes getKey(std::string_view key);
    void setKey(std::string_view key, cocos2d::enumKeyCodes value);
    // Geode saves when the game closes, this also does it when the menu closes
    void save();
}
