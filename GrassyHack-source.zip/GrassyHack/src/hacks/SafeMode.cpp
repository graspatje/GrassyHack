#include "../Config.hpp"
#include "../Hacks.hpp"
#include "../macro/Player.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>

using namespace geode::prelude;
using namespace grassy;

// Safe mode: an attempt where a cheat was on doesn't save progress (or no
// attempt does, with "always" on). GD already saves nothing in test mode (what
// playing from a start position is), so when such an attempt dies or beats the
// level, the level is put in test mode until the next restart.

namespace {
    // A cheat was on at some point in this attempt
    bool s_cheated = false;
    bool s_forcedTestMode = false;
    bool s_realTestMode = false;

    bool cheatOn() {
        return config::getBool("noclip") || speedhack::speed() != 1.f || stepper::isFrozen() || bot::isRunning() ||
            macro::state() == macro::State::Playing || config::getBool("autoclicker") || config::getBool("jump-hack") ||
            config::getBool("instant-complete") || config::getBool("force-platformer") || tps::changed();
    }

    void noteCheats() {
        if (cheatOn()) s_cheated = true;
    }

    void forceTestMode(PlayLayer* pl) {
        if (!config::getBool("safe-mode") || s_forcedTestMode) return;
        if (!s_cheated && !config::getBool("safe-mode.always")) return;
        s_realTestMode = pl->m_isTestMode;
        s_forcedTestMode = true;
        pl->m_isTestMode = true;
    }
}

namespace grassy::safemode {
    void beforeDeath(PlayLayer* pl) {
        noteCheats();
        forceTestMode(pl);
    }

    void restoreTestMode(PlayLayer* pl) {
        if (!s_forcedTestMode) return;
        s_forcedTestMode = false;
        pl->m_isTestMode = s_realTestMode;
    }
}

class $modify(SafeModePlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        s_cheated = false;
        s_forcedTestMode = false;
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;
        noteCheats();
        return true;
    }

    void resetLevel() {
        safemode::restoreTestMode(this);
        PlayLayer::resetLevel();
        // A new attempt only counts as cheated if a cheat is still on
        s_cheated = false;
        noteCheats();
    }

    void postUpdate(float dt) {
        PlayLayer::postUpdate(dt);
        noteCheats();
    }

    void levelComplete() {
        noteCheats();
        forceTestMode(this);
        PlayLayer::levelComplete();
    }

    void onQuit() {
        safemode::restoreTestMode(this);
        PlayLayer::onQuit();
    }
};
