#include "../Config.hpp"
#include "../Hacks.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>

#include <Windows.h>

using namespace geode::prelude;
using namespace grassy;

// TPS bypass: GD runs its physics 240 times a second. Two spots decide that:
// getModifiedDelta rounds each frame's time to whole 1/240 s ticks, and
// GJBaseGameLayer::update turns that time into a number of ticks by
// multiplying by 60 and then 4. getModifiedDelta is redone here with the
// chosen TPS, and update's "times 4" is pointed at a number of our own
// (4 * TPS / 240), which stays 4 while the bypass is off.

namespace {
    constexpr double kNormalTps = 240.0;
    // In GeometryDash.exe 2.2081: "mulsd xmm1, [4.0]" in GJBaseGameLayer::update
    constexpr uintptr_t kTickCountMultiply = 0x237A7C;
    constexpr size_t kInstructionLength = 8;

    // Lives within 2 GB of GD, so the patched instruction can reach it
    double* s_multiplier = nullptr;
    bool s_patched = false;

    // Memory close to GD's code, since x64 instructions only reach 2 GB away
    void* allocateNear(uintptr_t target, size_t size) {
        SYSTEM_INFO info;
        GetSystemInfo(&info);
        uintptr_t granularity = info.dwAllocationGranularity;
        uintptr_t start = target & ~(granularity - 1);
        for (uintptr_t offset = granularity; offset < 0x70000000; offset += granularity) {
            for (uintptr_t address : { start + offset, start - offset }) {
                if (void* memory = VirtualAlloc(reinterpret_cast<void*>(address), size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE)) {
                    return memory;
                }
            }
        }
        return nullptr;
    }

    void patchTickCount() {
        auto instruction = geode::base::get() + kTickCountMultiply;
        auto bytes = reinterpret_cast<uint8_t const*>(instruction);
        // Only patch the instruction it's meant for
        if (bytes[0] != 0xF2 || bytes[1] != 0x0F || bytes[2] != 0x59 || bytes[3] != 0x0D) {
            log::error("TPS bypass: GD's update isn't what it should be, so the TPS bypass stays off");
            return;
        }
        s_multiplier = static_cast<double*>(allocateNear(instruction, sizeof(double)));
        if (!s_multiplier) {
            log::error("TPS bypass: couldn't get memory near GD's code");
            return;
        }
        *s_multiplier = 4.0;
        auto next = instruction + kInstructionLength;
        auto distance = reinterpret_cast<intptr_t>(s_multiplier) - static_cast<intptr_t>(next);
        if (distance > INT32_MAX || distance < INT32_MIN) {
            log::error("TPS bypass: the memory is too far from GD's code");
            return;
        }
        auto displacement = static_cast<int32_t>(distance);
        ByteVector patch = { 0xF2, 0x0F, 0x59, 0x0D };
        auto raw = reinterpret_cast<uint8_t const*>(&displacement);
        patch.insert(patch.end(), raw, raw + 4);
        if (auto result = Mod::get()->patch(reinterpret_cast<void*>(instruction), patch); result.isErr()) {
            log::error("TPS bypass: couldn't patch GD: {}", result.unwrapErr());
            return;
        }
        s_patched = true;
    }
}

namespace grassy::tps {
    double value() {
        if (!s_patched || !config::getBool("tps.unlock")) return kNormalTps;
        return std::clamp(config::getFloat("tps.value"), 60.0, 1000.0);
    }

    bool changed() {
        return value() != kNormalTps;
    }
}

class $modify(TpsGameLayer, GJBaseGameLayer) {
    // GD's own, with the chosen TPS instead of 240
    double getModifiedDelta(float dt) {
        double tps = tps::value();
        if (s_multiplier) *s_multiplier = 4.0 * tps / kNormalTps;
        if (tps == kNormalTps) return GJBaseGameLayer::getModifiedDelta(dt);
        if (m_resumeTimer > 0) {
            m_resumeTimer--;
            dt = 0.f;
        }
        double step = static_cast<double>(std::min(1.f, m_gameState.m_timeWarp)) / tps;
        double total = static_cast<float>(static_cast<double>(dt) + m_extraDelta);
        int ticks = static_cast<int>(std::roundf(static_cast<float>(total / step)));
        m_extraDelta = total - ticks * step;
        return ticks * step;
    }
};

$on_mod(Loaded) {
    patchTickCount();
}
