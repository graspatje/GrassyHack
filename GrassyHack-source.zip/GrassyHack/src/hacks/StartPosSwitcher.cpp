#include "../Config.hpp"
#include "../Hacks.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/UILayer.hpp>
#include <Geode/ui/Notification.hpp>

#include <algorithm>
#include <vector>

using namespace geode::prelude;
using namespace grassy;

// Picks which start position the level starts from. The start positions are
// collected as the level loads, ordered left to right. Index -1 is the real
// start of the level, shown as 0. Starting from a start position is GD's test
// mode, which never saves progress.

namespace {
    constexpr int kStartPosObjectID = 31;

    std::vector<StartPosObject*> s_startPositions;
    bool s_sorted = true;
    int s_index = -1;

    void sortIfNeeded() {
        if (s_sorted) return;
        s_sorted = true;
        std::stable_sort(s_startPositions.begin(), s_startPositions.end(), [](StartPosObject* a, StartPosObject* b) {
            return a->getPositionX() < b->getPositionX();
        });
    }

    void forget() {
        s_startPositions.clear();
        s_sorted = true;
        s_index = -1;
    }

    bool shouldShowUI() {
        return config::getBool("startpos") && !config::getBool("startpos.hide-ui") && !s_startPositions.empty() && !bot::isRunning();
    }

    constexpr float kArrowScale = 0.55f;

    char const* arrowID(int direction) {
        return direction < 0 ? "previous" : "next";
    }

    // The arrows and "2/5" at the bottom of the screen. The arrows are plain
    // sprites, clicks on them are taken out in UILayer before they become a
    // jump (see StartPosUILayer).
    void updateUI(PlayLayer* pl) {
        if (!pl || !pl->m_uiLayer) return;
        auto node = pl->m_uiLayer->getChildByID("startpos-switcher"_spr);
        if (!shouldShowUI()) {
            if (node) node->setVisible(false);
            return;
        }
        if (!node) {
            node = CCNode::create();
            node->setID("startpos-switcher"_spr);
            auto size = CCDirector::get()->getWinSize();
            node->setPosition({ size.width / 2.f, 22.f });

            auto label = CCLabelBMFont::create("", "bigFont.fnt");
            label->setID("label");
            label->setScale(0.5f);
            node->addChild(label);

            for (int direction : { -1, 1 }) {
                auto arrow = CCSprite::createWithSpriteFrameName("GJ_arrow_01_001.png");
                arrow->setScale(kArrowScale);
                arrow->setFlipX(direction > 0);
                arrow->setPosition({ direction * 62.f, 0.f });
                arrow->setID(arrowID(direction));
                node->addChild(arrow);
            }
            pl->m_uiLayer->addChild(node, 1000);
        }
        node->setVisible(true);
        auto label = static_cast<CCLabelBMFont*>(node->getChildByID("label"));
        label->setString(fmt::format("{}/{}", s_index + 1, s_startPositions.size()).c_str());
        // The Labels window's transparency
        auto opacity = labels::opacity();
        label->setOpacity(opacity);
        for (int direction : { -1, 1 }) {
            static_cast<CCSprite*>(node->getChildByID(arrowID(direction)))->setOpacity(opacity);
        }
    }

    // The arrow (-1 left, 1 right) under a touch, or 0
    int arrowAt(UILayer* layer, CCPoint location) {
        auto node = layer->getChildByID("startpos-switcher"_spr);
        if (!node || !node->isVisible()) return 0;
        for (int direction : { -1, 1 }) {
            auto arrow = node->getChildByID(arrowID(direction));
            if (!arrow) continue;
            // A bit bigger than the arrow, it's small
            auto box = arrow->boundingBox();
            CCRect padded = { box.getMinX() - 6.f, box.getMinY() - 6.f, box.size.width + 12.f, box.size.height + 12.f };
            if (padded.containsPoint(node->convertToNodeSpace(location))) return direction;
        }
        return 0;
    }

    void bounce(UILayer* layer, int direction) {
        auto node = layer->getChildByID("startpos-switcher"_spr);
        auto arrow = node ? node->getChildByID(arrowID(direction)) : nullptr;
        if (!arrow) return;
        arrow->stopAllActions();
        arrow->setScale(kArrowScale * 1.25f);
        arrow->runAction(CCEaseBackOut::create(CCScaleTo::create(0.2f, kArrowScale)));
    }

    // Finds which start position GD picked when the level loaded
    void onLevelLoaded(PlayLayer* pl) {
        sortIfNeeded();
        auto found = std::find(s_startPositions.begin(), s_startPositions.end(), pl->m_startPosObject);
        s_index = found == s_startPositions.end() ? -1 : static_cast<int>(found - s_startPositions.begin());
        updateUI(pl);
    }

    void switchTo(PlayLayer* pl, int index) {
        int count = static_cast<int>(s_startPositions.size());
        if (index < -1) index = count - 1;
        if (index >= count) index = -1;
        s_index = index;
        auto target = index >= 0 ? s_startPositions[index] : nullptr;

        safemode::restoreTestMode(pl);
        pl->m_isTestMode = target != nullptr;
        pl->setStartPosObject(target);
        // Practice checkpoints from the old start would respawn you there
        if (pl->m_isPracticeMode) pl->removeAllCheckpoints();
        pl->m_currentCheckpoint = nullptr;
        pl->resetLevel();
        // A frozen level keeps its music paused
        if (!stepper::isFrozen()) pl->startMusic();
        pl->updateTestModeLabel();
        updateUI(pl);
    }

    bool switchBy(int direction) {
        auto pl = PlayLayer::get();
        if (!pl || !config::getBool("startpos") || s_startPositions.empty()) return false;
        if (pl->m_isPaused || pl->m_hasCompletedLevel || pl->m_levelEndAnimationStarted) return false;
        if (bot::isRunning()) {
            Notification::create("Stop the bot first", NotificationIcon::Warning)->show();
            return true;
        }
        sortIfNeeded();
        switchTo(pl, s_index + direction);
        return true;
    }
}

namespace grassy::startpos {
    bool previous() {
        return switchBy(-1);
    }

    bool next() {
        return switchBy(1);
    }

    void refresh() {
        updateUI(PlayLayer::get());
    }
}

class $modify(StartPosPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        forget();
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;
        onLevelLoaded(this);
        return true;
    }

    void addObject(GameObject* object) {
        PlayLayer::addObject(object);
        if (object->m_objectID != kStartPosObjectID) return;
        if (auto startPos = typeinfo_cast<StartPosObject*>(object)) {
            s_startPositions.push_back(startPos);
            s_sorted = false;
        }
    }

    // Big levels finish loading their objects after init
    void createObjectsFromSetupFinished() {
        PlayLayer::createObjectsFromSetupFinished();
        onLevelLoaded(this);
    }

    void onQuit() {
        forget();
        PlayLayer::onQuit();
    }
};

// UILayer turns clicks into jumps, so clicks on the arrows are taken out here
class $modify(StartPosUILayer, UILayer) {
    struct Fields {
        CCTouch* arrowTouch = nullptr;
    };

    bool ccTouchBegan(CCTouch* touch, CCEvent* event) {
        int direction = arrowAt(this, touch->getLocation());
        if (!direction) return UILayer::ccTouchBegan(touch, event);
        m_fields->arrowTouch = touch;
        bounce(this, direction);
        switchBy(direction);
        return true;
    }

    void ccTouchMoved(CCTouch* touch, CCEvent* event) {
        if (touch == m_fields->arrowTouch) return;
        UILayer::ccTouchMoved(touch, event);
    }

    void ccTouchEnded(CCTouch* touch, CCEvent* event) {
        if (touch == m_fields->arrowTouch) {
            m_fields->arrowTouch = nullptr;
            return;
        }
        UILayer::ccTouchEnded(touch, event);
    }

    void ccTouchCancelled(CCTouch* touch, CCEvent* event) {
        if (touch == m_fields->arrowTouch) {
            m_fields->arrowTouch = nullptr;
            return;
        }
        UILayer::ccTouchCancelled(touch, event);
    }
};
