#include "../Config.hpp"
#include "../Hacks.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/CCScheduler.hpp>

using namespace geode::prelude;
using namespace grassy;

// Speedhack: every frame's time goes through the scheduler, so scaling it
// there speeds up or slows down the whole game, menus included. The music
// follows by changing the pitch of FMOD's master channel group.

namespace {
    float s_appliedPitch = 1.f;

    void applyPitch(float pitch) {
        if (pitch == s_appliedPitch) return;
        auto engine = FMODAudioEngine::get();
        if (!engine || !engine->m_system) return;
        FMOD::ChannelGroup* master = nullptr;
        if (engine->m_system->getMasterChannelGroup(&master) != FMOD_OK || !master) return;
        master->setPitch(pitch);
        s_appliedPitch = pitch;
    }
}

namespace grassy::speedhack {
    float speed() {
        if (!config::getBool("speedhack")) return 1.f;
        return static_cast<float>(config::getFloat("speedhack.value"));
    }
}

class $modify(SpeedhackScheduler, CCScheduler) {
    void update(float dt) {
        menus::update();
        cosmetic::update();
        float speed = speedhack::speed();
        applyPitch(config::getBool("speedhack.audio") ? speed : 1.f);
        CCScheduler::update(dt * speed * menus::timeScale());
    }
};
