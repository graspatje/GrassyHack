#include "../Config.hpp"
#include "../Hacks.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>

#include <deque>
#include <unordered_map>

using namespace geode::prelude;
using namespace grassy;

// Seeing what the level is made of: hitboxes (GD's own practice mode
// hitboxes, shown in any mode), a trail of where the player's hitbox has
// been, the layout without decoration, and the triggers that are normally
// invisible while playing.

namespace {
    bool on(char const* key) {
        return config::getBool(key);
    }

    // The player's hitbox at each of the last ticks
    struct TrailBox {
        CCRect rect;
        bool player2 = false;
    };
    std::deque<TrailBox> s_trail;
    constexpr size_t kTrailLength = 240;

    // GrassyHack made GD's hitbox drawing node visible
    bool s_forcedHitboxes = false;

    bool showHitboxes(PlayLayer* pl) {
        if (on("hitboxes")) return true;
        return on("hitboxes.death") && pl->m_playerDied;
    }

    // Whether GD already draws its hitboxes this frame (practice mode's options)
    bool gameDraws(PlayLayer* pl) {
        return (pl->m_isDebugDrawEnabled && pl->m_isPracticeMode) || (pl->m_hitboxesOnDeath && pl->m_playerDied);
    }

    void drawTrail(PlayLayer* pl) {
        auto node = pl->m_debugDrawNode;
        for (size_t i = 0; i < s_trail.size(); i++) {
            auto const& box = s_trail[i];
            // Older boxes fade out
            float alpha = 0.15f + 0.6f * static_cast<float>(i + 1) / static_cast<float>(s_trail.size());
            ccColor4F border = box.player2 ? ccColor4F{ 0.35f, 0.9f, 1.f, alpha } : ccColor4F{ 1.f, 0.85f, 0.2f, alpha };
            auto const& r = box.rect;
            CCPoint corners[4] = {
                { r.getMinX(), r.getMinY() }, { r.getMaxX(), r.getMinY() }, { r.getMaxX(), r.getMaxY() }, { r.getMinX(), r.getMaxY() },
            };
            node->drawPolygon(corners, 4, { 0.f, 0.f, 0.f, 0.f }, 0.35f, border);
        }
    }

    void recordTrail(PlayLayer* pl) {
        if (!on("hitboxes.trail")) {
            s_trail.clear();
            return;
        }
        for (auto player : { pl->m_player1, pl->m_player2 }) {
            if (!player || player->m_isDead) continue;
            if (player == pl->m_player2 && !pl->m_gameState.m_isDualMode) continue;
            s_trail.push_back({ player->getObjectRect(), player == pl->m_player2 });
        }
        while (s_trail.size() > kTrailLength * 2) s_trail.pop_front();
    }

    // Show Layout: decoration is hidden and the background, ground and line
    // get GD's default colors, so only what you can touch is left
    bool isDecoration(GameObject* object) {
        if (object->m_isTrigger) return false;
        return object->m_objectType == GameObjectType::Decoration;
    }

    // Show Triggers: a copy of each trigger's editor icon, since GD doesn't
    // draw triggers while playing
    CCNode* s_triggerLayer = nullptr;
    std::unordered_map<CCTexture2D*, CCSpriteBatchNode*> s_triggerBatches;

    void addTriggerIcon(PlayLayer* pl, GameObject* object) {
        auto frame = object->displayFrame();
        if (!frame || !frame->getTexture()) return;
        if (!s_triggerLayer) {
            s_triggerLayer = CCNode::create();
            s_triggerLayer->setID("triggers"_spr);
            pl->m_objectLayer->addChild(s_triggerLayer, 9999);
        }
        auto texture = frame->getTexture();
        auto& batch = s_triggerBatches[texture];
        if (!batch) {
            batch = CCSpriteBatchNode::createWithTexture(texture);
            s_triggerLayer->addChild(batch);
        }
        auto sprite = CCSprite::createWithSpriteFrame(frame);
        sprite->setPosition(object->getPosition());
        sprite->setRotation(object->getRotation());
        sprite->setScaleX(object->getScaleX());
        sprite->setScaleY(object->getScaleY());
        sprite->setOpacity(200);
        batch->addChild(sprite);
    }
}

class $modify(HitboxPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        s_trail.clear();
        s_forcedHitboxes = false;
        s_triggerLayer = nullptr;
        s_triggerBatches.clear();
        return PlayLayer::init(level, useReplay, dontCreateObjects);
    }

    void addObject(GameObject* object) {
        if (on("layout") && isDecoration(object)) {
            object->m_isHide = true;
        }
        PlayLayer::addObject(object);
        if (on("show-triggers") && object->m_isTrigger && m_objectLayer) addTriggerIcon(this, object);
    }

    void updateVisibility(float dt) {
        PlayLayer::updateVisibility(dt);
        if (on("layout")) {
            if (m_middleground) m_middleground->setVisible(false);
        }
        if (s_triggerLayer) s_triggerLayer->setVisible(on("show-triggers"));

        auto node = m_debugDrawNode;
        if (!node) return;
        bool show = showHitboxes(this);
        bool trail = on("hitboxes.trail") && !s_trail.empty();
        if (!show && !trail) {
            if (s_forcedHitboxes && !gameDraws(this)) {
                node->clear();
                node->setVisible(false);
            }
            s_forcedHitboxes = false;
            return;
        }
        s_forcedHitboxes = true;
        node->setVisible(true);
        if (show) {
            // GD draws its hitboxes here in practice mode, otherwise it's done for it
            if (!gameDraws(this)) updateDebugDraw();
        }
        else if (!gameDraws(this)) {
            node->clear();
        }
        if (trail) drawTrail(this);
    }

    void resetLevel() {
        PlayLayer::resetLevel();
        s_trail.clear();
    }
};

class $modify(HitboxGameLayer, GJBaseGameLayer) {
    void processCommands(float dt, bool isHalfTick, bool isLastTick) {
        GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
        auto pl = PlayLayer::get();
        if (pl == static_cast<GJBaseGameLayer*>(this)) recordTrail(pl);
    }

    // Layout: the colors of the background (1000), ground (1001, 1009),
    // line (1002) and middleground (1013, 1014)
    void updateColor(ccColor3B& color, float fadeTime, int colorID, bool blending, float opacity, ccHSVValue& copyHSV,
            int colorIDToCopy, bool copyOpacity, EffectGameObject* callerObject, int unk1, int unk2) {
        if (on("layout") && PlayLayer::get() == static_cast<GJBaseGameLayer*>(this)) {
            switch (colorID) {
                case 1000: color = { 40, 125, 255 }; break;
                case 1001: case 1009: color = { 0, 102, 255 }; break;
                case 1002: color = { 255, 255, 255 }; break;
                default: break;
            }
        }
        GJBaseGameLayer::updateColor(color, fadeTime, colorID, blending, opacity, copyHSV, colorIDToCopy, copyOpacity, callerObject,
            unk1, unk2);
    }
};
