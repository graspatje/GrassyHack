#include "../Config.hpp"
#include "../Hacks.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/BitmapFontCache.hpp>
#include <Geode/modify/LabelGameObject.hpp>
#include <Geode/modify/TextGameObject.hpp>

#include <Windows.h>

#include <algorithm>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <vector>

// Dear ImGui's copy of stb_truetype, kept to this file
#define STBTT_STATIC
#define STB_TRUETYPE_IMPLEMENTATION
#include <imstb_truetype.h>

using namespace geode::prelude;
using namespace grassy;

// Custom Font: GD's text is made of bitmap fonts (a picture of every letter
// plus a .fnt file saying where each one is). This draws those from a .ttf or
// .otf font on the PC, with GD's black outline, shadow and gold colors, saves
// them in the mod's save folder, and hands them to GD whenever it loads one of
// its own three fonts. Text objects in levels keep the creator's font.

namespace {
    // One of GD's fonts. Sizes are in points, measured from GD's own files.
    struct Style {
        char const* gdFile;
        char const* tag;
        float lineHeight;
        // From the top of a line to where the letters stand
        float baseline;
        float capHeight;
        float outline;
        // How far the shadow sits down and to the right
        float shadow;
        float shadowAlpha;
        bool gold;
    };

    constexpr Style kStyles[] = {
        { "bigFont.fnt", "big", 32.5f, 28.f, 19.5f, 1.25f, 2.f, 0.4f, false },
        { "goldFont.fnt", "gold", 26.f, 23.f, 15.75f, 1.f, 1.75f, 0.3f, true },
        { "chatFont.fnt", "chat", 16.5f, 13.5f, 10.75f, 0.f, 0.f, 0.f, false },
    };

    // Goes up when the drawing changes, so old saved fonts aren't used
    constexpr int kVersion = 1;
    constexpr int kFirstChar = 32;
    constexpr int kLastChar = 126;

    // Above zero while GD makes the text of a text object in a level
    int s_levelText = 0;

    // The saved font for each style, for the settings in s_madeFor
    std::string s_made[std::size(kStyles)];
    std::string s_madeFor[std::size(kStyles)];
    // The settings the font couldn't be made for
    std::string s_failedFor;

    struct Glyph {
        int code = 0;
        int width = 0;
        int height = 0;
        int xOffset = 0;
        int yOffset = 0;
        int xAdvance = 0;
        int x = 0;
        int y = 0;
        std::vector<uint8_t> pixels;
    };

    int nextPowerOfTwo(int value) {
        int result = 1;
        while (result < value) result *= 2;
        return result;
    }

    float clamp01(float value) {
        return std::clamp(value, 0.f, 1.f);
    }

    // A letter's picture: the fill, then for GD's look a black outline around
    // it and a see-through shadow down and to the right
    void drawGlyph(Glyph& glyph, stbtt_fontinfo const& font, Style const& style, float scale, float pixelsPerPoint,
            float capTop, float baseline) {
        int x0, y0, x1, y1;
        stbtt_GetCodepointBitmapBox(&font, glyph.code, scale, scale, &x0, &y0, &x1, &y1);
        int fillWidth = x1 - x0;
        int fillHeight = y1 - y0;
        if (fillWidth <= 0 || fillHeight <= 0) return;
        std::vector<uint8_t> fill(fillWidth * fillHeight);
        stbtt_MakeCodepointBitmap(&font, fill.data(), fillWidth, fillHeight, fillWidth, scale, scale, glyph.code);

        float outline = style.outline * pixelsPerPoint;
        int shadow = static_cast<int>(std::lround(style.shadow * pixelsPerPoint));
        int pad = outline > 0.f ? static_cast<int>(std::ceil(outline)) + shadow + 2 : 1;
        int width = fillWidth + 2 * pad;
        int height = fillHeight + 2 * pad;
        auto fillAt = [&](int x, int y) {
            x -= pad;
            y -= pad;
            if (x < 0 || y < 0 || x >= fillWidth || y >= fillHeight) return 0.f;
            return fill[y * fillWidth + x] / 255.f;
        };

        // The outline: the fill grown by the outline's width, with soft edges
        std::vector<float> shape(width * height);
        int reach = static_cast<int>(std::ceil(outline)) + 1;
        struct Offset {
            int x;
            int y;
            float weight;
        };
        std::vector<Offset> offsets;
        for (int dy = -reach; dy <= reach; dy++) {
            for (int dx = -reach; dx <= reach; dx++) {
                float weight = clamp01(outline + 0.5f - std::sqrt(static_cast<float>(dx * dx + dy * dy)));
                if (weight > 0.f) offsets.push_back({ dx, dy, weight });
            }
        }
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                float alpha = fillAt(x, y);
                if (outline > 0.f) {
                    for (auto const& offset : offsets) {
                        alpha = std::max(alpha, fillAt(x + offset.x, y + offset.y) * offset.weight);
                    }
                }
                shape[y * width + x] = alpha;
            }
        }
        auto shapeAt = [&](int x, int y) {
            if (x < 0 || y < 0 || x >= width || y >= height) return 0.f;
            return shape[y * width + x];
        };

        glyph.width = width;
        glyph.height = height;
        glyph.xOffset = x0 - pad;
        glyph.yOffset = static_cast<int>(std::lround(baseline)) + y0 - pad;
        glyph.pixels.assign(width * height * 4, 0);
        for (int y = 0; y < height; y++) {
            // Gold goes from orange at the top of the capitals to yellow where they stand
            float down = clamp01((glyph.yOffset + y - capTop) / std::max(baseline - capTop, 1.f));
            float red = 255.f;
            float green = style.gold ? 160.f + (227.f - 160.f) * down : 255.f;
            float blue = style.gold ? 11.f + (72.f - 11.f) * down : 255.f;
            for (int x = 0; x < width; x++) {
                float fillAlpha = fillAt(x, y);
                float back = style.outline > 0.f ? shapeAt(x, y) : 0.f;
                if (style.shadowAlpha > 0.f) {
                    float shade = shapeAt(x - shadow, y - shadow) * style.shadowAlpha;
                    back = back + shade * (1.f - back);
                }
                // The fill over the black outline and shadow
                float alpha = fillAlpha + back * (1.f - fillAlpha);
                auto pixel = &glyph.pixels[(y * width + x) * 4];
                if (alpha <= 0.f) continue;
                float mix = fillAlpha / alpha;
                pixel[0] = static_cast<uint8_t>(std::lround(red * mix));
                pixel[1] = static_cast<uint8_t>(std::lround(green * mix));
                pixel[2] = static_cast<uint8_t>(std::lround(blue * mix));
                pixel[3] = static_cast<uint8_t>(std::lround(alpha * 255.f));
            }
        }
    }

    // Puts the letters next to each other in rows, tallest first. Returns the
    // picture's height, or 0 if they don't fit in the width.
    int packGlyphs(std::vector<Glyph*> const& glyphs, int width) {
        int x = 1;
        int y = 1;
        int rowHeight = 0;
        for (auto glyph : glyphs) {
            if (glyph->width + 2 > width) return 0;
            if (x + glyph->width + 1 > width) {
                x = 1;
                y += rowHeight + 1;
                rowHeight = 0;
            }
            glyph->x = x;
            glyph->y = y;
            x += glyph->width + 1;
            rowHeight = std::max(rowHeight, glyph->height);
        }
        return y + rowHeight + 1;
    }

    // Draws a whole font and saves it as fntPath and pngPath
    bool makeFont(std::vector<unsigned char> const& data, Style const& style, float size, std::filesystem::path const& fntPath,
            std::filesystem::path const& pngPath) {
        stbtt_fontinfo font;
        int offset = stbtt_GetFontOffsetForIndex(data.data(), 0);
        if (offset < 0 || !stbtt_InitFont(&font, data.data(), offset)) return false;

        // GD's fonts are drawn for its texture quality, 4 pixels per point on high
        float pixelsPerPoint = CCDirector::get()->getContentScaleFactor();
        // Sized so capital letters are as tall as in GD's font
        int box[4];
        float capUnits = 0.f;
        if (stbtt_GetCodepointBox(&font, 'H', &box[0], &box[1], &box[2], &box[3]) && box[3] > 0) {
            capUnits = static_cast<float>(box[3]);
        }
        else {
            int ascent, descent, gap;
            stbtt_GetFontVMetrics(&font, &ascent, &descent, &gap);
            capUnits = ascent * 0.7f;
        }
        if (capUnits <= 0.f) return false;
        float capPixels = style.capHeight * pixelsPerPoint * size;
        float scale = capPixels / capUnits;
        float baseline = style.baseline * pixelsPerPoint;
        float capTop = baseline - capPixels;
        float outline = style.outline * pixelsPerPoint;

        std::vector<Glyph> glyphs;
        for (int code = kFirstChar; code <= kLastChar; code++) {
            if (code != ' ' && !stbtt_FindGlyphIndex(&font, code)) continue;
            Glyph glyph;
            glyph.code = code;
            int advance, bearing;
            stbtt_GetCodepointHMetrics(&font, code, &advance, &bearing);
            glyph.xAdvance = static_cast<int>(std::lround(advance * scale + outline));
            drawGlyph(glyph, font, style, scale, pixelsPerPoint, capTop, baseline);
            glyphs.push_back(std::move(glyph));
        }
        if (glyphs.size() < 2) return false;

        std::vector<Glyph*> order;
        size_t area = 0;
        for (auto& glyph : glyphs) {
            if (glyph.width <= 0) continue;
            order.push_back(&glyph);
            area += static_cast<size_t>(glyph.width + 1) * (glyph.height + 1);
        }
        std::stable_sort(order.begin(), order.end(), [](Glyph* a, Glyph* b) { return a->height > b->height; });
        int width = std::max(64, nextPowerOfTwo(static_cast<int>(std::sqrt(static_cast<double>(area)) * 1.1)));
        int height = 0;
        while (width <= 8192) {
            int used = packGlyphs(order, width);
            if (used > 0 && used <= width * 2) {
                height = nextPowerOfTwo(used);
                break;
            }
            width *= 2;
        }
        if (!height) return false;

        std::vector<uint8_t> picture(static_cast<size_t>(width) * height * 4, 0);
        for (auto glyph : order) {
            for (int y = 0; y < glyph->height; y++) {
                std::copy_n(&glyph->pixels[y * glyph->width * 4], glyph->width * 4,
                    &picture[((glyph->y + y) * static_cast<size_t>(width) + glyph->x) * 4]);
            }
        }

        std::error_code error;
        std::filesystem::create_directories(fntPath.parent_path(), error);
        auto image = new CCImage();
        bool saved = image->initWithImageData(picture.data(), static_cast<int>(picture.size()), CCImage::kFmtRawData, width,
            height, 8) && image->saveToFile(pngPath.generic_string().c_str(), false);
        image->release();
        if (!saved) return false;

        // The .fnt file, in the same layout as GD's own
        std::string text = fmt::format("info face=\"GrassyHack\" size={} bold=0 italic=0 charset=\"\" unicode=0 stretchH=100 "
            "smooth=1 aa=1 padding=0,0,0,0 spacing=1,1\n", static_cast<int>(std::lround(capPixels)));
        text += fmt::format("common lineHeight={} base={} scaleW={} scaleH={} pages=1 packed=0\n",
            static_cast<int>(std::lround(style.lineHeight * pixelsPerPoint)), static_cast<int>(std::lround(baseline)), width,
            height);
        text += fmt::format("page id=0 file=\"{}\"\n", pngPath.filename().string());
        text += fmt::format("chars count={}\n", glyphs.size());
        for (auto const& glyph : glyphs) {
            text += fmt::format("char id={} x={} y={} width={} height={} xoffset={} yoffset={} xadvance={} page=0 chnl=0\n",
                glyph.code, glyph.x, glyph.y, glyph.width, glyph.height, glyph.xOffset, glyph.yOffset, glyph.xAdvance);
        }
        std::string kernings;
        int kerningCount = 0;
        for (auto const& first : glyphs) {
            for (auto const& second : glyphs) {
                int amount = static_cast<int>(std::lround(stbtt_GetCodepointKernAdvance(&font, first.code, second.code) * scale));
                if (!amount) continue;
                kernings += fmt::format("kerning first={} second={} amount={}\n", first.code, second.code, amount);
                kerningCount++;
            }
        }
        text += fmt::format("kernings count={}\n", kerningCount);
        text += kernings;
        std::ofstream file(fntPath, std::ios::binary);
        file << text;
        return static_cast<bool>(file);
    }

    std::string settingsKey() {
        return fmt::format("{}|{:.2f}|{}|{}", config::getString("font.file"), config::getFloat("font.size"),
            CCDirector::get()->getContentScaleFactor(), kVersion);
    }

    // The saved font to use instead of one of GD's, made if needed. Empty when
    // GD's own should be used.
    std::string replacementFor(char const* file) {
        std::string_view name = file;
        size_t index = 0;
        while (index < std::size(kStyles) && name != kStyles[index].gdFile) index++;
        if (index == std::size(kStyles)) return {};
        auto const& fontFile = config::getString("font.file");
        if (fontFile.empty()) return {};

        auto key = settingsKey();
        if (s_madeFor[index] == key) return s_made[index];
        if (s_failedFor == key) return {};
        s_madeFor[index] = key;
        s_made[index].clear();

        auto const& style = kStyles[index];
        auto folder = Mod::get()->getSaveDir() / "fonts";
        auto name64 = fmt::format("{:016x}-{}", std::hash<std::string>()(key), style.tag);
        auto fntPath = folder / (name64 + ".fnt");
        auto pngPath = folder / (name64 + ".png");
        std::error_code error;
        if (!std::filesystem::exists(fntPath, error) || !std::filesystem::exists(pngPath, error)) {
            std::ifstream input(std::filesystem::path(fontFile), std::ios::binary);
            std::vector<unsigned char> data((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
            if (data.empty() || !makeFont(data, style, static_cast<float>(config::getFloat("font.size")), fntPath, pngPath)) {
                log::warn("Couldn't make a font from {}", fontFile);
                s_failedFor = key;
                return {};
            }
            // Fonts made for other settings aren't needed anymore
            for (auto const& entry : std::filesystem::directory_iterator(folder, error)) {
                auto stem = entry.path().stem().string();
                bool current = false;
                for (auto const& made : s_madeFor) {
                    if (!made.empty() && stem.starts_with(fmt::format("{:016x}-", std::hash<std::string>()(made)))) current = true;
                }
                if (!current) std::filesystem::remove(entry.path(), error);
            }
        }
        // cocos finds the picture next to the .fnt by looking for the last "/"
        s_made[index] = fntPath.generic_string();
        return s_made[index];
    }

    CCBMFontConfiguration* loadFontConfig(char const* file) {
        if (file && s_levelText == 0 && config::getBool("font")) {
            auto replacement = replacementFor(file);
            if (!replacement.empty()) {
                if (auto made = FNTConfigLoadFile(replacement.c_str())) return made;
                log::warn("GD couldn't read the font made from {}", config::getString("font.file"));
                s_failedFor = settingsKey();
            }
        }
        return FNTConfigLoadFile(file);
    }
}

namespace grassy::fonts {
    bool failed() {
        return !config::getString("font.file").empty() && s_failedFor == settingsKey();
    }
}

// Every label in GD gets its font through FNTConfigLoadFile in libcocos2d
$execute {
    auto cocos = GetModuleHandleW(L"libcocos2d.dll");
    auto address = cocos ? GetProcAddress(cocos, "?FNTConfigLoadFile@cocos2d@@YAPEAVCCBMFontConfiguration@1@PEBD@Z") : nullptr;
    if (!address) {
        log::error("Couldn't find FNTConfigLoadFile, Custom Font won't work");
        return;
    }
    auto hook = Mod::get()->hook(reinterpret_cast<void*>(address), &loadFontConfig, "cocos2d::FNTConfigLoadFile");
    if (hook.isErr()) log::error("Couldn't hook FNTConfigLoadFile: {}", hook.unwrapErr());
}

// Wrapped text (TextArea) gets its letter widths from GD's own reading of the
// .fnt file, so that's pointed at the made font too
class $modify(FontWidthCache, BitmapFontCache) {
    FontObject* fontWithConfigFile(char const* font, float scale) {
        if (font && s_levelText == 0 && config::getBool("font")) {
            auto replacement = replacementFor(font);
            if (!replacement.empty()) return BitmapFontCache::fontWithConfigFile(replacement.c_str(), scale);
        }
        return BitmapFontCache::fontWithConfigFile(font, scale);
    }
};

class $modify(FontTextObject, TextGameObject) {
    void updateTextObject(gd::string text, bool defaultFont) {
        s_levelText++;
        TextGameObject::updateTextObject(text, defaultFont);
        s_levelText--;
    }
};

class $modify(FontLabelObject, LabelGameObject) {
    void createLabel(gd::string text) {
        s_levelText++;
        LabelGameObject::createLabel(text);
        s_levelText--;
    }
};
