#include "../Config.hpp"
#include "../Hacks.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/CCParticleBatchNode.hpp>
#include <Geode/modify/CCParticleSystemQuad.hpp>
#include <Geode/modify/FMODAudioEngine.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/HardStreak.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PlayerObject.hpp>
#include <Geode/modify/RingObject.hpp>
#include <Geode/modify/ShaderLayer.hpp>

#include <random>
#include <unordered_map>

using namespace geode::prelude;
using namespace grassy;

// Things that only change how a level looks: effects turned off, trails,
// which player is drawn on top, random icons, the exact percentage, the total
// attempts, the music's pitch. None of them change how the level plays,
// except Stop Triggers On Death, which freezes the level while you're dead.

namespace {
    bool on(char const* key) {
        return config::getBool(key);
    }

    bool inLevel() {
        return PlayLayer::get() != nullptr;
    }

    // One of the players of the level being played (not the main menu's)
    bool levelPlayer(PlayerObject* player) {
        auto pl = PlayLayer::get();
        return pl && (player == pl->m_player1 || player == pl->m_player2);
    }

    // Trails and fire sprites

    // An option touched the trails, so they need putting back when it's off
    bool s_trailsTouched = false;

    void setVisible(CCNode* node, bool visible) {
        if (node && node->isVisible() != visible) node->setVisible(visible);
    }

    void applyTrails(PlayLayer* pl) {
        bool hide = on("cosmetic.hide-player");
        bool noTrail = on("cosmetic.no-trail");
        bool noWaveTrail = on("cosmetic.no-wave-trail");
        bool noTrailBehindWave = on("cosmetic.no-trail-behind-wave");
        bool any = hide || noTrail || noWaveTrail || noTrailBehindWave;
        if (!any && !s_trailsTouched) return;
        s_trailsTouched = any;
        for (auto player : { pl->m_player1, pl->m_player2 }) {
            if (!player) continue;
            setVisible(player->m_regularTrail, !(hide || noTrail || (noTrailBehindWave && player->m_isDart)));
            setVisible(player->m_waveTrail, !(hide || noWaveTrail));
            setVisible(player->m_shipStreak, !hide);
        }
    }

    // Hide Player

    bool s_playersHidden = false;

    void applyHidden(PlayLayer* pl) {
        bool hide = on("cosmetic.hide-player");
        if (hide) {
            setVisible(pl->m_player1, false);
            setVisible(pl->m_player2, false);
            s_playersHidden = true;
        }
        else if (s_playersHidden) {
            s_playersHidden = false;
            setVisible(pl->m_player1, !pl->m_player1->m_isDead);
            setVisible(pl->m_player2, pl->m_gameState.m_isDualMode && !pl->m_player2->m_isDead);
        }
    }

    void applyEffects(PlayLayer* pl) {
        for (auto player : { pl->m_player1, pl->m_player2 }) {
            if (!player) continue;
            if (on("cosmetic.no-dash-fire")) setVisible(player->m_dashFireSprite, false);
            if (on("cosmetic.no-robot-fire")) setVisible(player->m_robotFire, false);
            if (on("cosmetic.no-swing-fire")) {
                setVisible(player->m_swingFireMiddle, false);
                setVisible(player->m_swingFireBottom, false);
                setVisible(player->m_swingFireTop, false);
            }
            player->m_alwaysShowStreak = on("cosmetic.trail-always");
        }
    }

    // Which player is drawn on top

    struct DrawOrder {
        int player1 = 0;
        int player2 = 0;
        bool saved = false;
    };
    DrawOrder s_order;

    void applyDrawOrder(PlayLayer* pl) {
        auto p1 = pl->m_player1;
        auto p2 = pl->m_player2;
        if (!p1 || !p2) return;
        if (!s_order.saved) s_order = { p1->getZOrder(), p2->getZOrder(), true };
        int z1 = s_order.player1;
        int z2 = s_order.player2;
        if (on("cosmetic.icon-on-top") && p1->getParent()) {
            // Above everything else in the layer the players are in
            int top = INT_MIN;
            for (auto child : CCArrayExt<CCNode*>(p1->getParent()->getChildren())) {
                if (child != p1 && child != p2) top = std::max(top, child->getZOrder());
            }
            if (top != INT_MIN) {
                z1 = std::max(z1, top + 1);
                z2 = std::max(z2, top + 1);
            }
        }
        if (on("cosmetic.p1-on-top")) z1 = std::max(z1, z2 + 1);
        else if (on("cosmetic.p2-on-top")) z2 = std::max(z2, z1 + 1);
        if (p1->getZOrder() != z1) p1->setZOrder(z1);
        if (p2->getParent() && p2->getZOrder() != z2) p2->setZOrder(z2);
    }

    // Icon Randomizer: the level's players get random icons and colors when
    // the level opens

    struct RandomIcons {
        int cube = 1, ship = 1, ball = 1, ufo = 1, wave = 1, robot = 1, spider = 1, swing = 1, jetpack = 1;
        int color1 = 0, color2 = 3;
    };
    RandomIcons s_icons;
    // The level is being set up, which is when its players get their icons
    bool s_settingUpLevel = false;

    std::mt19937& random() {
        static std::mt19937 s_random{ std::random_device{}() };
        return s_random;
    }

    // A random icon you have unlocked
    int randomIcon(IconType type) {
        auto gm = GameManager::get();
        std::vector<int> unlocked;
        int count = gm->countForType(type);
        for (int id = 1; id <= count; id++) {
            if (gm->isIconUnlocked(id, type)) unlocked.push_back(id);
        }
        if (unlocked.empty()) return 1;
        return unlocked[std::uniform_int_distribution<size_t>(0, unlocked.size() - 1)(random())];
    }

    int randomColor(UnlockType type) {
        auto gm = GameManager::get();
        std::vector<int> unlocked;
        // GD has colors 0 to 106
        for (int id = 0; id <= 106; id++) {
            if (gm->isColorUnlocked(id, type)) unlocked.push_back(id);
        }
        if (unlocked.empty()) return 0;
        return unlocked[std::uniform_int_distribution<size_t>(0, unlocked.size() - 1)(random())];
    }

    void rollIcons() {
        s_icons.cube = randomIcon(IconType::Cube);
        s_icons.ship = randomIcon(IconType::Ship);
        s_icons.ball = randomIcon(IconType::Ball);
        s_icons.ufo = randomIcon(IconType::Ufo);
        s_icons.wave = randomIcon(IconType::Wave);
        s_icons.robot = randomIcon(IconType::Robot);
        s_icons.spider = randomIcon(IconType::Spider);
        s_icons.swing = randomIcon(IconType::Swing);
        s_icons.jetpack = randomIcon(IconType::Jetpack);
        s_icons.color1 = randomColor(UnlockType::Col1);
        s_icons.color2 = randomColor(UnlockType::Col2);
    }

    // Players of a level, also while the level is still being set up
    bool randomizing(PlayerObject* player) {
        if (!on("cosmetic.icon-randomizer")) return false;
        return s_settingUpLevel || (player->m_gameLayer && typeinfo_cast<PlayLayer*>(player->m_gameLayer));
    }

    // Pitch shifter: an FMOD pitch shift effect on the music

    FMOD::DSP* s_pitchShift = nullptr;
    FMOD::ChannelGroup* s_pitchGroup = nullptr;

    void applyPitchShift() {
        bool shifting = on("cosmetic.pitch");
        auto engine = FMODAudioEngine::get();
        if (!engine || !engine->m_system || !engine->m_backgroundMusicChannel) return;
        if (!shifting && !s_pitchShift) return;
        if (!s_pitchShift) {
            if (engine->m_system->createDSPByType(FMOD_DSP_TYPE_PITCHSHIFT, &s_pitchShift) != FMOD_OK) {
                s_pitchShift = nullptr;
                return;
            }
        }
        if (s_pitchGroup != engine->m_backgroundMusicChannel) {
            if (s_pitchGroup) s_pitchGroup->removeDSP(s_pitchShift);
            s_pitchGroup = engine->m_backgroundMusicChannel;
            s_pitchGroup->addDSP(0, s_pitchShift);
        }
        float pitch = static_cast<float>(std::clamp(config::getFloat("cosmetic.pitch.value"), 0.5, 2.0));
        s_pitchShift->setParameterFloat(FMOD_DSP_PITCHSHIFT_PITCH, pitch);
        s_pitchShift->setBypass(!shifting);
    }

    std::unordered_map<StartPosObject*, bool> s_startPosResetCamera;

    // The wave trail's width is multiplied by m_pulseSize, which GD sets from
    // the music: 1 is the plain width. GD's own value is kept so it isn't
    // scaled twice when GD hasn't set a new one.
    struct WavePulse {
        float game = 1.f;
        float written = -1.f;
    };
    std::unordered_map<HardStreak*, WavePulse> s_wavePulses;
}

namespace grassy::cosmetic {
    // Runs every frame, menus included
    void update() {
        applyPitchShift();
    }
}

class $modify(CosmeticPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        s_order = {};
        s_trailsTouched = false;
        s_playersHidden = false;
        s_startPosResetCamera.clear();
        s_wavePulses.clear();
        if (on("cosmetic.icon-randomizer")) rollIcons();
        s_settingUpLevel = true;
        bool result = PlayLayer::init(level, useReplay, dontCreateObjects);
        s_settingUpLevel = false;
        return result;
    }

    void postUpdate(float dt) {
        PlayLayer::postUpdate(dt);
        applyHidden(this);
        applyTrails(this);
        applyEffects(this);
        applyDrawOrder(this);
    }

    void resetLevel() {
        // Start positions with GD's "Reset Camera" option, which the option turns on for all of them
        if (auto startPos = m_startPosObject; startPos && startPos->m_startSettings) {
            auto [it, added] = s_startPosResetCamera.try_emplace(startPos, startPos->m_startSettings->m_resetCamera);
            startPos->m_startSettings->m_resetCamera = on("cosmetic.startpos-camera") || it->second;
        }
        PlayLayer::resetLevel();
    }

    void updateProgressbar() {
        PlayLayer::updateProgressbar();
        if (!on("cosmetic.accurate-percent") || m_isPlatformer || !m_percentageLabel) return;
        auto decimals = static_cast<int>(std::clamp<int64_t>(config::getInt("cosmetic.accurate-percent.decimals"), 0, 6));
        auto text = fmt::format("{:.{}f}%", std::clamp(getCurrentPercent(), 0.f, 100.f), decimals);
        if (text != m_percentageLabel->getString()) m_percentageLabel->setString(text.c_str());
    }

    void updateAttempts() {
        PlayLayer::updateAttempts();
        if (!on("cosmetic.total-attempts") || !m_attemptLabel || !m_level) return;
        m_attemptLabel->setString(fmt::format("Attempt {}", m_level->m_attempts.value()).c_str());
    }

    void showNewBest(bool newReward, int orbs, int diamonds, bool demonKey, bool noRetry, bool noTitle) {
        if (on("cosmetic.no-new-best")) return;
        // GD's "Do Not" setting mirrors this text too
        if (on("cosmetic.no-do-not")) m_doNot = false;
        PlayLayer::showNewBest(newReward, orbs, diamonds, demonKey, noRetry, noTitle);
    }

    // Where GD's "Do Not" setting mirrors the attempt text
    void setupHasCompleted() {
        if (on("cosmetic.no-do-not")) m_doNot = false;
        PlayLayer::setupHasCompleted();
    }

    void addObject(GameObject* object) {
        if (on("cosmetic.no-glow")) object->m_hasNoGlow = true;
        PlayLayer::addObject(object);
    }
};

class $modify(CosmeticGameLayer, GJBaseGameLayer) {
    bool isLevel() {
        return PlayLayer::get() == static_cast<GJBaseGameLayer*>(this);
    }

    void shakeCamera(float duration, float strength, float interval) {
        if (isLevel()) {
            if (on("cosmetic.no-shake")) return;
            auto pl = static_cast<PlayLayer*>(static_cast<GJBaseGameLayer*>(this));
            if (on("cosmetic.no-end-shake") && (pl->m_hasCompletedLevel || m_levelEndAnimationStarted)) return;
        }
        GJBaseGameLayer::shakeCamera(duration, strength, interval);
    }

    void updateZoom(float zoom, float duration, int easing, float rate, int uniqueID, int controlID) {
        if (isLevel() && on("cosmetic.no-zoom")) return;
        GJBaseGameLayer::updateZoom(zoom, duration, easing, rate, uniqueID, controlID);
    }

    void toggleFlipped(bool flip, bool noEffects) {
        if (isLevel() && on("cosmetic.no-mirror")) flip = false;
        GJBaseGameLayer::toggleFlipped(flip, noEffects);
    }

    // Stop Triggers On Death: nothing in the level moves while you're dead
    void update(float dt) {
        if (isLevel() && on("cosmetic.stop-triggers") && !bot::isRunning()) {
            if ((m_player1 && m_player1->m_isDead) || (m_player2 && m_player2->m_isDead)) return;
        }
        GJBaseGameLayer::update(dt);
    }
};

class $modify(CosmeticPlayer, PlayerObject) {
    void playDeathEffect() {
        if (on("cosmetic.no-death-effect") && levelPlayer(this)) return;
        PlayerObject::playDeathEffect();
    }

    void playSpawnEffect() {
        if (on("cosmetic.no-respawn-flash") && levelPlayer(this)) return;
        PlayerObject::playSpawnEffect();
    }

    void playSpiderDashEffect(CCPoint from, CCPoint to) {
        if (on("cosmetic.no-spider-dash") && levelPlayer(this)) return;
        PlayerObject::playSpiderDashEffect(from, to);
    }

    void toggleGhostEffect(GhostType type) {
        if (on("cosmetic.no-ghost-trail") && levelPlayer(this)) type = GhostType::Disabled;
        PlayerObject::toggleGhostEffect(type);
    }

    // Icon Randomizer: GD picks the icons the player is drawn with here, and
    // when a level's players are made
    bool init(int player, int ship, GJBaseGameLayer* gameLayer, CCLayer* layer, bool playLayer) {
        if (on("cosmetic.icon-randomizer") && s_settingUpLevel) {
            player = s_icons.cube;
            ship = s_icons.ship;
        }
        return PlayerObject::init(player, ship, gameLayer, layer, playLayer);
    }


    void updatePlayerFrame(int frame) {
        PlayerObject::updatePlayerFrame(randomizing(this) ? s_icons.cube : frame);
    }

    void updatePlayerShipFrame(int frame) {
        PlayerObject::updatePlayerShipFrame(randomizing(this) ? s_icons.ship : frame);
    }

    void updatePlayerRollFrame(int frame) {
        PlayerObject::updatePlayerRollFrame(randomizing(this) ? s_icons.ball : frame);
    }

    void updatePlayerBirdFrame(int frame) {
        PlayerObject::updatePlayerBirdFrame(randomizing(this) ? s_icons.ufo : frame);
    }

    void updatePlayerDartFrame(int frame) {
        PlayerObject::updatePlayerDartFrame(randomizing(this) ? s_icons.wave : frame);
    }

    void updatePlayerSwingFrame(int frame) {
        PlayerObject::updatePlayerSwingFrame(randomizing(this) ? s_icons.swing : frame);
    }

    void updatePlayerJetpackFrame(int frame) {
        PlayerObject::updatePlayerJetpackFrame(randomizing(this) ? s_icons.jetpack : frame);
    }

    void createRobot(int frame) {
        PlayerObject::createRobot(randomizing(this) ? s_icons.robot : frame);
    }

    void createSpider(int frame) {
        PlayerObject::createSpider(randomizing(this) ? s_icons.spider : frame);
    }

    // Your colors are swapped for the random ones. Player 2 has them the other way around.
    ccColor3B randomColorFor(ccColor3B const& color) {
        auto gm = GameManager::get();
        if (color == gm->colorForIdx(gm->getPlayerColor())) return gm->colorForIdx(s_icons.color1);
        if (color == gm->colorForIdx(gm->getPlayerColor2())) return gm->colorForIdx(s_icons.color2);
        return color;
    }

    void setColor(ccColor3B const& color) {
        if (!randomizing(this)) return PlayerObject::setColor(color);
        PlayerObject::setColor(randomColorFor(color));
    }

    void setSecondColor(ccColor3B const& color) {
        if (!randomizing(this)) return PlayerObject::setSecondColor(color);
        PlayerObject::setSecondColor(randomColorFor(color));
    }
};

class $modify(CosmeticRing, RingObject) {
    // The ring that grows out of an orb when you click it
    void spawnCircle() {
        if (on("cosmetic.no-orb-ring") && inLevel()) return;
        RingObject::spawnCircle();
    }
};

class $modify(CosmeticParticles, CCParticleSystemQuad) {
    void draw() {
        if (on("cosmetic.no-particles") && inLevel()) return;
        CCParticleSystemQuad::draw();
    }
};

class $modify(CosmeticParticleBatch, CCParticleBatchNode) {
    void draw() {
        if (on("cosmetic.no-particles") && inLevel()) return;
        CCParticleBatchNode::draw();
    }
};

class $modify(CosmeticShaders, ShaderLayer) {
    // Draws the level straight to the screen instead of through the shaders
    void visit() {
        if (on("cosmetic.no-shaders") && inLevel()) return CCNode::visit();
        ShaderLayer::visit();
    }
};

class $modify(CosmeticAudio, FMODAudioEngine) {
    // No Pulse: the music's loudness, which objects pulse with, stays at
    // what GD starts levels with (0.1)
    void update(float dt) {
        FMODAudioEngine::update(dt);
        if (on("cosmetic.no-pulse") && inLevel()) {
            m_pulse1 = 0.1f;
            m_pulse2 = 0.1f;
            m_pulse3 = 0.1f;
        }
    }
};

class $modify(CosmeticWaveTrail, HardStreak) {
    void updateStroke(float dt) {
        auto pl = PlayLayer::get();
        bool waveTrail = pl && ((pl->m_player1 && pl->m_player1->m_waveTrail == this) ||
            (pl->m_player2 && pl->m_player2->m_waveTrail == this));
        bool noPulse = on("cosmetic.no-wave-pulse");
        bool custom = on("cosmetic.wave-pulse-size");
        if (waveTrail && (noPulse || custom)) {
            auto& pulse = s_wavePulses[this];
            if (m_pulseSize != pulse.written) pulse.game = m_pulseSize;
            float strength = noPulse ? 0.f : static_cast<float>(config::getFloat("cosmetic.wave-pulse-size.value"));
            m_pulseSize = pulse.written = std::max(0.f, 1.f + (pulse.game - 1.f) * strength);
        }
        HardStreak::updateStroke(dt);
    }
};
