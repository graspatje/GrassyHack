#include "../Config.hpp"
#include "../Hacks.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/ui/Notification.hpp>

#include <chrono>
#include <deque>

using namespace geode::prelude;
using namespace grassy;

// Freezes the level and moves it one physics tick per key press, forwards or back.
// GD 2.2 always simulates at 240 ticks per second, so one tick = 1/240 s.
//
// Stepping back works by saving a checkpoint snapshot before every forward step,
// then respawning at that snapshot the same way practice mode respawns at a
// checkpoint. That restores the level far more completely than loading the state
// by hand, but it means stepping back is practice mode only.

namespace {
    constexpr double kSecondsPerTick = 1.0 / 240.0;
    // Caps how many presses can pile up if key repeat outpaces the frame rate
    constexpr int kMaxQueuedSteps = 2;

    bool s_enabled = false;
    bool s_stepping = false;
    bool s_rewinding = false;
    // Died while frozen: the respawn waits so you can step back out of the death
    bool s_respawnHeld = false;
    int s_queuedSteps = 0;
    int s_ticksThisStep = 0;
    // How far the music fell behind while paused, applied when the stepper is turned off
    double s_musicLagSeconds = 0.0;
    // Snapshots taken right before each forward step, oldest first
    std::deque<Ref<CheckpointObject>> s_history;

    bool canUseStepper(PlayLayer* pl) {
        return pl && !pl->m_isPaused && !pl->m_hasCompletedLevel && !pl->m_levelEndAnimationStarted;
    }

    bool isDead(PlayLayer* pl) {
        return pl->m_player1 && pl->m_player1->m_isDead;
    }

    size_t historyLimit() {
        return static_cast<size_t>(config::getInt("stepper.history"));
    }

    void updateLabel(PlayLayer* pl) {
        if (!pl || !pl->m_uiLayer) return;

        auto label = static_cast<CCLabelBMFont*>(pl->m_uiLayer->getChildByID("frame-label"_spr));
        bool show = s_enabled && config::getBool("stepper.label");
        if (!show) {
            if (label) label->setVisible(false);
            return;
        }

        if (!label) {
            label = CCLabelBMFont::create("", "bigFont.fnt");
            label->setID("frame-label"_spr);
            label->setAnchorPoint({ 0.f, 0.f });
            label->setScale(0.35f);
            label->setPosition({ 5.f, 5.f });
            pl->m_uiLayer->addChild(label, 1000);
        }

        // GD's progress counts 480 a second, 2 per tick
        auto text = fmt::format("Frame Stepper | Tick {}", pl->m_gameState.m_currentProgress / 2);
        if (pl->m_isPracticeMode) {
            text += fmt::format(" | Back {}", s_history.size());
        }
        if (s_respawnHeld) {
            text += " | Dead: step back or continue";
        }
        label->setVisible(true);
        label->setOpacity(labels::opacity());
        label->setString(text.c_str());
    }

    void freezeMusic() {
        FMODAudioEngine::sharedEngine()->pauseAllMusic(true);
    }

    void unfreezeMusic() {
        auto engine = FMODAudioEngine::sharedEngine();
        // Catch the song up to where the level is now, so it stays in sync
        if (s_musicLagSeconds > 0.0 && engine->getActiveMusicChannel(0)) {
            auto lagMS = static_cast<unsigned int>(s_musicLagSeconds * 1000.0 + 0.5);
            engine->setMusicTimeMS(engine->getMusicTimeMS(0) + lagMS, true, 0);
        }
        s_musicLagSeconds = 0.0;
        engine->resumeAllMusic();
    }

    void setFrozenIn(PlayLayer* pl, bool enabled) {
        if (s_enabled == enabled) return;
        s_enabled = enabled;
        s_queuedSteps = 0;
        s_history.clear();
        if (enabled) {
            s_musicLagSeconds = 0.0;
            freezeMusic();
        }
        else if (s_respawnHeld) {
            // Continuing while dead: do the respawn that was put on hold
            s_respawnHeld = false;
            s_musicLagSeconds = 0.0;
            pl->resetLevel();
        }
        else {
            unfreezeMusic();
        }
        updateLabel(pl);
    }

    void takeSnapshot(PlayLayer* pl) {
        if (!pl->m_isPracticeMode || isDead(pl)) return;
        s_history.push_back(pl->createCheckpoint());
        while (s_history.size() > historyLimit()) {
            s_history.pop_front();
        }
    }

    void rewind(PlayLayer* pl) {
        if (s_history.empty()) return;

        Ref<CheckpointObject> snapshot = s_history.back();
        s_history.pop_back();

        // Respawn at the snapshot like practice mode does, then take it back out
        // so it never acts as one of your real checkpoints
        auto currentCheckpoint = pl->m_currentCheckpoint;
        pl->m_checkpointArray->addObject(snapshot);
        s_rewinding = true;
        pl->resetLevel();
        s_rewinding = false;
        if (pl->m_checkpointArray->containsObject(snapshot)) {
            pl->m_checkpointArray->removeObject(snapshot);
        }
        pl->m_currentCheckpoint = currentCheckpoint;

        s_respawnHeld = false;
        s_queuedSteps = 0;
        updateLabel(pl);
    }

    void resetState() {
        s_enabled = false;
        s_stepping = false;
        s_rewinding = false;
        s_respawnHeld = false;
        s_queuedSteps = 0;
        s_musicLagSeconds = 0.0;
        s_history.clear();
    }

    void warn(char const* text) {
        Notification::create(text, NotificationIcon::Warning)->show();
    }
}

namespace grassy::stepper {
    bool isFrozen() {
        return s_enabled;
    }

    void setFrozen(bool frozen) {
        auto pl = PlayLayer::get();
        if (frozen == s_enabled) return;
        if (!pl) return warn("Open a level first");
        if (frozen && bot::isRunning()) return warn("Stop the bot first");
        if (pl->m_isPaused) return warn("Unpause the level first");
        if (!canUseStepper(pl)) return;
        setFrozenIn(pl, frozen);
    }

    bool stepForward() {
        if (!s_enabled || !canUseStepper(PlayLayer::get())) return false;
        // Holding the key keeps stepping through OS key repeat
        s_queuedSteps = std::min(s_queuedSteps + 1, kMaxQueuedSteps);
        return true;
    }

    bool stepBack() {
        auto pl = PlayLayer::get();
        if (!s_enabled || !canUseStepper(pl)) return false;
        if (!pl->m_isPracticeMode) {
            // Holding the key repeats it, so don't stack up warnings
            static std::chrono::steady_clock::time_point lastWarning;
            auto now = std::chrono::steady_clock::now();
            if (now - lastWarning > std::chrono::seconds(2)) {
                lastWarning = now;
                warn("Step back only works in practice mode");
            }
            return true;
        }
        rewind(pl);
        return true;
    }
}

class $modify(StepperGameLayer, GJBaseGameLayer) {
    void update(float dt) {
        auto pl = PlayLayer::get();
        if (!s_enabled || pl != static_cast<GJBaseGameLayer*>(this) || !canUseStepper(pl)) {
            return GJBaseGameLayer::update(dt);
        }
        // Frozen: skip the whole update until a step is requested
        if (s_queuedSteps <= 0) return;
        s_queuedSteps--;

        takeSnapshot(pl);

        s_stepping = true;
        s_ticksThisStep = 0;
        GJBaseGameLayer::update(dt);
        s_stepping = false;

        if (s_ticksThisStep != 1) {
            log::warn("Frame step ran {} ticks instead of 1", s_ticksThisStep);
        }
        updateLabel(pl);
    }

    double getModifiedDelta(float dt) {
        if (!s_stepping) return GJBaseGameLayer::getModifiedDelta(dt);

        // Return exactly one tick's worth of time, the same amount GD's own
        // formula yields for a single step (time warp below 1 shrinks the tick)
        double warp = std::min(m_gameState.m_timeWarp, 1.f);
        double delta = warp * kSecondsPerTick;
        m_extraDelta = 0.0;
        s_musicLagSeconds += delta;
        return delta;
    }

    void processCommands(float dt, bool isHalfTick, bool isLastTick) {
        if (s_stepping) s_ticksThisStep++;
        GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
    }
};

class $modify(StepperPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        resetState();
        return PlayLayer::init(level, useReplay, dontCreateObjects);
    }

    void onQuit() {
        resetState();
        PlayLayer::onQuit();
    }

    // GD restarts or resumes the song in these, so pause it again while frozen
    void resetLevel() {
        PlayLayer::resetLevel();
        if (!s_rewinding) {
            // A real respawn or restart: the old history no longer applies
            s_history.clear();
            s_respawnHeld = false;
        }
        if (s_enabled) {
            s_musicLagSeconds = 0.0;
            freezeMusic();
            updateLabel(this);
        }
    }

    void delayedResetLevel() {
        // Dying while frozen in practice mode: hold the respawn so you can step back
        if (s_enabled && m_isPracticeMode && !s_history.empty()) {
            if (isDead(this)) {
                s_respawnHeld = true;
                updateLabel(this);
            }
            // Not dead any more means you already stepped back out of the death
            return;
        }
        PlayLayer::delayedResetLevel();
    }

    void updateAttempts() {
        // Stepping back shouldn't count as a new attempt
        if (s_rewinding) return;
        PlayLayer::updateAttempts();
    }

    void resume() {
        PlayLayer::resume();
        if (s_enabled) freezeMusic();
    }

    void togglePracticeMode(bool practiceMode) {
        PlayLayer::togglePracticeMode(practiceMode);
        s_history.clear();
        if (s_enabled) {
            s_musicLagSeconds = 0.0;
            freezeMusic();
            updateLabel(this);
        }
    }
};
