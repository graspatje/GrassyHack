#include "../Config.hpp"
#include "../Hacks.hpp"

#include <Geode/Geode.hpp>

#include <algorithm>
#include <filesystem>
#include <optional>

using namespace geode::prelude;
using namespace grassy;

// The chat's pictures: yours is the cube you have picked in GD, the AI's is a
// GD icon or a picture from your PC, set in the chat's settings. GD icons are
// drawn into a texture, and drawn again only when they change.

namespace {
    // In points, the texture has GD's texture quality on top
    constexpr int kSize = 48;
    // How much of the picture the icon fills, so it fits inside the circle
    constexpr float kFill = 0.7f;

    struct IconTexture {
        CCRenderTexture* texture = nullptr;
        // What's drawn in it now
        std::string drawn;
    };

    IconTexture s_playerIcon;
    IconTexture s_aiIcon;
    CCTexture2D* s_aiImage = nullptr;
    std::string s_aiImagePath;

    ccColor3B rgb(int64_t value) {
        return { static_cast<GLubyte>((value >> 16) & 0xFF), static_cast<GLubyte>((value >> 8) & 0xFF),
            static_cast<GLubyte>(value & 0xFF) };
    }

    // The area the visible sprites in node take up, in the space of node's parent
    void addBounds(CCNode* node, CCAffineTransform const& toParent, std::optional<CCRect>& bounds) {
        if (!node->isVisible()) return;
        auto transform = CCAffineTransformConcat(node->nodeToParentTransform(), toParent);
        auto size = node->getContentSize();
        if (typeinfo_cast<CCSprite*>(node) && size.width > 0.f && size.height > 0.f) {
            auto rect = CCRectApplyAffineTransform({ 0.f, 0.f, size.width, size.height }, transform);
            if (!bounds) {
                bounds = rect;
            }
            else {
                float minX = std::min(bounds->getMinX(), rect.getMinX());
                float minY = std::min(bounds->getMinY(), rect.getMinY());
                float maxX = std::max(bounds->getMaxX(), rect.getMaxX());
                float maxY = std::max(bounds->getMaxY(), rect.getMaxY());
                bounds = CCRect(minX, minY, maxX - minX, maxY - minY);
            }
        }
        for (auto child : CCArrayExt<CCNode*>(node->getChildren())) addBounds(child, transform, bounds);
    }

    std::optional<CCRect> boundsOf(CCNode* node) {
        std::optional<CCRect> bounds;
        addBounds(node, CCAffineTransformMakeIdentity(), bounds);
        return bounds;
    }

    chat::Picture iconPicture(IconTexture const& icon) {
        if (!icon.texture) return {};
        auto texture = icon.texture->getSprite()->getTexture();
        // Render textures are upside down
        return { texture->getName(), 0.f, texture->getMaxT(), texture->getMaxS(), 0.f };
    }

    chat::Picture drawIcon(IconTexture& icon, int type, int id, ccColor3B main, ccColor3B second,
            std::optional<ccColor3B> glow) {
        auto key = fmt::format("{} {} {} {} {} {} {} {} {} {}", type, id, main.r, main.g, main.b, second.r, second.g,
            second.b, glow ? (glow->r << 16 | glow->g << 8 | glow->b) : -1, CCDirector::get()->getContentScaleFactor());
        if (icon.texture && icon.drawn == key) return iconPicture(icon);
        if (!icon.texture) {
            icon.texture = CCRenderTexture::create(kSize, kSize);
            if (!icon.texture) return {};
            icon.texture->retain();
        }
        icon.drawn = key;

        auto player = SimplePlayer::create(1);
        player->updatePlayerFrame(id, static_cast<IconType>(type));
        player->setColors(main, second);
        if (glow) player->setGlowOutline(*glow);
        else player->disableGlowOutline();
        auto holder = CCNode::create();
        holder->addChild(player);

        // Scaled to fit, then moved so it sits in the middle
        if (auto bounds = boundsOf(player)) {
            float biggest = std::max({ bounds->size.width, bounds->size.height, 1.f });
            player->setScale(kSize * kFill / biggest);
        }
        if (auto bounds = boundsOf(player)) {
            player->setPosition({ kSize / 2.f - bounds->getMidX(), kSize / 2.f - bounds->getMidY() });
        }

        icon.texture->beginWithClear(0.f, 0.f, 0.f, 0.f);
        holder->visit();
        icon.texture->end();
        return iconPicture(icon);
    }
}

namespace grassy::chat {
    Picture playerPicture() {
        auto gm = GameManager::get();
        std::optional<ccColor3B> glow;
        if (gm->getPlayerGlow()) glow = gm->colorForIdx(gm->getPlayerGlowColor());
        return drawIcon(s_playerIcon, static_cast<int>(IconType::Cube), gm->getPlayerFrame(),
            gm->colorForIdx(gm->getPlayerColor()), gm->colorForIdx(gm->getPlayerColor2()), glow);
    }

    Picture aiPicture() {
        if (config::getInt("chat.ai.picture") == 1) {
            auto const& path = config::getString("chat.ai.image");
            if (path != s_aiImagePath) {
                s_aiImagePath = path;
                if (s_aiImage) s_aiImage->release();
                s_aiImage = nullptr;
                std::error_code error;
                if (!path.empty() && std::filesystem::exists(std::filesystem::path(path), error)) {
                    s_aiImage = CCTextureCache::get()->addImage(path.c_str(), false);
                    if (s_aiImage) s_aiImage->retain();
                }
            }
            if (s_aiImage) {
                // Only the middle square of the picture, so it isn't squashed
                float width = static_cast<float>(s_aiImage->getPixelsWide());
                float height = static_cast<float>(s_aiImage->getPixelsHigh());
                float maxS = s_aiImage->getMaxS();
                float maxT = s_aiImage->getMaxT();
                float cutX = width > height ? (width - height) / 2.f / width * maxS : 0.f;
                float cutY = height > width ? (height - width) / 2.f / height * maxT : 0.f;
                return { s_aiImage->getName(), cutX, cutY, maxS - cutX, maxT - cutY };
            }
        }
        std::optional<ccColor3B> glow;
        if (config::getBool("chat.ai.glow")) glow = rgb(config::getInt("chat.ai.glow-color"));
        return drawIcon(s_aiIcon, static_cast<int>(config::getInt("chat.ai.icon-type")),
            static_cast<int>(config::getInt("chat.ai.icon")), rgb(config::getInt("chat.ai.color")),
            rgb(config::getInt("chat.ai.color2")), glow);
    }

    bool aiImageMissing() {
        return config::getInt("chat.ai.picture") == 1 && !s_aiImage;
    }
}
