#include "../Config.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/FLAlertLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>

using namespace geode::prelude;
using namespace grassy;

// The pause menu's exit button and Escape both open a confirm popup instead of
// leaving. The level only closes when the popup's Exit button is clicked.

namespace {
    // Lets our own popup call through to the real onQuit
    bool s_confirmed = false;

    bool confirmEnabled() {
        return config::getBool("confirm-exit");
    }
}

class $modify(ConfirmExitPauseLayer, PauseLayer) {
    void onQuit(CCObject* sender) {
        if (s_confirmed || !confirmEnabled()) {
            return PauseLayer::onQuit(sender);
        }
        if (CCScene::get()->getChildByID("confirm-exit-popup"_spr)) return;

        Ref<PauseLayer> self = this;
        auto popup = createQuickPopup(
            "Exit Level",
            "Are you sure you want to <cr>exit</c> this level?",
            "Cancel", "Exit",
            [self](FLAlertLayer*, bool exit) {
                if (!exit) return;
                s_confirmed = true;
                self->onQuit(nullptr);
                s_confirmed = false;
            },
            false,
            // Escape just closes the popup, it never counts as Exit
            true
        );
        popup->setID("confirm-exit-popup"_spr);
        popup->show();
    }

    void keyBackClicked() {
        if (!confirmEnabled()) return PauseLayer::keyBackClicked();
        this->onQuit(nullptr);
    }
};

class $modify(ConfirmExitAlertLayer, FLAlertLayer) {
    void keyDown(enumKeyCodes key, double timestamp) {
        // Block Space/Enter from pressing Exit, so it has to be clicked
        if (key != KEY_Escape && this->getID() == "confirm-exit-popup"_spr) return;
        FLAlertLayer::keyDown(key, timestamp);
    }
};
