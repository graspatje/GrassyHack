#include "../Config.hpp"
#include "../Hacks.hpp"
#include "../macro/Player.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/LevelSettingsObject.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PlayerObject.hpp>

#include <Windows.h>

#include <random>
#include <unordered_map>

using namespace geode::prelude;
using namespace grassy;

// Level hacks that play along with you: the auto clicker, auto kill, auto
// deafen, the jumpscare, the jump hack, instant complete, force platformer,
// practice runs that count, smart start positions, GD's click on/between
// steps, music sync. Also the buttons that change a level's saved progress,
// and Click Between Frames (another mod) switched from the menu.

namespace {
    bool on(char const* key) {
        return config::getBool(key);
    }

    bool isLevel(GJBaseGameLayer* layer) {
        return PlayLayer::get() == layer;
    }

    // Something else is playing the level, so the helpers stay out of the way
    bool somethingElsePlays() {
        return bot::isRunning() || macro::state() == macro::State::Playing;
    }

    // Ticks since the attempt started, for the auto clicker
    int64_t s_tick = 0;
    bool s_clickerHolding = false;

    bool s_autoKilled = false;
    // A level is being opened
    bool s_openingLevel = false;
    bool s_completedInstantly = false;

    // 0% Practice Complete: this practice attempt started at the start of the level and hasn't died
    bool s_cleanRun = false;
    bool s_loadedCheckpoint = false;
    // The level was taken out of practice mode so beating it saves
    bool s_leftPractice = false;

    // Auto deafen

    bool s_deafened = false;

    void sendKey(WORD key, bool down) {
        INPUT input = {};
        input.type = INPUT_KEYBOARD;
        input.ki.wVk = key;
        input.ki.dwFlags = down ? 0 : KEYEVENTF_KEYUP;
        SendInput(1, &input, sizeof(INPUT));
    }

    // Presses Discord's deafen shortcut, as set in the options
    void pressDeafenKey() {
        auto key = config::getKey("deafen.key");
        if (key == KEY_None) return;
        std::vector<WORD> modifiers;
        if (on("deafen.ctrl")) modifiers.push_back(VK_CONTROL);
        if (on("deafen.shift")) modifiers.push_back(VK_SHIFT);
        if (on("deafen.alt")) modifiers.push_back(VK_MENU);
        for (auto modifier : modifiers) sendKey(modifier, true);
        // Cocos key codes are Windows' own key codes
        sendKey(static_cast<WORD>(key), true);
        sendKey(static_cast<WORD>(key), false);
        for (auto it = modifiers.rbegin(); it != modifiers.rend(); ++it) sendKey(*it, false);
    }

    void undeafen() {
        if (!s_deafened) return;
        s_deafened = false;
        pressDeafenKey();
    }

    void checkDeafen(PlayLayer* pl) {
        if (!on("deafen") || s_deafened || pl->m_isPracticeMode || pl->m_isPlatformer || pl->m_player1->m_isDead) return;
        if (pl->getCurrentPercent() < static_cast<float>(config::getInt("deafen.percent"))) return;
        s_deafened = true;
        pressDeafenKey();
    }

    // Jumpscare

    std::mt19937& random() {
        static std::mt19937 s_random{ std::random_device{}() };
        return s_random;
    }

    void jumpscare() {
        auto scene = CCScene::get();
        if (!scene) return;
        auto winSize = CCDirector::get()->getWinSize();
        CCSprite* sprite = nullptr;
        auto const& path = config::getString("jumpscare.image");
        if (!path.empty() && std::filesystem::exists(std::filesystem::path(path))) {
            if (auto texture = CCTextureCache::get()->addImage(path.c_str(), false)) sprite = CCSprite::createWithTexture(texture);
        }
        // Without a picture of your own, the extreme demon face
        if (!sprite) sprite = CCSprite::createWithSpriteFrameName("diffIcon_10_btn_001.png");
        if (!sprite) return;

        auto layer = CCLayerColor::create({ 0, 0, 0, 255 });
        layer->setID("jumpscare"_spr);
        auto size = sprite->getContentSize();
        float scale = std::min(winSize.width / std::max(size.width, 1.f), winSize.height / std::max(size.height, 1.f));
        sprite->setScale(scale * 0.6f);
        sprite->setPosition(winSize / 2.f);
        sprite->runAction(CCEaseExponentialOut::create(CCScaleTo::create(0.15f, scale)));
        layer->addChild(sprite);
        scene->addChild(layer, 100000);
        layer->runAction(CCSequence::create(CCDelayTime::create(0.9f), CCFadeOut::create(0.25f), CCRemoveSelf::create(), nullptr));
        sprite->runAction(CCSequence::create(CCDelayTime::create(0.9f), CCFadeOut::create(0.25f), nullptr));
        auto engine = FMODAudioEngine::get();
        engine->playEffect("explode_11.ogg", 1.f, 0.f, 1.f);
        engine->playEffect("magicExplosion.ogg", 1.f, 0.f, 1.f);
    }

    void maybeJumpscare(PlayLayer* pl) {
        if (!on("jumpscare")) return;
        if (!pl->m_isPlatformer && pl->getCurrentPercent() < static_cast<float>(config::getInt("jumpscare.percent"))) return;
        auto chance = std::clamp<int64_t>(config::getInt("jumpscare.chance"), 0, 100);
        if (std::uniform_int_distribution<int>(1, 100)(random()) > chance) return;
        jumpscare();
    }

    // Smart StartPos: each start position gets the game mode, speed, size,
    // dual and gravity of the portals before it

    struct StartSettings {
        int mode = 0;
        Speed speed = Speed::Normal;
        bool mini = false;
        bool dual = false;
        bool flipped = false;
    };

    struct SmartStartPos {
        StartSettings original;
        StartSettings smart;
    };
    std::unordered_map<StartPosObject*, SmartStartPos> s_smartStartPos;
    bool s_smartScanned = false;

    StartSettings read(LevelSettingsObject* settings) {
        return { settings->m_startMode, settings->m_startSpeed, settings->m_startMini, settings->m_startDual, settings->m_isFlipped };
    }

    void write(LevelSettingsObject* settings, StartSettings const& values) {
        settings->m_startMode = values.mode;
        settings->m_startSpeed = values.speed;
        settings->m_startMini = values.mini;
        settings->m_startDual = values.dual;
        settings->m_isFlipped = values.flipped;
    }

    void scanStartPositions(PlayLayer* pl) {
        if (s_smartScanned || !pl->m_objects) return;
        s_smartScanned = true;
        struct Portal {
            float x;
            int id;
        };
        std::vector<Portal> portals;
        std::vector<StartPosObject*> startPositions;
        for (auto object : CCArrayExt<GameObject*>(pl->m_objects)) {
            int id = object->m_objectID;
            if (id == 31) {
                if (auto startPos = typeinfo_cast<StartPosObject*>(object); startPos && startPos->m_startSettings) {
                    startPositions.push_back(startPos);
                }
                continue;
            }
            switch (id) {
                case 12: case 13: case 47: case 111: case 660: case 745: case 1331: case 1933:
                case 200: case 201: case 202: case 203: case 1334:
                case 99: case 101: case 286: case 287: case 10: case 11:
                    portals.push_back({ object->getPositionX(), id });
                    break;
                default: break;
            }
        }
        std::sort(portals.begin(), portals.end(), [](Portal const& a, Portal const& b) { return a.x < b.x; });

        // The level's own start
        StartSettings start;
        if (pl->m_levelSettings) start = read(pl->m_levelSettings);
        for (auto startPos : startPositions) {
            StartSettings smart = start;
            float x = startPos->getPositionX();
            for (auto const& portal : portals) {
                if (portal.x >= x) break;
                switch (portal.id) {
                    case 12: smart.mode = 0; break;
                    case 13: smart.mode = 1; break;
                    case 47: smart.mode = 2; break;
                    case 111: smart.mode = 3; break;
                    case 660: smart.mode = 4; break;
                    case 745: smart.mode = 5; break;
                    case 1331: smart.mode = 6; break;
                    case 1933: smart.mode = 7; break;
                    case 200: smart.speed = Speed::Slow; break;
                    case 201: smart.speed = Speed::Normal; break;
                    case 202: smart.speed = Speed::Fast; break;
                    case 203: smart.speed = Speed::Faster; break;
                    case 1334: smart.speed = Speed::Fastest; break;
                    case 99: smart.mini = false; break;
                    case 101: smart.mini = true; break;
                    case 286: smart.dual = true; break;
                    case 287: smart.dual = false; break;
                    case 10: smart.flipped = false; break;
                    case 11: smart.flipped = true; break;
                    default: break;
                }
            }
            s_smartStartPos[startPos] = { read(startPos->m_startSettings), smart };
        }
    }

    void applySmartStartPos(PlayLayer* pl) {
        auto startPos = pl->m_startPosObject;
        if (!startPos || !startPos->m_startSettings) return;
        scanStartPositions(pl);
        auto it = s_smartStartPos.find(startPos);
        if (it == s_smartStartPos.end()) return;
        write(startPos->m_startSettings, on("startpos.smart") ? it->second.smart : it->second.original);
    }

    // GD's click on steps / click between steps, as the level set them
    bool s_gameClickBetweenSteps = false;
    bool s_gameClickOnSteps = false;

    // Music sync: where the song and the level were when the attempt started
    double s_musicAnchorLevelTime = -1.0;
    double s_musicAnchorSongMs = 0.0;
    double s_nextMusicCheck = 0.0;

    void syncMusic(PlayLayer* pl) {
        if (!on("music-sync") || pl->m_isPaused || pl->m_hasCompletedLevel || pl->m_player1->m_isDead || stepper::isFrozen()) {
            s_musicAnchorLevelTime = -1.0;
            return;
        }
        if (pl->m_isPracticeMode && !pl->m_practiceMusicSync) return;
        auto engine = FMODAudioEngine::get();
        double levelTime = pl->m_gameState.m_levelTime;
        // Give GD a moment to start the song before taking where it is
        if (s_musicAnchorLevelTime < 0.0) {
            if (levelTime < 0.3) return;
            s_musicAnchorLevelTime = levelTime;
            s_musicAnchorSongMs = engine->getMusicTimeMS(0);
            s_nextMusicCheck = levelTime + 0.5;
            return;
        }
        if (levelTime < s_nextMusicCheck) return;
        s_nextMusicCheck = levelTime + 0.5;
        double expected = s_musicAnchorSongMs + (levelTime - s_musicAnchorLevelTime) * 1000.0;
        double actual = engine->getMusicTimeMS(0);
        if (std::abs(actual - expected) > 60.0) engine->setMusicTimeMS(static_cast<unsigned>(std::max(0.0, expected)), true, 0);
    }
}

namespace grassy::level {
    GJGameLevel* current() {
        if (auto pl = PlayLayer::get()) return pl->m_level;
        auto scene = CCScene::get();
        if (!scene) return nullptr;
        if (auto info = scene->getChildByType<LevelInfoLayer>(0)) return info->m_level;
        return nullptr;
    }

    bool completed(GJGameLevel* level) {
        return level && level->m_normalPercent.value() >= 100;
    }

    bool practiceCompleted(GJGameLevel* level) {
        return level && level->m_practicePercent >= 100;
    }

    void uncomplete(GJGameLevel* level) {
        if (!level) return;
        GameStatsManager::get()->uncompleteLevel(level);
        level->m_normalPercent = 0;
        level->m_newNormalPercent2 = 0;
        level->m_orbCompletion = 0;
        level->m_bestTime = 0;
        level->m_bestPoints = 0;
    }

    void uncompletePractice(GJGameLevel* level) {
        if (level) level->m_practicePercent = 0;
    }

    void resetProgress(GJGameLevel* level) {
        if (!level) return;
        if (completed(level)) uncomplete(level);
        level->m_normalPercent = 0;
        level->m_newNormalPercent2 = 0;
        level->m_orbCompletion = 0;
        level->m_bestTime = 0;
        level->m_bestPoints = 0;
        level->m_personalBests = "";
        level->m_attempts = 0;
        level->m_jumps = 0;
        level->m_clicks = 0;
        level->m_attemptTime = 0;
    }

    void resetPractice(GJGameLevel* level) {
        if (level) level->m_practicePercent = 0;
    }

    void testJumpscare() {
        jumpscare();
    }

    bool restartFromStart() {
        auto pl = PlayLayer::get();
        if (!pl) return false;
        pl->resetLevelFromStart();
        return true;
    }

    [[noreturn]] void crash() {
        log::warn("Crashing the game on purpose (Force Crash in GrassyHack)");
        *reinterpret_cast<int volatile*>(0) = 0;
        std::abort();
    }

    Mod* clickBetweenFrames() {
        return Loader::get()->getLoadedMod("syzzi.click_between_frames");
    }

    bool clickBetweenFramesOn() {
        auto cbf = clickBetweenFrames();
        return cbf && !cbf->getSettingValue<bool>("soft-toggle");
    }

    void setClickBetweenFrames(bool enabled) {
        if (auto cbf = clickBetweenFrames()) cbf->setSettingValue<bool>("soft-toggle", !enabled);
    }
}

class $modify(LevelToolsPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        s_tick = 0;
        s_clickerHolding = false;
        s_autoKilled = false;
        s_completedInstantly = false;
        s_cleanRun = true;
        s_loadedCheckpoint = false;
        s_leftPractice = false;
        s_smartStartPos.clear();
        s_smartScanned = false;
        s_musicAnchorLevelTime = -1.0;
        s_openingLevel = true;
        bool opened = PlayLayer::init(level, useReplay, dontCreateObjects);
        s_openingLevel = false;
        if (!opened) return false;
        s_gameClickBetweenSteps = m_clickBetweenSteps;
        s_gameClickOnSteps = m_clickOnSteps;
        if (m_startPosObject) s_cleanRun = false;
        return true;
    }

    void resetLevel() {
        if (s_leftPractice) {
            s_leftPractice = false;
            m_isPracticeMode = true;
        }
        undeafen();
        applySmartStartPos(this);
        s_loadedCheckpoint = false;
        PlayLayer::resetLevel();
        s_tick = 0;
        s_clickerHolding = false;
        s_autoKilled = false;
        s_completedInstantly = false;
        s_musicAnchorLevelTime = -1.0;
        // A practice attempt from a checkpoint or a start position doesn't count
        s_cleanRun = !s_loadedCheckpoint && !m_startPosObject;
    }

    void loadFromCheckpoint(CheckpointObject* checkpoint) {
        s_loadedCheckpoint = true;
        PlayLayer::loadFromCheckpoint(checkpoint);
    }

    void destroyPlayer(PlayerObject* player, GameObject* object) {
        bool wasDead = player && player->m_isDead;
        PlayLayer::destroyPlayer(player, object);
        if (wasDead || !player || !player->m_isDead || object == m_anticheatSpike) return;
        undeafen();
        s_cleanRun = false;
        if (!bot::isRunning()) maybeJumpscare(this);
    }

    void levelComplete() {
        undeafen();
        // A practice run from the start without dying counts like a normal one
        if (on("practice-complete") && m_isPracticeMode && s_cleanRun && !m_startPosObject) {
            m_isPracticeMode = false;
            s_leftPractice = true;
        }
        PlayLayer::levelComplete();
    }

    void onQuit() {
        undeafen();
        if (s_leftPractice) {
            s_leftPractice = false;
            m_isPracticeMode = true;
        }
        PlayLayer::onQuit();
    }

    void postUpdate(float dt) {
        PlayLayer::postUpdate(dt);
        if (!m_player1) return;
        m_clickBetweenSteps = on("click-between-steps") || s_gameClickBetweenSteps;
        m_clickOnSteps = on("click-on-steps") || s_gameClickOnSteps;
        checkDeafen(this);
        syncMusic(this);

        bool alive = !m_player1->m_isDead && !m_hasCompletedLevel && !m_levelEndAnimationStarted;
        if (!alive || m_isPaused || bot::isRunning()) return;
        if (on("autokill") && !s_autoKilled && !m_isPlatformer && (!m_isPracticeMode || on("autokill.practice")) &&
                getCurrentPercent() >= static_cast<float>(config::getInt("autokill.percent"))) {
            s_autoKilled = true;
            noclip::kill(this);
            return;
        }
        if (on("instant-complete") && !s_completedInstantly && m_started) {
            s_completedInstantly = true;
            levelComplete();
        }
    }
};

class $modify(LevelToolsGameLayer, GJBaseGameLayer) {
    // Runs once per tick: the auto clicker presses and lets go here
    void processCommands(float dt, bool isHalfTick, bool isLastTick) {
        if (isLevel(this) && on("autoclicker") && !somethingElsePlays() && m_player1 && !m_player1->m_isDead) {
            auto interval = std::max<int64_t>(2, config::getInt("autoclicker.interval"));
            auto hold = std::clamp<int64_t>(config::getInt("autoclicker.hold"), 1, interval - 1);
            auto phase = s_tick % interval;
            bool both = on("autoclicker.player2") && m_gameState.m_isDualMode;
            if (phase == 0 && !s_clickerHolding) {
                s_clickerHolding = true;
                handleButton(true, 1, true);
                if (both) handleButton(true, 1, false);
            }
            else if (phase == hold && s_clickerHolding) {
                s_clickerHolding = false;
                handleButton(false, 1, true);
                if (both) handleButton(false, 1, false);
            }
        }
        GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
        if (isLevel(this)) s_tick++;
    }

};

class $modify(LevelToolsSettings, LevelSettingsObject) {
    // Force Platformer: the level's settings say platformer when a level opens
    static LevelSettingsObject* objectFromDict(CCDictionary* dict) {
        auto settings = LevelSettingsObject::objectFromDict(dict);
        if (settings && s_openingLevel && on("force-platformer")) settings->m_platformerMode = true;
        return settings;
    }
};

class $modify(LevelToolsPlayer, PlayerObject) {
    // Jump Hack: every jump press works, even in the air
    bool pushButton(PlayerButton button) {
        if (button == PlayerButton::Jump && on("jump-hack")) {
            auto pl = PlayLayer::get();
            if (pl && (this == pl->m_player1 || this == pl->m_player2)) m_isOnGround = true;
        }
        return PlayerObject::pushButton(button);
    }
};
