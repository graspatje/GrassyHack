#include "../Config.hpp"
#include "../Hacks.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>

using namespace geode::prelude;
using namespace grassy;

// Noclip: GD's destroyPlayer is where every death goes through, so skipping
// it means nothing kills the player. GD's anticheat spike still goes through,
// since GD checks that it got hit. The bot learns from deaths, so noclip is
// off while it runs.

namespace {
    // Stats for the current attempt, counted while noclip is on: ticks played,
    // ticks spent inside something deadly, and how many times you went in
    int64_t s_ticks = 0;
    int64_t s_hitTicks = 0;
    int s_deaths = 0;
    int64_t s_lastHitTick = -2;
    // Auto kill's death goes through noclip
    bool s_forceKill = false;

    void resetStats() {
        s_ticks = 0;
        s_hitTicks = 0;
        s_deaths = 0;
        s_lastHitTick = -2;
    }

    // Sitting in a spike hits it every tick, and one tick can hit several things
    void countHit() {
        if (s_lastHitTick == s_ticks) return;
        if (s_lastHitTick != s_ticks - 1) s_deaths++;
        s_lastHitTick = s_ticks;
        s_hitTicks++;
    }

    void flash(PlayLayer* pl) {
        if (!config::getBool("noclip.flash") || !pl->m_uiLayer) return;
        auto layer = static_cast<CCLayerColor*>(pl->m_uiLayer->getChildByID("noclip-flash"_spr));
        if (!layer) {
            layer = CCLayerColor::create({ 255, 0, 0, 0 });
            layer->setID("noclip-flash"_spr);
            pl->m_uiLayer->addChild(layer, -1);
        }
        // Sitting in a spike hits every tick, which only restarts a flash that's mostly faded
        if (layer->getOpacity() > 40) return;
        layer->stopAllActions();
        layer->setOpacity(90);
        layer->runAction(CCFadeTo::create(0.3f, 0));
    }
}

class $modify(NoclipPlayLayer, PlayLayer) {
    void destroyPlayer(PlayerObject* player, GameObject* object) {
        if (object == m_anticheatSpike) return PlayLayer::destroyPlayer(player, object);
        if (config::getBool("noclip") && !bot::isRunning() && !s_forceKill) {
            countHit();
            flash(this);
            return;
        }
        safemode::beforeDeath(this);
        PlayLayer::destroyPlayer(player, object);
    }

    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        resetStats();
        return PlayLayer::init(level, useReplay, dontCreateObjects);
    }

    void resetLevel() {
        PlayLayer::resetLevel();
        resetStats();
    }
};

class $modify(NoclipGameLayer, GJBaseGameLayer) {
    // Runs once per tick
    void processCommands(float dt, bool isHalfTick, bool isLastTick) {
        if (config::getBool("noclip") && !bot::isRunning() && PlayLayer::get() == static_cast<GJBaseGameLayer*>(this)) {
            s_ticks++;
        }
        GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
    }
};

namespace grassy::noclip {
    float accuracy() {
        if (s_ticks <= 0) return 100.f;
        return 100.f * static_cast<float>(std::max<int64_t>(0, s_ticks - s_hitTicks)) / static_cast<float>(s_ticks);
    }

    int deaths() {
        return s_deaths;
    }

    void kill(PlayLayer* pl) {
        if (!pl->m_player1 || pl->m_player1->m_isDead) return;
        s_forceKill = true;
        pl->destroyPlayer(pl->m_player1, nullptr);
        s_forceKill = false;
    }
}
