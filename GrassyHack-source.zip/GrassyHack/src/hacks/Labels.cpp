#include "../Config.hpp"
#include "../Hacks.hpp"
#include "../Rulesets.hpp"
#include "../macro/Player.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>

#include <algorithm>
#include <chrono>
#include <ctime>
#include <deque>
#include <string>
#include <vector>

using namespace geode::prelude;
using namespace grassy;

// Text stacked in a top corner of the level (custom text, the time, FPS,
// clicks per second, time in the level, attempts, the exact percentage, the
// tick, noclip stats) and the cheat indicator dot in the bottom right. A node in the UI layer redraws them every frame, which
// keeps going while the level is frozen or paused.

namespace {
    using Clock = std::chrono::steady_clock;

    Clock::time_point s_enteredLevel;
    // When each click of the last second happened, and the most in a second
    std::deque<Clock::time_point> s_clicks;
    int s_mostClicks = 0;
    // Frames drawn since s_fpsSince, and the FPS they came to
    int s_frames = 0;
    Clock::time_point s_fpsSince;
    float s_fps = 0.f;
    // The rulesets::Cheat bits of every cheat used this attempt
    uint32_t s_usedCheats = 0;

    uint32_t activeCheats(PlayLayer* pl) {
        using namespace rulesets;
        bool botRunning = bot::isRunning();
        uint32_t active = 0;
        if (config::getBool("noclip") && !botRunning) active |= Noclip;
        if (speedhack::speed() != 1.f) active |= Speedhack;
        if (stepper::isFrozen()) active |= FrameStepper;
        if (botRunning) active |= AutoBot;
        if (pl->m_startPosObject) active |= StartPos;
        if (respawn::changed()) active |= Respawn;
        if (macro::state() == macro::State::Playing) active |= MacroPlayback;
        if (config::getBool("autoclicker")) active |= AutoClicker;
        if (config::getBool("jump-hack")) active |= JumpHack;
        if (config::getBool("instant-complete")) active |= InstantComplete;
        if (config::getBool("force-platformer")) active |= Platformer;
        if (tps::changed()) active |= Tps;
        if (config::getBool("hitboxes")) active |= Hitboxes;
        if (config::getBool("trajectory")) active |= Trajectory;
        if (config::getBool("layout")) active |= ShowLayout;
        if (config::getBool("cosmetic.no-mirror")) active |= NoMirror;
        return active;
    }

    std::string duration(int64_t seconds) {
        if (seconds >= 3600) return fmt::format("{}:{:02}:{:02}", seconds / 3600, seconds / 60 % 60, seconds % 60);
        return fmt::format("{}:{:02}", seconds / 60, seconds % 60);
    }

    std::string clockText() {
        auto now = std::time(nullptr);
        std::tm local{};
        localtime_s(&local, &now);
        auto seconds = config::getBool("labels.clock.seconds") ? fmt::format(":{:02}", local.tm_sec) : std::string();
        if (!config::getBool("labels.clock.12h")) return fmt::format("{:02}:{:02}{}", local.tm_hour, local.tm_min, seconds);
        int hour = local.tm_hour % 12 == 0 ? 12 : local.tm_hour % 12;
        return fmt::format("{}:{:02}{} {}", hour, local.tm_min, seconds, local.tm_hour < 12 ? "AM" : "PM");
    }

    int clicksPerSecond() {
        auto now = Clock::now();
        while (!s_clicks.empty() && now - s_clicks.front() > std::chrono::seconds(1)) s_clicks.pop_front();
        return static_cast<int>(s_clicks.size());
    }

    void countFrame() {
        auto now = Clock::now();
        s_frames++;
        auto elapsed = std::chrono::duration<float>(now - s_fpsSince).count();
        if (elapsed < 0.25f) return;
        s_fps = elapsed > 2.f ? 0.f : s_frames / elapsed;
        s_frames = 0;
        s_fpsSince = now;
    }

    std::vector<std::string> lines(PlayLayer* pl) {
        std::vector<std::string> out;
        if (config::getBool("labels.custom")) {
            auto const& text = config::getString("labels.custom.text");
            if (!text.empty()) out.push_back(text);
        }
        if (config::getBool("labels.clock")) out.push_back(clockText());
        if (config::getBool("labels.fps")) out.push_back(fmt::format("{:.0f} FPS", s_fps));
        if (config::getBool("labels.cps")) {
            auto text = fmt::format("{} CPS", clicksPerSecond());
            if (config::getBool("labels.cps.best")) text += fmt::format(" ({} best)", s_mostClicks);
            out.push_back(text);
        }
        if (config::getBool("labels.session")) {
            auto seconds = std::chrono::duration_cast<std::chrono::seconds>(Clock::now() - s_enteredLevel).count();
            out.push_back(fmt::format("Session {}", duration(seconds)));
        }
        if (config::getBool("labels.attempts")) {
            auto text = fmt::format("Attempt {}", pl->m_attempts);
            if (config::getBool("labels.attempts.total") && pl->m_level) {
                text += fmt::format(" ({} total)", pl->m_level->m_attempts.value());
            }
            out.push_back(text);
        }
        if (config::getBool("labels.percent") && !pl->m_isPlatformer) {
            auto decimals = static_cast<int>(config::getInt("labels.percent.decimals"));
            out.push_back(fmt::format("{:.{}f}%", std::clamp(pl->getCurrentPercent(), 0.f, 100.f), decimals));
        }
        // GD counts progress twice per tick
        if (config::getBool("labels.frame")) out.push_back(fmt::format("Frame {}", pl->m_gameState.m_currentProgress / 2));
        bool noclipOn = config::getBool("noclip") && !bot::isRunning();
        if (noclipOn && config::getBool("labels.noclip-accuracy")) {
            out.push_back(fmt::format("Accuracy {:.2f}%", noclip::accuracy()));
        }
        if (noclipOn && config::getBool("labels.noclip-deaths")) {
            out.push_back(fmt::format("Deaths {}", noclip::deaths()));
        }
        return out;
    }

    class LabelsNode : public CCNode {
        std::vector<CCLabelBMFont*> m_lines;
        CCDrawNode* m_indicator = nullptr;
        // What the indicator was last drawn as, so it's only redrawn on a change
        int m_indicatorState = -1;

    public:
        static LabelsNode* create() {
            auto node = new LabelsNode();
            if (node->init()) {
                node->autorelease();
                return node;
            }
            delete node;
            return nullptr;
        }

        bool init() override {
            if (!CCNode::init()) return false;
            m_indicator = CCDrawNode::create();
            // Colors aren't premultiplied, so see-through ones blend right
            m_indicator->setBlendFunc({ GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA });
            addChild(m_indicator);
            scheduleUpdate();
            return true;
        }

        void update(float) override {
            auto pl = PlayLayer::get();
            if (!pl) return;
            countFrame();
            s_usedCheats |= activeCheats(pl);
            updateText(pl);
            updateIndicator();
        }

        void updateText(PlayLayer* pl) {
            auto text = lines(pl);
            auto winSize = CCDirector::get()->getWinSize();
            bool right = config::getInt("labels.corner") == 1;
            float scale = 0.35f * static_cast<float>(config::getFloat("labels.size"));
            // The pause button is in the top right corner, GD's FPS counter
            // (when it's on) in the top left
            float x = right ? winSize.width - 5.f : 5.f;
            float y = winSize.height - (right ? 34.f : CCDirector::get()->isDisplayStats() ? 12.f : 4.f);
            auto opacity = labels::opacity();

            for (size_t i = 0; i < std::max(text.size(), m_lines.size()); i++) {
                if (i >= text.size()) {
                    m_lines[i]->setVisible(false);
                    continue;
                }
                if (i >= m_lines.size()) {
                    auto label = CCLabelBMFont::create("", "bigFont.fnt");
                    addChild(label);
                    m_lines.push_back(label);
                }
                auto label = m_lines[i];
                label->setVisible(true);
                if (text[i] != label->getString()) label->setString(text[i].c_str());
                label->setScale(scale);
                label->setOpacity(opacity);
                label->setAnchorPoint({ right ? 1.f : 0.f, 1.f });
                label->setPosition({ x, y });
                y -= label->getContentSize().height * scale;
            }
        }

        // A dot in the bottom right corner: green while this attempt only used
        // what the chosen ruleset allows, red once it used something it bans
        void updateIndicator() {
            bool show = config::getBool("cheat-indicator");
            bool cheating = (s_usedCheats & rulesets::selected().banned) != 0;
            int state = show ? (cheating ? 2 : 1) | (labels::opacity() << 2) : 0;
            if (state == m_indicatorState) return;
            m_indicatorState = state;
            m_indicator->clear();
            if (!show) return;
            auto winSize = CCDirector::get()->getWinSize();
            float alpha = labels::opacity() / 255.f;
            ccColor4F fill = cheating ? ccColor4F{ 1.f, 0.25f, 0.25f, alpha } : ccColor4F{ 0.3f, 0.9f, 0.4f, alpha };
            m_indicator->drawCircle({ winSize.width - 7.f, 7.f }, 3.5f, fill, 0.f, fill, 24);
        }
    };
}

namespace grassy::labels {
    GLubyte opacity() {
        auto transparency = std::clamp<int64_t>(config::getInt("labels.transparency"), 0, 100);
        return static_cast<GLubyte>(std::lround(255.0 * static_cast<double>(100 - transparency) / 100.0));
    }
}

class $modify(LabelsPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        s_enteredLevel = Clock::now();
        s_usedCheats = 0;
        s_clicks.clear();
        s_mostClicks = 0;
        s_frames = 0;
        s_fpsSince = Clock::now();
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;
        if (m_uiLayer) {
            auto node = LabelsNode::create();
            node->setID("labels"_spr);
            m_uiLayer->addChild(node, 1000);
        }
        return true;
    }

    // A new attempt only counts the cheats still on
    void resetLevel() {
        PlayLayer::resetLevel();
        s_usedCheats = activeCheats(this);
    }
};

class $modify(LabelsGameLayer, GJBaseGameLayer) {
    // Every press counts as a click, from either player
    void handleButton(bool down, int button, bool isPlayer1) {
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
        if (!down || PlayLayer::get() != static_cast<GJBaseGameLayer*>(this)) return;
        s_clicks.push_back(Clock::now());
        s_mostClicks = std::max(s_mostClicks, clicksPerSecond());
    }
};
