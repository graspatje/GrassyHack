#include "../Config.hpp"
#include "../Hacks.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/CCTextInputNode.hpp>
#include <Geode/modify/CCTransitionScene.hpp>
#include <Geode/modify/CreatorLayer.hpp>
#include <Geode/modify/FLAlertLayer.hpp>
#include <Geode/modify/GJDropDownLayer.hpp>
#include <Geode/modify/GameManager.hpp>
#include <Geode/modify/GameStatsManager.hpp>
#include <Geode/modify/LevelAreaInnerLayer.hpp>
#include <Geode/modify/LevelPage.hpp>
#include <Geode/modify/OptionsLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/RewardUnlockLayer.hpp>
#include <Geode/modify/SecretRewardsLayer.hpp>
#include <Geode/modify/SliderTouchLogic.hpp>

using namespace geode::prelude;
using namespace grassy;

// Hacks for GD's menus: Quick Menus for GD's own screens and popups, fast
// chest opening, a confirm popup for practice mode, the bypasses (practice
// music, locked levels, vaults and shops, icons, sliders, text length), and
// the FPS limit and vertical sync.

namespace {
    // GD's own screens: scene changes, popups and drop-down menus. A level's
    // end screen belongs to the level, so it's left alone.
    bool quickMenus() {
        return config::getBool("menu.quick");
    }

    // Set while GD checks whether something is locked, so the check passes
    int s_bypassStats = 0;
    int s_bypassUGV = 0;
    int s_bypassMainLevels = 0;

    struct Bypass {
        int& depth;
        explicit Bypass(int& value) : depth(value) { depth++; }
        ~Bypass() { depth--; }
    };

    // Chests open this many times faster
    constexpr float kChestSpeed = 5.f;
    // A chest is opening, until its close button shows up
    bool s_openingChest = false;

    void applyFps() {
        auto director = CCDirector::get();
        static bool s_wasUnlocked = false;
        bool unlocked = config::getBool("fps.unlock");
        if (unlocked) {
            double fps = std::clamp(config::getFloat("fps.value"), 15.0, 1000.0);
            double interval = 1.0 / fps;
            if (std::abs(director->getAnimationInterval() - interval) > 1e-9) director->setAnimationInterval(interval);
        }
        else if (s_wasUnlocked) {
            // GD's own FPS setting again
            GameManager::get()->updateCustomFPS();
        }
        s_wasUnlocked = unlocked;
    }

}

namespace grassy::menus {
    float timeScale() {
        return s_openingChest && config::getBool("chests.fast") ? kChestSpeed : 1.f;
    }

    void update() {
        applyFps();
    }

    // GD's own vertical sync setting
    bool vsyncOn() {
        return GameManager::get()->getGameVariable("0030");
    }

    void setVsync(bool enabled) {
        GameManager::get()->setGameVariable("0030", enabled);
        CCApplication::sharedApplication()->toggleVerticalSync(enabled);
    }
}

// Quick Menus

class $modify(QuickTransition, CCTransitionScene) {
    bool initWithDuration(float duration, CCScene* scene) {
        return CCTransitionScene::initWithDuration(quickMenus() ? 0.f : duration, scene);
    }
};

class $modify(QuickAlert, FLAlertLayer) {
    void show() {
        if (quickMenus()) m_noElasticity = true;
        FLAlertLayer::show();
    }
};

class $modify(QuickDropDown, GJDropDownLayer) {
    bool isQuick() {
        return quickMenus() && !typeinfo_cast<EndLevelLayer*>(this);
    }

    void showLayer(bool instant) {
        GJDropDownLayer::showLayer(instant || isQuick());
    }

    void hideLayer(bool instant) {
        GJDropDownLayer::hideLayer(instant || isQuick());
    }
};

// Fast chest opening: the game runs faster while a chest opens

class $modify(FastChestLayer, RewardUnlockLayer) {
    bool showCollectReward(GJRewardItem* item) {
        s_openingChest = true;
        return RewardUnlockLayer::showCollectReward(item);
    }

    void showCloseButton() {
        s_openingChest = false;
        RewardUnlockLayer::showCloseButton();
    }

    void onClose(CCObject* sender) {
        s_openingChest = false;
        RewardUnlockLayer::onClose(sender);
    }
};

// Confirm Practice: entering or leaving practice mode asks first

namespace {
    // Lets the popup's button call through to GD
    bool s_practiceConfirmed = false;
}

class $modify(ConfirmPracticePauseLayer, PauseLayer) {
    void confirm(char const* text, bool entering) {
        Ref<PauseLayer> self = this;
        createQuickPopup("Practice Mode", text, "Cancel", entering ? "Practice" : "Leave", [self, entering](FLAlertLayer*, bool yes) {
            if (!yes) return;
            s_practiceConfirmed = true;
            if (entering) self->onPracticeMode(nullptr);
            else self->onNormalMode(nullptr);
            s_practiceConfirmed = false;
        });
    }

    void onPracticeMode(CCObject* sender) {
        if (s_practiceConfirmed || !config::getBool("confirm-practice")) return PauseLayer::onPracticeMode(sender);
        confirm("Enter <cg>practice mode</c>?", true);
    }

    void onNormalMode(CCObject* sender) {
        if (s_practiceConfirmed || !config::getBool("confirm-practice")) return PauseLayer::onNormalMode(sender);
        confirm("Leave <cg>practice mode</c>? Your checkpoints will be gone.", false);
    }
};

// Practice music: plays the level's song in practice mode. That's GD's own
// "practice music sync" option, normally bought in the shop.

class $modify(PracticeMusicPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;
        if (config::getBool("bypass.practice-music")) m_practiceMusicSync = true;
        return true;
    }

    void togglePracticeMode(bool practiceMode) {
        if (config::getBool("bypass.practice-music")) m_practiceMusicSync = true;
        PlayLayer::togglePracticeMode(practiceMode);
    }
};

// Unlocks

class $modify(UnlockGameStats, GameStatsManager) {
    bool isItemUnlocked(UnlockType type, int id) {
        if (config::getBool("bypass.unlock-all")) return true;
        // GJItem 17 is practice music sync
        if (type == UnlockType::GJItem && id == 17 && config::getBool("bypass.practice-music")) return true;
        return GameStatsManager::isItemUnlocked(type, id);
    }

    bool isStoreItemUnlocked(int index) {
        if (config::getBool("bypass.unlock-all")) return true;
        return GameStatsManager::isStoreItemUnlocked(index);
    }

    int getStat(char const* key) {
        // Enough of anything a lock asks for (diamonds, coins, keys)
        if (s_bypassStats > 0) return std::max(GameStatsManager::getStat(key), 100000);
        return GameStatsManager::getStat(key);
    }

    bool hasCompletedMainLevel(int levelID) {
        if (s_bypassMainLevels > 0) return true;
        return GameStatsManager::hasCompletedMainLevel(levelID);
    }
};

class $modify(UnlockGameManager, GameManager) {
    bool isIconUnlocked(int id, IconType type) {
        if (config::getBool("bypass.unlock-all")) return true;
        return GameManager::isIconUnlocked(id, type);
    }

    bool isColorUnlocked(int id, UnlockType type) {
        if (config::getBool("bypass.unlock-all")) return true;
        return GameManager::isColorUnlocked(id, type);
    }

    bool getUGV(char const* key) {
        if (s_bypassUGV > 0) return true;
        return GameManager::getUGV(key);
    }
};

// The vaults: the Vault of Secrets (diamonds), the Treasure Room (keys) and
// the vault in the settings (coins)

class $modify(UnlockCreatorLayer, CreatorLayer) {
    void onSecretVault(CCObject* sender) {
        if (!config::getBool("bypass.unlock-all")) return CreatorLayer::onSecretVault(sender);
        Bypass bypass(s_bypassStats);
        CreatorLayer::onSecretVault(sender);
    }

    void onTreasureRoom(CCObject* sender) {
        if (!config::getBool("bypass.unlock-all")) return CreatorLayer::onTreasureRoom(sender);
        // GD goes straight in once it's unlocked, so it isn't unlocked in the save
        Bypass bypass(s_bypassUGV);
        CreatorLayer::onTreasureRoom(sender);
    }
};

class $modify(UnlockOptionsLayer, OptionsLayer) {
    void onSecretVault(CCObject* sender) {
        if (!config::getBool("bypass.unlock-all")) return OptionsLayer::onSecretVault(sender);
        Bypass bypass(s_bypassStats);
        OptionsLayer::onSecretVault(sender);
    }
};

// The shops in the Treasure Room
class $modify(UnlockSecretRewardsLayer, SecretRewardsLayer) {
    void onShop(CCObject* sender) {
        if (!config::getBool("bypass.unlock-all")) return SecretRewardsLayer::onShop(sender);
        Bypass bypass(s_bypassUGV);
        SecretRewardsLayer::onShop(sender);
    }
};

// Main levels that need secret coins (Clubstep, Theory of Everything 2,
// Deadlocked) and the Tower's doors that need the floor before them
class $modify(UnlockLevelPage, LevelPage) {
    void onPlay(CCObject* sender) {
        if (!config::getBool("bypass.main-levels")) return LevelPage::onPlay(sender);
        Bypass bypass(s_bypassStats);
        LevelPage::onPlay(sender);
    }
};

class $modify(UnlockTowerLayer, LevelAreaInnerLayer) {
    // Which doors are open is decided when the Tower is shown
    bool init(bool returning) {
        if (!config::getBool("bypass.main-levels")) return LevelAreaInnerLayer::init(returning);
        Bypass bypass(s_bypassMainLevels);
        return LevelAreaInnerLayer::init(returning);
    }
};

// Slider limit: GD keeps a slider's knob between the ends of the bar. This is
// GD's own code without that limit.
class $modify(UnlimitedSlider, SliderTouchLogic) {
    void ccTouchMoved(CCTouch* touch, CCEvent* event) {
        if (!config::getBool("bypass.slider") || !m_thumb) return SliderTouchLogic::ccTouchMoved(touch, event);
        auto position = convertTouchToNodeSpace(touch) - m_position;
        m_thumb->setPosition(m_rotated ? CCPoint{ 0.f, position.y } : CCPoint{ position.x, 0.f });
        if (m_activateThumb) m_thumb->activate();
        if (m_slider) m_slider->updateBar();
    }
};

// Text length: text boxes take as many characters as you type
class $modify(UnlimitedTextInput, CCTextInputNode) {
    bool onTextFieldInsertText(CCTextFieldTTF* field, char const* text, int length, enumKeyCodes key) {
        if (config::getBool("bypass.text-length")) m_maxLabelLength = 100000;
        return CCTextInputNode::onTextFieldInsertText(field, text, length, key);
    }
};
