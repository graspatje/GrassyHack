#include "../Config.hpp"
#include "../Hacks.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <vector>

using namespace geode::prelude;
using namespace grassy;

// Remembers where you died in each level: a red cross at each spot (bigger the
// more you died there, with the count next to it), and deaths per percent for
// the chart in the menu. Each level's deaths are a file in the mod's save
// folder (deaths/). Deaths while the bot runs aren't counted, and with noclip
// on you don't die.

namespace {
    // Deaths closer than this (in level units, a block is 30) share a cross
    constexpr float kMergeDistance = 15.f;
    constexpr auto kSaveInterval = std::chrono::seconds(5);

    struct Marker {
        float x = 0.f;
        float y = 0.f;
        int count = 0;
    };

    bool s_inLevel = false;
    deaths::Summary s_summary;
    std::vector<Marker> s_markers;
    std::filesystem::path s_file;
    bool s_dirty = false;
    std::chrono::steady_clock::time_point s_lastSave;
    // The crosses need drawing again (a death, an option or the transparency changed)
    bool s_redraw = true;
    GLubyte s_drawnOpacity = 0;

    std::string fileName(GJGameLevel* level) {
        if (level->m_levelType == GJLevelType::Main) return fmt::format("main-{}", level->m_levelID.value());
        if (level->m_levelType != GJLevelType::Editor) return fmt::format("{}", level->m_levelID.value());
        // Your own levels have no ID, so they go by name
        std::string name = level->m_levelName;
        for (auto& c : name) {
            if (!std::isalnum(static_cast<unsigned char>(c))) c = '_';
        }
        return fmt::format("local-{}", name.substr(0, 60));
    }

    void load(PlayLayer* pl) {
        s_inLevel = true;
        s_summary = {};
        s_summary.levelName = pl->m_level->m_levelName;
        s_summary.platformer = pl->m_isPlatformer;
        s_markers.clear();
        s_dirty = false;
        s_redraw = true;
        s_file = Mod::get()->getSaveDir() / "deaths" / (fileName(pl->m_level) + ".json");

        // No file yet means no deaths yet
        auto json = utils::file::readJson(s_file);
        if (!json) return;
        auto const& data = json.unwrap();
        s_summary.total = static_cast<int>(data["total"].asInt().unwrapOr(0));
        auto const& percents = data["percents"];
        for (size_t i = 0; percents.isArray() && i < percents.size() && i < s_summary.percents.size(); i++) {
            s_summary.percents[i] = static_cast<int>(percents[i].asInt().unwrapOr(0));
        }
        auto const& markers = data["markers"];
        for (size_t i = 0; markers.isArray() && i < markers.size(); i++) {
            // [x, y, count]
            auto const& entry = markers[i];
            Marker marker;
            marker.x = static_cast<float>(entry[0].asDouble().unwrapOr(0.0));
            marker.y = static_cast<float>(entry[1].asDouble().unwrapOr(0.0));
            marker.count = static_cast<int>(entry[2].asInt().unwrapOr(0));
            if (marker.count > 0) s_markers.push_back(marker);
        }
    }

    void save() {
        if (!s_dirty || s_file.empty()) return;
        s_dirty = false;
        s_lastSave = std::chrono::steady_clock::now();
        std::error_code error;
        if (s_summary.total <= 0) {
            std::filesystem::remove(s_file, error);
            return;
        }
        auto markers = matjson::Value::array();
        for (auto const& marker : s_markers) {
            auto entry = matjson::Value::array();
            entry.push(std::round(static_cast<double>(marker.x) * 10.0) / 10.0);
            entry.push(std::round(static_cast<double>(marker.y) * 10.0) / 10.0);
            entry.push(marker.count);
            markers.push(entry);
        }
        auto percents = matjson::Value::array();
        for (int count : s_summary.percents) percents.push(count);
        auto data = matjson::makeObject({
            { "level", s_summary.levelName },
            { "total", s_summary.total },
            { "percents", percents },
            { "markers", markers },
        });
        std::filesystem::create_directories(s_file.parent_path(), error);
        if (auto result = utils::file::writeStringSafe(s_file, data.dump(matjson::NO_INDENTATION)); result.isErr()) {
            log::warn("Couldn't save deaths: {}", result.unwrapErr());
        }
    }

    void addDeath(PlayLayer* pl, PlayerObject* player) {
        auto position = player->m_position;
        auto found = std::find_if(s_markers.begin(), s_markers.end(), [&](Marker const& marker) {
            return std::abs(marker.x - position.x) <= kMergeDistance && std::abs(marker.y - position.y) <= kMergeDistance;
        });
        if (found == s_markers.end()) {
            s_markers.push_back({ position.x, position.y, 1 });
        }
        else {
            // The cross moves to the middle of its deaths
            found->x = (found->x * found->count + position.x) / (found->count + 1);
            found->y = (found->y * found->count + position.y) / (found->count + 1);
            found->count++;
        }
        if (!pl->m_isPlatformer) {
            auto percent = static_cast<int>(std::clamp(pl->getCurrentPercent(), 0.f, 100.f));
            s_summary.percents[percent]++;
        }
        s_summary.total++;
        s_dirty = true;
        s_redraw = true;
        if (std::chrono::steady_clock::now() - s_lastSave > kSaveInterval) save();
    }

    void drawMarkers(PlayLayer* pl) {
        if (!pl || !pl->m_objectLayer) return;
        bool show = config::getBool("deaths") && config::getBool("deaths.markers") && !bot::isRunning();
        auto node = pl->m_objectLayer->getChildByID("death-markers"_spr);
        if (!node) {
            if (!show) return;
            node = CCNode::create();
            node->setID("death-markers"_spr);
            // Above the level's objects
            pl->m_objectLayer->addChild(node, 9999);
        }
        node->setVisible(show);
        auto opacity = labels::opacity();
        if (!show || (!s_redraw && opacity == s_drawnOpacity)) return;
        s_redraw = false;
        s_drawnOpacity = opacity;

        node->removeAllChildren();
        auto crosses = CCDrawNode::create();
        // Colors aren't premultiplied, so see-through ones blend right
        crosses->setBlendFunc({ GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA });
        node->addChild(crosses);
        float alpha = opacity / 255.f;
        ccColor4F outline = { 0.f, 0.f, 0.f, 0.6f * alpha };
        ccColor4F red = { 1.f, 0.2f, 0.2f, alpha };
        for (auto const& marker : s_markers) {
            // Bigger the more deaths, up to twice the size
            float half = 4.f + 4.f * std::min(marker.count - 1, 20) / 20.f;
            CCPoint center = { marker.x, marker.y };
            for (int pass = 0; pass < 2; pass++) {
                float radius = pass == 0 ? 2.2f : 1.2f;
                auto const& color = pass == 0 ? outline : red;
                crosses->drawSegment(center + CCPoint{ -half, -half }, center + CCPoint{ half, half }, radius, color);
                crosses->drawSegment(center + CCPoint{ -half, half }, center + CCPoint{ half, -half }, radius, color);
            }
            if (marker.count > 1) {
                auto label = CCLabelBMFont::create(fmt::format("{}", marker.count).c_str(), "bigFont.fnt");
                label->setScale(0.3f);
                label->setOpacity(opacity);
                label->setAnchorPoint({ 0.f, 0.f });
                label->setPosition(center + CCPoint{ half + 1.f, half - 2.f });
                node->addChild(label);
            }
        }
    }
}

namespace grassy::deaths {
    Summary const* current() {
        return s_inLevel ? &s_summary : nullptr;
    }

    void clearCurrent() {
        if (!s_inLevel) return;
        s_summary.total = 0;
        s_summary.percents.fill(0);
        s_markers.clear();
        s_dirty = true;
        s_redraw = true;
        save();
        drawMarkers(PlayLayer::get());
    }

    void refresh() {
        drawMarkers(PlayLayer::get());
    }
}

class $modify(DeathTrackerPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        s_inLevel = false;
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;
        load(this);
        drawMarkers(this);
        return true;
    }

    void destroyPlayer(PlayerObject* player, GameObject* object) {
        bool wasDead = player && player->m_isDead;
        PlayLayer::destroyPlayer(player, object);
        if (!s_inLevel || wasDead || !player || !player->m_isDead || object == m_anticheatSpike) return;
        if (!config::getBool("deaths") || bot::isRunning()) return;
        if (m_isPracticeMode && !config::getBool("deaths.practice")) return;
        addDeath(this, player);
        drawMarkers(this);
    }

    void pauseGame(bool unfocused) {
        save();
        PlayLayer::pauseGame(unfocused);
    }

    void onQuit() {
        save();
        s_inLevel = false;
        s_file.clear();
        PlayLayer::onQuit();
    }
};

$on_game(Exiting) {
    save();
}
