#include "../Config.hpp"
#include "../Hacks.hpp"

#include <Geode/Geode.hpp>
#include <Geode/utils/web.hpp>

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstdlib>
#include <functional>
#include <thread>
#include <utility>

using namespace geode::prelude;
using namespace grassy;

// The AI chat. It talks to Groq (groq.com), which runs AI models for free
// with a limit on how many messages an account can send. Every player puts
// in their own free key, kept in their saved options, so nobody's messages
// count against anyone else. The AI can turn hacks on and off for you.

namespace {
    using Who = chat::Line::Who;

    constexpr char const* kUrl = "https://api.groq.com/openai/v1/chat/completions";
    constexpr char const* kModelsUrl = "https://api.groq.com/openai/v1/models";
    // Groq retires old models now and then. When the chosen one is gone, the
    // first of these Groq still has is used instead.
    constexpr char const* kFallbackModels[] = { "openai/gpt-oss-20b", "openai/gpt-oss-120b" };
    // Models that aren't for chatting (speech, safety checks)
    constexpr char const* kNotChatModels[] = { "whisper", "guard", "tts", "orpheus", "compound", "playai" };
    // How many times in a row the AI can change hacks before it has to answer
    constexpr int kMaxToolRounds = 4;
    // Older messages are left out, so requests stay small: the free plan
    // also limits how much can be sent per minute
    constexpr size_t kMaxHistory = 16;

    std::vector<chat::Line> s_lines;
    // The conversation as it's sent to Groq: user, assistant and tool messages
    std::vector<matjson::Value> s_messages;
    std::vector<chat::Hack> s_hacks;
    // Where the question being answered starts in s_messages, so it can be
    // taken back out when something goes wrong
    size_t s_questionStart = 0;
    int s_toolRounds = 0;
    int s_changes = 0;
    bool s_busy = false;
    // Goes up when the chat is cleared, so an answer to the old chat is dropped
    int s_generation = 0;
    // Already switched models for this question, so it doesn't go round in circles
    bool s_switchedModel = false;

    void addLine(Who who, std::string text) {
        s_lines.push_back({ who, std::move(text) });
        s_changes++;
    }

    std::string lower(std::string_view text) {
        std::string out(text);
        std::transform(out.begin(), out.end(), out.begin(), [](unsigned char c) { return std::tolower(c); });
        return out;
    }

    std::string trim(std::string_view text) {
        auto isSpace = [](unsigned char c) { return std::isspace(c); };
        while (!text.empty() && isSpace(text.front())) text.remove_prefix(1);
        while (!text.empty() && isSpace(text.back())) text.remove_suffix(1);
        return std::string(text);
    }

    chat::Hack const* findHack(std::string_view name) {
        auto wanted = lower(trim(name));
        for (auto const& hack : s_hacks) {
            if (lower(hack.name) == wanted || hack.option == wanted) return &hack;
        }
        return nullptr;
    }

    // Small models sometimes send true as "true", or a number as "2"
    std::optional<bool> readBool(matjson::Value const& value) {
        if (value.isBool()) return value.asBool().unwrapOr(false);
        if (value.isString()) {
            auto text = lower(trim(value.asString().unwrapOr("")));
            if (text == "true" || text == "on" || text == "yes") return true;
            if (text == "false" || text == "off" || text == "no") return false;
        }
        return std::nullopt;
    }

    std::optional<double> readNumber(matjson::Value const& value) {
        if (value.isNumber()) return value.asDouble().unwrapOr(1.0);
        if (value.isString()) {
            auto text = value.asString().unwrapOr("");
            char* end = nullptr;
            double number = std::strtod(text.c_str(), &end);
            if (end != text.c_str()) return number;
        }
        return std::nullopt;
    }

    std::string systemPrompt() {
        std::string all;
        std::string on;
        std::string_view group;
        for (auto const& hack : s_hacks) {
            if (hack.group != group) {
                group = hack.group;
                all += fmt::format("{}{} window: ", all.empty() ? "" : ". ", group);
            }
            else {
                all += ", ";
            }
            all += hack.name;
            if (config::getBool(hack.option)) on += fmt::format("{}{}", on.empty() ? "" : ", ", hack.name);
        }

        std::string tools = config::getBool("chat.tools")
            ? "You can turn hacks on or off with set_hack and change the game speed with set_speed. Only do that when "
              "the player asks, then say what you changed. Safe Mode (on unless the player turned it off) stops runs "
              "with cheats like noclip from saving progress."
            : "You can't change hacks, the player turned that off in the chat's settings. Tell them which hack to use "
              "and which window it's in instead.";

        return fmt::format(
            "You are the chat helper inside GrassyHack, a free mod menu for Geometry Dash 2.2081, made by graspatje "
            "with Geode. The menu opens with Tab unless the player changed its key. Every hack is a row with a switch: "
            "clicking it turns the hack on or off, right-clicking it shows its options and its keybind.\n\n"
            "Talk like a friendly gamer: casual, plain words, and short answers (one to three sentences) unless the "
            "player asks for more. Don't use markdown, lists or headings, the chat only shows plain text. If you're "
            "not sure about something in Geometry Dash, say so instead of making it up.\n\n"
            "{}\n\nHacks in GrassyHack: {}.\n\nTurned on right now: {}. Speedhack speed: {:.2f}x.",
            tools, all, on.empty() ? "nothing" : on, config::getFloat("speedhack.value"));
    }

    matjson::Value tools() {
        auto setHack = matjson::makeObject({
            { "name", "set_hack" },
            { "description", "Turns one of GrassyHack's hacks on or off." },
            { "parameters", matjson::makeObject({
                { "type", "object" },
                { "properties", matjson::makeObject({
                    { "hack", matjson::makeObject({
                        { "type", "string" },
                        { "description", "The hack's name, as in the list of hacks, like Noclip" },
                    }) },
                    { "on", matjson::makeObject({
                        { "type", "boolean" },
                        { "description", "true turns it on, false turns it off" },
                    }) },
                }) },
                { "required", std::vector<matjson::Value>{ "hack", "on" } },
            }) },
        });
        auto setSpeed = matjson::makeObject({
            { "name", "set_speed" },
            { "description", "Sets how fast the whole game runs (the speedhack). 1 is normal speed, 0.5 is half, 2 is "
                "double. Anything but 1 turns the speedhack on, 1 turns it off." },
            { "parameters", matjson::makeObject({
                { "type", "object" },
                { "properties", matjson::makeObject({
                    { "speed", matjson::makeObject({
                        { "type", "number" },
                        { "description", "From 0.1 to 10" },
                    }) },
                }) },
                { "required", std::vector<matjson::Value>{ "speed" } },
            }) },
        });
        auto list = matjson::Value::array();
        list.push(matjson::makeObject({ { "type", "function" }, { "function", setHack } }));
        list.push(matjson::makeObject({ { "type", "function" }, { "function", setSpeed } }));
        return list;
    }

    // Does what the AI asked for and returns what to tell it back
    std::string runTool(std::string_view name, matjson::Value const& args) {
        if (name == "set_hack") {
            auto hackName = args["hack"].asString().unwrapOr("");
            auto hack = findHack(hackName);
            if (!hack) return fmt::format("There's no hack called \"{}\". Use a name from the list.", hackName);
            auto on = readBool(args["on"]);
            if (!on) return "Say whether to turn it on (true) or off (false).";
            config::setBool(hack->option, *on);
            addLine(Who::Info, fmt::format("Turned {} {}", hack->name, *on ? "on" : "off"));
            return fmt::format("{} is {} now.", hack->name, *on ? "on" : "off");
        }
        if (name == "set_speed") {
            auto speed = readNumber(args["speed"]);
            if (!speed) return "Give the speed as a number, like 0.5.";
            double value = std::clamp(*speed, 0.1, 10.0);
            config::setFloat("speedhack.value", value);
            config::setBool("speedhack", value != 1.0);
            addLine(Who::Info, value == 1.0 ? "Set the speed back to normal" : fmt::format("Set the speed to {:.2f}x", value));
            return fmt::format("The game runs at {:.2f}x now.", value);
        }
        return fmt::format("There's no tool called {}.", name);
    }

    void fail(std::string text) {
        // Taken back out, so the next question isn't sent after a half-answered one
        s_messages.resize(s_questionStart);
        s_toolRounds = 0;
        addLine(Who::Error, std::move(text));
    }

    // Groq's error message and code ("model_not_found" and so on)
    std::pair<std::string, std::string> groqError(web::WebResponse const& response) {
        auto json = response.json();
        if (json.isErr()) return {};
        auto const& error = std::as_const(json.unwrap())["error"];
        return { error["message"].asString().unwrapOr(""), error["code"].asString().unwrapOr("") };
    }

    bool modelGone(web::WebResponse const& response) {
        auto [message, code] = groqError(response);
        return code == "model_not_found" || code == "model_decommissioned" ||
            message.find("does not exist") != std::string::npos || message.find("decommissioned") != std::string::npos;
    }

    std::string errorText(web::WebResponse const& response) {
        int code = response.code();
        auto [message, _] = groqError(response);
        if (code == 401) return "Groq says this key doesn't work. Check it in the chat's settings.";
        if (code == 429) {
            // Groq says how long to wait, like "Please try again in 7m12.5s."
            // The rest isn't shown, it has the account's id in it.
            auto at = message.find("try again in ");
            if (at != std::string::npos) {
                auto wait = message.substr(at + 13);
                wait = wait.substr(0, wait.find_first_of(" ,"));
                if (wait.ends_with(".")) wait.pop_back();
                return fmt::format("Groq's free plan limit is used up for now. Try again in {}.", wait);
            }
            return "That's too many messages for Groq's free plan right now. Wait a minute, then try again.";
        }
        if (code < 100) return "Couldn't reach Groq. Check your internet.";
        return message.empty() ? fmt::format("Groq sent back error {}.", code) : fmt::format("Groq: {}", message);
    }

    // Waits for Groq on its own thread, so the game doesn't freeze, then
    // hands the answer over on the main thread
    void sendInBackground(web::WebRequest req, std::string method, std::string url,
            std::function<void(web::WebResponse const&)> done) {
        s_busy = true;
        std::thread([req = std::move(req), method = std::move(method), url = std::move(url), done = std::move(done),
                generation = s_generation]() mutable {
            auto response = req.sendSync(method, url);
            queueInMainThread([response = std::move(response), done = std::move(done), generation] {
                if (generation != s_generation) return;
                s_busy = false;
                done(response);
            });
        }).detach();
    }

    web::WebRequest groqRequest() {
        auto req = web::WebRequest();
        req.header("Authorization", fmt::format("Bearer {}", trim(config::getString("chat.key"))));
        req.timeout(std::chrono::seconds(60));
        return req;
    }

    void answered(web::WebResponse const& response);

    void request() {
        auto messages = matjson::Value::array();
        messages.push(matjson::makeObject({ { "role", "system" }, { "content", systemPrompt() } }));
        // The oldest messages are left out, starting from a question so no
        // answer is sent without the question before it
        size_t first = 0;
        if (s_messages.size() > kMaxHistory) {
            first = s_messages.size() - kMaxHistory;
            while (first < s_questionStart && s_messages[first]["role"] != matjson::Value("user")) first++;
        }
        for (size_t i = first; i < s_messages.size(); i++) messages.push(s_messages[i]);

        auto body = matjson::makeObject({
            { "model", config::getString("chat.model") },
            { "messages", messages },
            { "max_completion_tokens", 1024 },
            { "temperature", 0.7 },
        });
        if (config::getBool("chat.tools")) {
            body.set("tools", tools());
            body.set("tool_choice", "auto");
        }
        // OpenAI's models think before answering. A little is plenty for a
        // chat, and the thinking itself isn't sent back.
        if (config::getString("chat.model").starts_with("openai/gpt-oss")) {
            body.set("reasoning_effort", "low");
            body.set("include_reasoning", false);
        }

        auto req = groqRequest();
        req.bodyJSON(body);
        sendInBackground(std::move(req), "POST", kUrl, answered);
    }

    // The chosen model is gone, so this asks Groq which ones it has, picks
    // another and asks the question again
    void switchModel() {
        s_switchedModel = true;
        sendInBackground(groqRequest(), "GET", kModelsUrl, [](web::WebResponse const& response) {
            if (!response.ok()) return fail(errorText(response));
            std::vector<std::string> models;
            if (auto json = response.json(); json.isOk()) {
                for (auto const& model : std::as_const(json.unwrap())["data"]) {
                    if (model["active"] == matjson::Value(false)) continue;
                    if (auto id = model["id"].asString(); id.isOk()) models.push_back(id.unwrap());
                }
            }
            std::string picked;
            for (auto fallback : kFallbackModels) {
                if (picked.empty() && std::find(models.begin(), models.end(), fallback) != models.end()) picked = fallback;
            }
            for (auto const& model : models) {
                if (!picked.empty()) break;
                bool chats = std::none_of(std::begin(kNotChatModels), std::end(kNotChatModels), [&](char const* word) {
                    return model.find(word) != std::string::npos;
                });
                if (chats) picked = model;
            }
            if (picked.empty() || picked == config::getString("chat.model")) {
                return fail("Groq doesn't have this AI model anymore, and GrassyHack couldn't find another one. "
                    "Pick one in the chat's settings.");
            }
            config::setString("chat.model", picked);
            addLine(Who::Info, fmt::format("That AI model is gone, switched to {}", picked));
            request();
        });
    }

    void answered(web::WebResponse const& response) {
        if (response.cancelled()) return;
        if (!response.ok()) {
            if (!s_switchedModel && modelGone(response)) return switchModel();
            return fail(errorText(response));
        }
        auto json = response.json();
        if (json.isErr()) return fail("Groq sent back something GrassyHack can't read.");
        auto root = std::move(json).unwrap();
        auto const& message = std::as_const(root)["choices"][size_t{ 0 }]["message"];

        auto const& calls = message["tool_calls"];
        if (calls.isArray() && calls.size() > 0) {
            if (++s_toolRounds > kMaxToolRounds) return fail("The AI got stuck changing hacks. Try asking again.");
            // Sent back as it came, so the answers below match its calls
            s_messages.push_back(matjson::makeObject({
                { "role", "assistant" },
                { "content", message["content"].isString() ? message["content"] : matjson::Value(nullptr) },
                { "tool_calls", calls },
            }));
            for (auto const& call : calls) {
                auto name = call["function"]["name"].asString().unwrapOr("");
                auto args = matjson::parse(call["function"]["arguments"].asString().unwrapOr("{}"))
                    .unwrapOr(matjson::Value::object());
                s_messages.push_back(matjson::makeObject({
                    { "role", "tool" },
                    { "tool_call_id", call["id"] },
                    { "name", name },
                    { "content", runTool(name, args) },
                }));
            }
            return request();
        }

        auto text = trim(message["content"].asString().unwrapOr(""));
        if (text.empty()) return fail("The AI didn't say anything. Try asking again.");
        s_messages.push_back(matjson::makeObject({ { "role", "assistant" }, { "content", text } }));
        s_toolRounds = 0;
        addLine(Who::Ai, std::move(text));
    }
}

namespace grassy::chat {
    std::vector<Line> const& lines() {
        return s_lines;
    }

    int changes() {
        return s_changes;
    }

    bool busy() {
        return s_busy;
    }

    bool hasKey() {
        return !trim(config::getString("chat.key")).empty();
    }

    void send(std::string text, std::vector<Hack> hacks) {
        text = trim(text);
        if (text.empty() || busy()) return;
        s_hacks = std::move(hacks);
        addLine(Who::You, text);
        s_questionStart = s_messages.size();
        s_toolRounds = 0;
        s_switchedModel = false;
        s_messages.push_back(matjson::makeObject({ { "role", "user" }, { "content", text } }));
        request();
    }

    void clear() {
        s_generation++;
        s_busy = false;
        s_lines.clear();
        s_messages.clear();
        s_questionStart = 0;
        s_toolRounds = 0;
        s_changes++;
    }
}
