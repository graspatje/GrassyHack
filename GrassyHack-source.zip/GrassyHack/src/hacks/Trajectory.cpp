#include "../Config.hpp"
#include "../Hacks.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/EnhancedGameObject.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PlayerObject.hpp>
#include <Geode/modify/RingObject.hpp>

#include <unordered_set>

using namespace geode::prelude;
using namespace grassy;

// Show Trajectory: every frame an invisible copy of player 1 is played ahead
// through the real level twice, once holding and once not, and its path is
// drawn. While the copy runs, everything it would do to the level (collect
// coins, use up pads and orbs, start triggers, switch dual mode, move the
// camera, play effects) is skipped.

namespace {
    constexpr int kTicks = 240;

    PlayerObject* s_fake = nullptr;
    CCDrawNode* s_drawNode = nullptr;
    PlayerCheckpoint* s_checkpoint = nullptr;
    // The copy is being played ahead right now
    bool s_simulating = false;
    // Pads and orbs the copy used in this run, which the real player didn't
    std::unordered_set<GameObject*> s_fakeActivated;

    bool isFake(PlayerObject* player) {
        return s_simulating && player && player == s_fake;
    }

    // The copy and its trails are never drawn
    void hideFake() {
        s_fake->setVisible(false);
        for (CCNode* node : { static_cast<CCNode*>(s_fake->m_regularTrail), static_cast<CCNode*>(s_fake->m_waveTrail),
                static_cast<CCNode*>(s_fake->m_shipStreak) }) {
            if (node) node->setVisible(false);
        }
    }

    void cleanup() {
        if (s_fake) s_fake->release();
        if (s_checkpoint) s_checkpoint->release();
        s_fake = nullptr;
        s_checkpoint = nullptr;
        s_drawNode = nullptr;
    }

    void setup(PlayLayer* pl) {
        cleanup();
        if (!pl->m_objectLayer) return;
        s_fake = PlayerObject::create(1, 1, pl, pl->m_objectLayer, false);
        if (!s_fake) return;
        s_fake->retain();
        hideFake();
        s_checkpoint = PlayerCheckpoint::create();
        s_checkpoint->retain();
        s_drawNode = CCDrawNode::create();
        s_drawNode->setBlendFunc({ GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA });
        s_drawNode->setID("trajectory"_spr);
        pl->m_objectLayer->addChild(s_drawNode, 9998);
    }

    // Plays the copy ahead and draws where it goes
    void simulate(PlayLayer* pl, bool holding, ccColor4F color) {
        auto real = pl->m_player1;
        real->saveToCheckpoint(s_checkpoint);
        s_fake->loadFromCheckpoint(s_checkpoint);
        s_fake->m_isDead = false;
        hideFake();
        s_fakeActivated.clear();

        // Player collision blocks follow the players, so they're put back afterwards
        CCPoint block1 = pl->m_player1CollisionBlock ? pl->m_player1CollisionBlock->getPosition() : CCPoint{};
        CCPoint block2 = pl->m_player2CollisionBlock ? pl->m_player2CollisionBlock->getPosition() : CCPoint{};

        s_simulating = true;
        if (holding) s_fake->pushButton(PlayerButton::Jump);
        else s_fake->releaseButton(PlayerButton::Jump);

        float dt = static_cast<float>(60.0 / tps::value()) * std::min(1.f, pl->m_gameState.m_timeWarp);
        CCPoint last = s_fake->getPosition();
        for (int tick = 0; tick < kTicks; tick++) {
            s_fake->update(dt);
            pl->checkCollisions(s_fake, dt, false);
            if (s_fake->m_isDead) {
                // Dying right away happens while the player respawns, it means nothing
                if (tick == 0) break;
                // A cross where the copy dies
                auto rect = s_fake->getObjectRect();
                s_drawNode->drawSegment({ rect.getMinX(), rect.getMinY() }, { rect.getMaxX(), rect.getMaxY() }, 0.8f, color);
                s_drawNode->drawSegment({ rect.getMinX(), rect.getMaxY() }, { rect.getMaxX(), rect.getMinY() }, 0.8f, color);
                break;
            }
            auto position = s_fake->getPosition();
            s_drawNode->drawSegment(last, position, 0.6f, color);
            last = position;
        }
        s_simulating = false;

        if (pl->m_player1CollisionBlock) pl->m_player1CollisionBlock->setPosition(block1);
        if (pl->m_player2CollisionBlock) pl->m_player2CollisionBlock->setPosition(block2);
    }

    void drawTrajectory(PlayLayer* pl) {
        if (!s_drawNode) return;
        s_drawNode->clear();
        bool show = config::getBool("trajectory") && s_fake && pl->m_player1 && !pl->m_player1->m_isDead &&
            !pl->m_hasCompletedLevel && !pl->m_levelEndAnimationStarted;
        s_drawNode->setVisible(show);
        if (!show) return;
        simulate(pl, true, { 0.35f, 1.f, 0.4f, 0.9f });
        simulate(pl, false, { 1.f, 0.35f, 0.35f, 0.9f });
    }
}

class $modify(TrajectoryPlayLayer, PlayLayer) {
    static void onModify(auto& self) {
        // Before noclip, the death tracker and the rest see the copy die
        (void)self.setHookPriorityPre("PlayLayer::destroyPlayer", Priority::First);
    }

    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        cleanup();
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;
        setup(this);
        return true;
    }

    void destroyPlayer(PlayerObject* player, GameObject* object) {
        if (isFake(player)) {
            player->m_isDead = true;
            return;
        }
        PlayLayer::destroyPlayer(player, object);
    }

    void postUpdate(float dt) {
        PlayLayer::postUpdate(dt);
        drawTrajectory(this);
    }

    void onQuit() {
        cleanup();
        PlayLayer::onQuit();
    }
};

class $modify(TrajectoryGameLayer, GJBaseGameLayer) {
    void playerTouchedTrigger(PlayerObject* player, EffectGameObject* object) {
        if (s_simulating) return;
        GJBaseGameLayer::playerTouchedTrigger(player, object);
    }

    void pickupItem(EffectGameObject* object) {
        if (s_simulating) return;
        GJBaseGameLayer::pickupItem(object);
    }

    void destroyObject(GameObject* object) {
        if (s_simulating) return;
        GJBaseGameLayer::destroyObject(object);
    }

    void toggleDualMode(GameObject* object, bool dual, PlayerObject* player, bool noEffects) {
        if (s_simulating) return;
        GJBaseGameLayer::toggleDualMode(object, dual, player, noEffects);
    }

    void teleportPlayer(TeleportPortalObject* object, PlayerObject* player) {
        // The copy stops at teleport portals
        if (isFake(player)) {
            player->m_isDead = true;
            return;
        }
        GJBaseGameLayer::teleportPlayer(object, player);
    }

    void playerWillSwitchMode(PlayerObject* player, GameObject* object) {
        if (s_simulating) return;
        GJBaseGameLayer::playerWillSwitchMode(player, object);
    }

    void updateDualGround(PlayerObject* player, int mode, bool instant, float duration) {
        if (s_simulating) return;
        GJBaseGameLayer::updateDualGround(player, mode, instant, duration);
    }

    void flipGravity(PlayerObject* player, bool flip, bool noEffects) {
        GJBaseGameLayer::flipGravity(player, flip, noEffects || isFake(player));
    }

    void toggleFlipped(bool flip, bool noEffects) {
        if (s_simulating) return;
        GJBaseGameLayer::toggleFlipped(flip, noEffects);
    }

    void reverseDirection(EffectGameObject* object) {
        if (s_simulating) return;
        GJBaseGameLayer::reverseDirection(object);
    }

    void rotateGameplay(RotateGameplayGameObject* object) {
        if (s_simulating) return;
        GJBaseGameLayer::rotateGameplay(object);
    }

    void gameEventTriggered(GJGameEvent event, int material, int playerID) {
        if (s_simulating) return;
        GJBaseGameLayer::gameEventTriggered(event, material, playerID);
    }

    void shakeCamera(float duration, float strength, float interval) {
        if (s_simulating) return;
        GJBaseGameLayer::shakeCamera(duration, strength, interval);
    }
};

class $modify(TrajectoryObject, EnhancedGameObject) {
    // Pads and orbs remember which player used them. The copy keeps its own list.
    void activatedByPlayer(PlayerObject* player) {
        if (isFake(player)) {
            s_fakeActivated.insert(this);
            return;
        }
        EnhancedGameObject::activatedByPlayer(player);
    }

    bool hasBeenActivatedByPlayer(PlayerObject* player) {
        if (isFake(player)) {
            auto pl = PlayLayer::get();
            return s_fakeActivated.contains(this) || (pl && EnhancedGameObject::hasBeenActivatedByPlayer(pl->m_player1));
        }
        return EnhancedGameObject::hasBeenActivatedByPlayer(player);
    }
};

class $modify(TrajectoryRing, RingObject) {
    void spawnCircle() {
        if (s_simulating) return;
        RingObject::spawnCircle();
    }
};

class $modify(TrajectoryPlayer, PlayerObject) {
    void spawnCircle() {
        if (s_simulating) return;
        PlayerObject::spawnCircle();
    }

    void spawnPortalCircle(ccColor3B color, float startRadius) {
        if (s_simulating) return;
        PlayerObject::spawnPortalCircle(color, startRadius);
    }

    void spawnScaleCircle() {
        if (s_simulating) return;
        PlayerObject::spawnScaleCircle();
    }

    void spawnDualCircle() {
        if (s_simulating) return;
        PlayerObject::spawnDualCircle();
    }

    void playBumpEffect(int objectType, GameObject* object) {
        if (s_simulating) return;
        PlayerObject::playBumpEffect(objectType, object);
    }

    void playSpiderDashEffect(CCPoint from, CCPoint to) {
        if (s_simulating) return;
        PlayerObject::playSpiderDashEffect(from, to);
    }
};
