#include "../Config.hpp"
#include "../Hacks.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>

using namespace geode::prelude;
using namespace grassy;

// Instant respawn and a custom respawn time. When you die, GD starts an action
// tagged 0x10 that waits (normally 1 second) and then respawns you through
// delayedResetLevel. That action is swapped for one with a different wait.
// The bot restarts attempts itself, so it's left alone.

namespace {
    constexpr int kRespawnActionTag = 0x10;

    // Seconds to wait before respawning, or -1 for GD's own wait
    float respawnDelay() {
        if (config::getBool("respawn.instant")) return 0.f;
        if (config::getBool("respawn.custom")) return static_cast<float>(config::getFloat("respawn.time"));
        return -1.f;
    }
}

namespace grassy::respawn {
    bool changed() {
        return respawnDelay() >= 0.f;
    }
}

class $modify(RespawnPlayLayer, PlayLayer) {
    void destroyPlayer(PlayerObject* player, GameObject* object) {
        bool wasDead = player && player->m_isDead;
        PlayLayer::destroyPlayer(player, object);
        // Only a death that just happened, GD restarts its wait for each one
        float delay = respawnDelay();
        if (delay < 0.f || wasDead || !player || !player->m_isDead || bot::isRunning()) return;
        auto action = getActionByTag(kRespawnActionTag);
        if (!action) return;
        stopAction(action);
        auto respawn = CCSequence::create(CCDelayTime::create(delay),
            CCCallFunc::create(this, callfunc_selector(PlayLayer::delayedResetLevel)), nullptr);
        respawn->setTag(kRespawnActionTag);
        runAction(respawn);
    }
};
