#include "../Config.hpp"
#include "../Hacks.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/CustomListView.hpp>
#include <Geode/modify/LevelBrowserLayer.hpp>

#include <algorithm>

using namespace geode::prelude;
using namespace grassy;

// See More Levels: the list of levels (search results, saved and created
// levels) is zoomed out, so more of them fit on the screen. GD builds the
// list bigger than normal, then it's shrunk to fit the normal frame.

namespace {
    // Set while GD builds a level list
    bool s_building = false;

    float zoom() {
        return std::clamp(static_cast<float>(config::getFloat("levels.zoom.value")), 0.3f, 1.f);
    }
}

class $modify(BrowserListView, CustomListView) {
    static CustomListView* create(CCArray* entries, TableViewCellDelegate* delegate, float height, float width, int page,
            BoomListType type, float y) {
        if (s_building) {
            height /= zoom();
            width /= zoom();
        }
        return CustomListView::create(entries, delegate, height, width, page, type, y);
    }
};

class $modify(BrowserLayer, LevelBrowserLayer) {
    void setupLevelBrowser(CCArray* items) {
        s_building = config::getBool("levels.zoom");
        float scale = zoom();
        LevelBrowserLayer::setupLevelBrowser(items);
        if (!s_building) return;
        s_building = false;
        if (!m_list || !m_list->m_listView) return;
        // Shrunk from the bottom left corner, where GD put it
        auto view = m_list->m_listView;
        view->setAnchorPoint({ 0.f, 0.f });
        view->setScale(scale);
    }
};
