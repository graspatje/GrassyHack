#include "Config.hpp"
#include "Hacks.hpp"
#include "Rulesets.hpp"
#include "macro/Player.hpp"

#include <Geode/Geode.hpp>
#include <Geode/ui/Notification.hpp>
#include <Geode/utils/file.hpp>
#include <Geode/utils/web.hpp>

#include <Windows.h>
#include <commdlg.h>

#include <imgui-cocos.hpp>
#include <imgui.h>
#include <imgui_internal.h>

#include <algorithm>
#include <cctype>
#include <cfloat>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <functional>
#include <string>
#include <unordered_map>

using namespace geode::prelude;
using namespace grassy;

// The menu: category windows in the style of Mega Hack, drawn with Dear ImGui
// over the game. Each hack is a row with a switch. Clicking the row turns it
// on or off, right-clicking it (or clicking its dots) opens its options and
// keybind. Keybinds work everywhere, menu open or not.

namespace {
    // Sizes in pixels at UI scale 1
    constexpr float kFontSize = 16.f;
    constexpr float kWindowWidth = 220.f;
    constexpr float kHeaderHeight = 30.f;
    constexpr float kRowHeight = 27.f;
    constexpr float kPadding = 11.f;
    constexpr float kWindowGap = 12.f;
    constexpr float kFadeSeconds = 0.12f;
    constexpr float kSwitchSeconds = 0.12f;

    ImVec4 const kWindowBg = { 0.075f, 0.08f, 0.095f, 0.97f };
    ImVec4 const kPopupBg = { 0.105f, 0.11f, 0.13f, 0.98f };
    ImVec4 const kText = { 0.93f, 0.94f, 0.96f, 1.f };
    ImVec4 const kTextDim = { 0.64f, 0.66f, 0.72f, 1.f };
    ImVec4 const kFrame = { 0.16f, 0.17f, 0.2f, 1.f };
    ImVec4 const kFrameHover = { 0.21f, 0.22f, 0.26f, 1.f };
    ImVec4 const kSwitchOff = { 0.22f, 0.23f, 0.27f, 1.f };
    ImVec4 const kWhite = { 1.f, 1.f, 1.f, 1.f };
    ImVec4 const kBlack = { 0.f, 0.f, 0.f, 1.f };

    bool s_open = false;
    // 0 closed, 1 open, in between while fading
    float s_fade = 0.f;
    float s_scale = 1.f;
    // The scale the style was last built for
    float s_styleScale = 0.f;
    // When the scale changes, windows move with it so they don't overlap
    float s_moveWindows = 1.f;
    // While the UI scale slider is dragged, so the menu doesn't resize under the mouse
    float s_pendingScale = 0.f;
    bool s_resetLayout = false;
    bool s_resetLayoutNextFrame = false;
    int s_windowIndex = 0;
    ImFont* s_font = nullptr;
    ImFont* s_boldFont = nullptr;
    char s_search[64] = "";
    // The keybind option waiting for a key press, empty when none
    std::string s_capturing;
    bool s_captureButtonDrawn = false;
    // How far each switch is between off (0) and on (1), for the animation
    std::unordered_map<ImGuiID, float> s_switches;
    bool s_keybindsOpen = false;
    bool s_chatOpen = false;
    // Puts the cursor in the chat's text box on the next frame
    bool s_focusChat = false;
    // Showing the key setup even though there's a key, to change it
    bool s_changingKey = false;
    char s_chatInput[1000] = "";
    char s_keyInput[200] = "";
    // What the chat looked like last frame, to scroll down when it changes
    int s_chatSeen = -1;
    bool s_chatSeenBusy = false;
    int s_chatScroll = 0;

    struct Bind {
        // The key is saved as "key." + this
        char const* option;
        char const* name;
        // Where it's listed in the Keybinds window
        char const* group;
        // The key turns a saved option on and off (the option is "option")
        bool toggles;
    };

    // Every keybind, in the order the Keybinds window lists them
    constexpr Bind kBinds[] = {
        { "menu", "Open / close the menu", "Menu", false },
        { "menu.rainbow", "Rainbow Accent", "Menu", true },
        { "menu.dim", "Dim Background", "Menu", true },
        { "menu.quick", "Quick Menus", "Menu", true },
        { "chat", "AI Chat: open / close", "Menu", false },
        { "speedhack", "Speedhack", "Global", true },
        { "safe-mode", "Safe Mode", "Global", true },
        { "fps.unlock", "FPS Bypass", "Global", true },
        { "tps.unlock", "TPS Bypass", "Global", true },
        { "vsync", "Vertical Sync", "Global", false },
        { "chests.fast", "Fast Chest Opening", "Global", true },
        { "levels.zoom", "See More Levels", "Global", true },
        { "bypass.practice-music", "Practice Music", "Bypass", true },
        { "bypass.main-levels", "Unlock Main Levels", "Bypass", true },
        { "bypass.unlock-all", "Unlock Everything", "Bypass", true },
        { "bypass.slider", "No Slider Limit", "Bypass", true },
        { "bypass.text-length", "No Text Length Limit", "Bypass", true },
        { "noclip", "Noclip", "Player", true },
        { "respawn.instant", "Instant Respawn", "Player", true },
        { "respawn.custom", "Respawn Time", "Player", true },
        { "jump-hack", "Jump Hack", "Player", true },
        { "autoclicker", "Auto Clicker", "Player", true },
        { "cbf", "Click Between Frames", "Player", false },
        { "click-between-steps", "Click Between Steps", "Player", true },
        { "click-on-steps", "Click On Steps", "Player", true },
        { "startpos", "StartPos Switcher", "Level", true },
        { "startpos.smart", "Smart StartPos", "Level", true },
        { "startpos.prev", "Previous start position", "Level", false },
        { "startpos.next", "Next start position", "Level", false },
        { "stepper", "Frame Stepper: freeze", "Level", false },
        { "stepper.step", "Frame Stepper: step forward", "Level", false },
        { "stepper.back", "Frame Stepper: step back", "Level", false },
        { "deaths", "Death Tracker", "Level", true },
        { "confirm-exit", "Confirm Exit", "Level", true },
        { "confirm-practice", "Confirm Practice", "Level", true },
        { "practice-complete", "0% Practice Complete", "Level", true },
        { "autokill", "Auto Kill", "Level", true },
        { "deafen", "Auto Deafen", "Level", true },
        { "jumpscare", "Jumpscare", "Level", true },
        { "instant-complete", "Instant Complete", "Level", true },
        { "force-platformer", "Force Platformer", "Level", true },
        { "music-sync", "Auto Music Sync", "Level", true },
        { "restart", "Restart from 0%", "Level", false },
        { "hitboxes", "Show Hitboxes", "Visual", true },
        { "hitboxes.death", "Hitboxes On Death", "Visual", true },
        { "hitboxes.trail", "Hitbox Trail", "Visual", true },
        { "trajectory", "Show Trajectory", "Visual", true },
        { "layout", "Show Layout", "Visual", true },
        { "show-triggers", "Show Triggers", "Visual", true },
        { "bot", "Auto Bot: start / stop", "Bot", false },
        { "macro.record", "Macro: record", "Bot", false },
        { "macro.play", "Macro: play", "Bot", false },
        { "cheat-indicator", "Cheat Indicator", "Labels", true },
        { "labels.custom", "Custom Text", "Labels", true },
        { "labels.fps", "FPS", "Labels", true },
        { "labels.cps", "CPS", "Labels", true },
        { "labels.frame", "Frame", "Labels", true },
        { "labels.clock", "Clock", "Labels", true },
        { "labels.session", "Session Time", "Labels", true },
        { "labels.attempts", "Attempts", "Labels", true },
        { "labels.percent", "Percentage", "Labels", true },
        { "labels.noclip-accuracy", "Noclip Accuracy", "Labels", true },
        { "labels.noclip-deaths", "Noclip Deaths", "Labels", true },
        { "startpos.hide-ui", "Hide StartPos UI", "Labels", true },
        { "cosmetic.hide-player", "Hide Player", "Cosmetic", true },
        { "cosmetic.icon-randomizer", "Icon Randomizer", "Cosmetic", true },
        { "cosmetic.icon-on-top", "Player Icon On Top", "Cosmetic", true },
        { "cosmetic.p1-on-top", "Player 1 On Top", "Cosmetic", true },
        { "cosmetic.p2-on-top", "Player 2 On Top", "Cosmetic", true },
        { "cosmetic.no-trail", "No Trail", "Cosmetic", true },
        { "cosmetic.trail-always", "Trail Always On", "Cosmetic", true },
        { "cosmetic.no-wave-trail", "No Wave Trail", "Cosmetic", true },
        { "cosmetic.no-trail-behind-wave", "No Trail Behind Wave", "Cosmetic", true },
        { "cosmetic.no-wave-pulse", "No Wave Pulse", "Cosmetic", true },
        { "cosmetic.wave-pulse-size", "Wave Pulse Size", "Cosmetic", true },
        { "cosmetic.no-death-effect", "No Death Effect", "Cosmetic", true },
        { "cosmetic.no-respawn-flash", "No Respawn Flash", "Cosmetic", true },
        { "cosmetic.no-ghost-trail", "No Ghost Trail", "Cosmetic", true },
        { "cosmetic.no-dash-fire", "No Dash Fire", "Cosmetic", true },
        { "cosmetic.no-robot-fire", "No Robot Fire", "Cosmetic", true },
        { "cosmetic.no-swing-fire", "No Swing Fire", "Cosmetic", true },
        { "cosmetic.no-spider-dash", "No Spider Dash", "Cosmetic", true },
        { "cosmetic.no-orb-ring", "No Orb Ring", "Cosmetic", true },
        { "cosmetic.no-particles", "No Particles", "Cosmetic", true },
        { "cosmetic.no-glow", "No Glow", "Cosmetic", true },
        { "cosmetic.no-pulse", "No Pulse", "Cosmetic", true },
        { "cosmetic.no-shaders", "No Shaders", "Cosmetic", true },
        { "cosmetic.no-shake", "No Shake", "Cosmetic", true },
        { "cosmetic.no-end-shake", "No End Shake", "Cosmetic", true },
        { "cosmetic.no-zoom", "No Camera Zoom", "Cosmetic", true },
        { "cosmetic.no-mirror", "No Mirror", "Cosmetic", true },
        { "cosmetic.startpos-camera", "StartPos Reset Camera", "Cosmetic", true },
        { "cosmetic.accurate-percent", "Accurate Percentage", "Cosmetic", true },
        { "cosmetic.total-attempts", "Show Total Attempts", "Cosmetic", true },
        { "cosmetic.no-new-best", "No New Best Popup", "Cosmetic", true },
        { "cosmetic.no-do-not", "No \"Do Not\" Flip", "Cosmetic", true },
        { "font", "Custom Font", "Cosmetic", true },
        { "cosmetic.stop-triggers", "Stop Triggers On Death", "Cosmetic", true },
        { "cosmetic.pitch", "Pitch Shifter", "Cosmetic", true },
    };

    float px(float value) {
        return value * s_scale;
    }

    // The window's width, less its scrollbar when it has one
    float innerWidth() {
        auto window = ImGui::GetCurrentWindow();
        return window->Size.x - (window->ScrollbarY ? ImGui::GetStyle().ScrollbarSize : 0.f);
    }

    ImVec4 mix(ImVec4 a, ImVec4 b, float t) {
        return { a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t, a.w + (b.w - a.w) * t };
    }

    ImVec4 withAlpha(ImVec4 color, float alpha) {
        color.w *= alpha;
        return color;
    }

    // Colors drawn by hand go through this, so they fade with the menu
    ImU32 color(ImVec4 value) {
        return ImGui::GetColorU32(value);
    }

    ImVec4 accent() {
        if (config::getBool("menu.rainbow")) {
            float hue = std::fmod(static_cast<float>(ImGui::GetTime()) * 0.08f, 1.f);
            ImVec4 out = kWhite;
            ImGui::ColorConvertHSVtoRGB(hue, 0.6f, 0.85f, out.x, out.y, out.z);
            return out;
        }
        auto rgb = config::getInt("menu.accent");
        return { ((rgb >> 16) & 0xFF) / 255.f, ((rgb >> 8) & 0xFF) / 255.f, (rgb & 0xFF) / 255.f, 1.f };
    }

    std::string keyName(enumKeyCodes key) {
        if (key == KEY_None) return "None";
        return Keybind(key, KeyboardModifier::None).toString();
    }

    bool matchesSearch(char const* label) {
        if (!s_search[0]) return true;
        std::string_view text(label), needle(s_search);
        auto found = std::search(text.begin(), text.end(), needle.begin(), needle.end(), [](char a, char b) {
            return std::tolower(static_cast<unsigned char>(a)) == std::tolower(static_cast<unsigned char>(b));
        });
        return found != text.end();
    }

    void loadFonts() {
        auto& io = ImGui::GetIO();
        char const* windows = std::getenv("WINDIR");
        auto fonts = std::filesystem::path(windows ? windows : "C:\\Windows") / "Fonts";
        auto load = [&](char const* file) -> ImFont* {
            std::error_code error;
            auto path = fonts / file;
            if (!std::filesystem::exists(path, error)) return nullptr;
            return io.Fonts->AddFontFromFileTTF(path.string().c_str(), kFontSize);
        };
        s_font = load("segoeui.ttf");
        if (!s_font) s_font = io.Fonts->AddFontDefault();
        s_boldFont = load("seguisb.ttf");
        if (!s_boldFont) s_boldFont = s_font;
        io.FontDefault = s_font;
    }

    void applyStyle() {
        ImGuiStyle style;
        style.WindowRounding = 8.f;
        style.ChildRounding = 6.f;
        style.PopupRounding = 8.f;
        style.FrameRounding = 5.f;
        style.GrabRounding = 4.f;
        style.ScrollbarRounding = 6.f;
        style.WindowBorderSize = 0.f;
        style.PopupBorderSize = 1.f;
        style.FrameBorderSize = 0.f;
        style.WindowPadding = { 12.f, 10.f };
        style.FramePadding = { 8.f, 4.f };
        style.ItemSpacing = { 8.f, 7.f };
        style.ItemInnerSpacing = { 6.f, 4.f };
        style.GrabMinSize = 12.f;
        style.ScrollbarSize = 7.f;
        style.WindowMinSize = { 10.f, 10.f };
        style.HoverDelayNormal = 0.45f;
        style.ScaleAllSizes(s_scale);
        style.FontSizeBase = kFontSize;
        style.FontScaleMain = s_scale;

        auto& colors = style.Colors;
        colors[ImGuiCol_Text] = kText;
        colors[ImGuiCol_TextDisabled] = kTextDim;
        colors[ImGuiCol_WindowBg] = kWindowBg;
        colors[ImGuiCol_PopupBg] = kPopupBg;
        colors[ImGuiCol_Border] = { 1.f, 1.f, 1.f, 0.07f };
        colors[ImGuiCol_FrameBg] = kFrame;
        colors[ImGuiCol_FrameBgHovered] = kFrameHover;
        colors[ImGuiCol_FrameBgActive] = kFrameHover;
        colors[ImGuiCol_Button] = kFrame;
        colors[ImGuiCol_ButtonHovered] = kFrameHover;
        colors[ImGuiCol_Separator] = { 1.f, 1.f, 1.f, 0.08f };
        colors[ImGuiCol_ScrollbarBg] = { 0.f, 0.f, 0.f, 0.f };
        colors[ImGuiCol_ScrollbarGrab] = kFrameHover;
        colors[ImGuiCol_ScrollbarGrabHovered] = kSwitchOff;
        colors[ImGuiCol_ScrollbarGrabActive] = kTextDim;
        ImGui::GetStyle() = style;
        s_styleScale = s_scale;
    }

    // Set every frame, since the rainbow accent changes all the time
    void applyAccent(ImVec4 value) {
        auto& colors = ImGui::GetStyle().Colors;
        colors[ImGuiCol_CheckMark] = value;
        colors[ImGuiCol_SliderGrab] = value;
        colors[ImGuiCol_SliderGrabActive] = mix(value, kWhite, 0.25f);
        colors[ImGuiCol_ButtonActive] = withAlpha(value, 0.7f);
        colors[ImGuiCol_Header] = withAlpha(value, 0.35f);
        colors[ImGuiCol_HeaderHovered] = withAlpha(value, 0.5f);
        colors[ImGuiCol_HeaderActive] = withAlpha(value, 0.65f);
        colors[ImGuiCol_TextSelectedBg] = withAlpha(value, 0.4f);
        colors[ImGuiCol_NavCursor] = value;
        colors[ImGuiCol_PlotHistogram] = value;
        colors[ImGuiCol_Tab] = kFrame;
        colors[ImGuiCol_TabHovered] = withAlpha(value, 0.6f);
        colors[ImGuiCol_TabSelected] = withAlpha(value, 0.85f);
        colors[ImGuiCol_TabSelectedOverline] = value;
        colors[ImGuiCol_PlotHistogramHovered] = mix(value, kWhite, 0.3f);
    }

    void tooltip(char const* text) {
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, { px(10.f), px(8.f) });
        if (ImGui::BeginTooltip()) {
            ImGui::PushTextWrapPos(px(280.f));
            ImGui::TextUnformatted(text);
            ImGui::PopTextWrapPos();
            ImGui::EndTooltip();
        }
        ImGui::PopStyleVar();
    }

    void tooltipForItem(char const* text) {
        if (text && ImGui::IsItemHovered(ImGuiHoveredFlags_DelayNormal)) tooltip(text);
    }

    // Where the bottom of each column of windows drawn so far this frame is
    std::vector<float> s_columnBottoms;

    int columnCount() {
        float width = px(kWindowWidth);
        float gap = px(kWindowGap);
        return std::max(1, static_cast<int>((ImGui::GetIO().DisplaySize.x - gap) / (width + gap)));
    }

    // Windows start in a row along the top. Once the row is full, the next
    // one goes under the column with the most room left.
    ImVec2 defaultPosition(int index) {
        float width = px(kWindowWidth);
        float gap = px(kWindowGap);
        int columns = columnCount();
        if (index < columns || s_columnBottoms.empty()) return { gap + (index % columns) * (width + gap), gap };
        int best = 0;
        for (int column = 1; column < static_cast<int>(s_columnBottoms.size()); column++) {
            if (s_columnBottoms[column] < s_columnBottoms[best]) best = column;
        }
        return { gap + best * (width + gap), s_columnBottoms[best] + gap };
    }

    void noteColumnBottom() {
        float width = px(kWindowWidth);
        float gap = px(kWindowGap);
        auto pos = ImGui::GetWindowPos();
        auto size = ImGui::GetWindowSize();
        int columns = columnCount();
        if (static_cast<int>(s_columnBottoms.size()) != columns) s_columnBottoms.assign(columns, 0.f);
        int column = std::clamp(static_cast<int>(std::lround((pos.x - gap) / (width + gap))), 0, columns - 1);
        s_columnBottoms[column] = std::max(s_columnBottoms[column], pos.y + size.y);
    }

    // A window's header, also what you drag the window by
    void drawHeader(char const* title, float width) {
        auto draw = ImGui::GetWindowDrawList();
        ImVec2 pos = ImGui::GetWindowPos();
        float height = px(kHeaderHeight);
        auto tint = accent();
        draw->AddRectFilled(pos, { pos.x + width, pos.y + height }, color(tint), ImGui::GetStyle().WindowRounding,
            ImDrawFlags_RoundCornersTop);
        draw->AddRectFilled({ pos.x, pos.y + height - px(2.f) }, { pos.x + width, pos.y + height }, color(mix(tint, kBlack, 0.3f)));
        ImGui::PushFont(s_boldFont, kFontSize + 1.f);
        auto size = ImGui::CalcTextSize(title);
        ImVec2 textPos = { pos.x + (width - size.x) / 2.f, pos.y + (height - size.y) / 2.f - px(1.f) };
        draw->AddText({ textPos.x + px(1.f), textPos.y + px(1.f) }, color({ 0.f, 0.f, 0.f, 0.3f }), title);
        draw->AddText(textPos, color(kWhite), title);
        ImGui::PopFont();
        ImGui::Dummy({ width, height + px(4.f) });
    }

    // A small button with an x drawn on it
    bool crossButton(char const* id, float size, char const* description) {
        ImVec2 pos = ImGui::GetCursorScreenPos();
        bool pressed = ImGui::InvisibleButton(id, { size, size });
        bool hovered = ImGui::IsItemHovered();
        bool disabled = ImGui::GetItemFlags() & ImGuiItemFlags_Disabled;
        auto draw = ImGui::GetWindowDrawList();
        if (hovered && !disabled) {
            draw->AddRectFilled(pos, { pos.x + size, pos.y + size }, color(kFrameHover), ImGui::GetStyle().FrameRounding);
        }
        float inset = size * 0.32f;
        auto lineColor = color(disabled ? withAlpha(kTextDim, 0.35f) : hovered ? kText : kTextDim);
        draw->AddLine({ pos.x + inset, pos.y + inset }, { pos.x + size - inset, pos.y + size - inset }, lineColor, px(1.6f));
        draw->AddLine({ pos.x + size - inset, pos.y + inset }, { pos.x + inset, pos.y + size - inset }, lineColor, px(1.6f));
        if (!disabled) tooltipForItem(description);
        return pressed && !disabled;
    }

    // Windows being placed, and for how many more frames. Window heights are
    // only right after a frame or two, so a window going under another one is
    // placed again until they are.
    std::unordered_map<std::string, int> s_placing;

    void beginCategory(char const* title) {
        float width = px(kWindowWidth);
        int index = s_windowIndex++;
        auto window = ImGui::FindWindowByName(title);
        // A window that was never shown before (the ini file has its spot otherwise)
        bool isNew = !window && !ImGui::FindWindowSettingsByID(ImHashStr(title));
        if (isNew || s_resetLayout) s_placing[title] = 4;
        auto placing = s_placing.find(title);
        if (placing != s_placing.end() && placing->second > 0) {
            placing->second--;
            ImGui::SetNextWindowPos(defaultPosition(index), ImGuiCond_Always);
        }
        else if (window && s_moveWindows != 1.f) {
            ImGui::SetNextWindowPos({ window->Pos.x * s_moveWindows, window->Pos.y * s_moveWindows });
        }
        // Height 0 fits the window to its rows
        ImGui::SetNextWindowSize({ width, 0.f });
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, { 0.f, 0.f });
        ImGui::Begin(title, nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
            ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoCollapse);
        ImGui::PopStyleVar();
        // Rows sit right against each other, endCategory pops this
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, { 0.f, 0.f });

        drawHeader(title, width);
        // The rows scroll when the window would go off the bottom of the screen
        float top = ImGui::GetCursorScreenPos().y;
        float maxHeight = std::max(px(160.f), ImGui::GetIO().DisplaySize.y - top - px(kWindowGap));
        ImGui::SetNextWindowSizeConstraints({ 0.f, 0.f }, { FLT_MAX, maxHeight });
        ImGui::BeginChild("##rows", { width, 0.f }, ImGuiChildFlags_AutoResizeY, ImGuiWindowFlags_NoBackground);
    }

    void endCategory() {
        ImGui::Dummy({ 0.f, px(5.f) });
        ImGui::EndChild();
        ImGui::PopStyleVar();
        noteColumnBottom();
        ImGui::End();
    }

    // A small heading between groups of rows, hidden while searching
    void section(char const* title) {
        if (s_search[0]) return;
        ImGui::Dummy({ 0.f, px(4.f) });
        ImGui::SetCursorPosX(px(kPadding));
        ImGui::PushFont(s_boldFont, kFontSize - 3.f);
        ImGui::PushStyleColor(ImGuiCol_Text, withAlpha(accent(), 0.85f));
        ImGui::TextUnformatted(title);
        ImGui::PopStyleColor();
        ImGui::PopFont();
        ImGui::Dummy({ 0.f, px(2.f) });
    }

    void space(float height) {
        ImGui::Dummy({ 0.f, px(height) });
    }

    struct RowClick {
        bool toggle = false;
        bool options = false;
    };

    // A row with a name and a switch, the building block of the menu
    RowClick row(char const* label, char const* description, bool on) {
        RowClick click;
        auto& io = ImGui::GetIO();
        float width = innerWidth();
        float height = px(kRowHeight);
        ImVec2 pos = ImGui::GetCursorScreenPos();

        ImGui::PushID(label);
        bool pressed = ImGui::InvisibleButton("##row", { width, height });
        ImGui::PopID();
        ImGuiID id = ImGui::GetItemID();
        bool hovered = ImGui::IsItemHovered();

        float pad = px(kPadding);
        float switchWidth = px(28.f);
        float switchHeight = px(15.f);
        float switchX = pos.x + width - pad - switchWidth;
        float dotsWidth = px(18.f);
        float dotsX = switchX - px(6.f) - dotsWidth;
        bool overDots = hovered && io.MousePos.x >= dotsX - px(3.f) && io.MousePos.x < switchX - px(2.f);

        if (pressed) {
            if (overDots) click.options = true;
            else click.toggle = true;
        }
        if (ImGui::IsItemClicked(ImGuiMouseButton_Right)) click.options = true;
        if (description && !overDots) tooltipForItem(description);

        auto [it, added] = s_switches.try_emplace(id, on ? 1.f : 0.f);
        float& t = it->second;
        float step = config::getBool("menu.quick") ? 1.f : io.DeltaTime / kSwitchSeconds;
        t = on ? std::min(1.f, t + step) : std::max(0.f, t - step);
        float eased = t * t * (3.f - 2.f * t);

        auto draw = ImGui::GetWindowDrawList();
        if (hovered) {
            draw->AddRectFilled(pos, { pos.x + width, pos.y + height }, color({ 1.f, 1.f, 1.f, 0.045f }));
        }
        auto textSize = ImGui::CalcTextSize(label);
        float brightness = std::max(eased, hovered ? 0.6f : 0.f);
        draw->AddText({ pos.x + pad, pos.y + (height - textSize.y) / 2.f }, color(mix(kTextDim, kText, brightness)), label);

        float middle = pos.y + height / 2.f;
        auto dots = overDots ? kText : withAlpha(kTextDim, hovered ? 0.9f : 0.45f);
        for (int i = -1; i <= 1; i++) {
            draw->AddCircleFilled({ dotsX + dotsWidth / 2.f + i * px(4.5f), middle }, px(1.6f), color(dots));
        }

        ImVec2 trackMin = { switchX, middle - switchHeight / 2.f };
        ImVec2 trackMax = { switchX + switchWidth, middle + switchHeight / 2.f };
        draw->AddRectFilled(trackMin, trackMax, color(mix(kSwitchOff, accent(), eased)), switchHeight / 2.f);
        float knobX = trackMin.x + switchHeight / 2.f + (switchWidth - switchHeight) * eased;
        draw->AddCircleFilled({ knobX, middle }, switchHeight / 2.f - px(2.5f), color(kWhite));
        return click;
    }

    bool beginOptions(char const* label) {
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, { px(12.f), px(10.f) });
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, { px(8.f), px(7.f) });
        ImGui::SetNextWindowSizeConstraints({ px(300.f), 0.f }, { FLT_MAX, FLT_MAX });
        // Sizes in fractions of a pixel would otherwise give it a needless scrollbar
        if (!ImGui::BeginPopup(label, ImGuiWindowFlags_NoScrollbar)) {
            ImGui::PopStyleVar(2);
            return false;
        }
        ImGui::PushFont(s_boldFont, 0.f);
        ImGui::TextColored(accent(), "%s", label);
        ImGui::PopFont();
        ImGui::Separator();
        return true;
    }

    void endOptions() {
        ImGui::EndPopup();
        ImGui::PopStyleVar(2);
    }

    // Lines in an options popup: a label, then the control in a column
    void optionLabel(char const* label) {
        ImGui::AlignTextToFramePadding();
        ImGui::TextUnformatted(label);
        ImGui::SameLine(px(140.f));
        ImGui::SetNextItemWidth(px(150.f));
    }

    // A note in an options popup, wrapped to the popup's width
    void optionText(char const* text) {
        ImGui::PushTextWrapPos(ImGui::GetCursorPosX() + px(276.f));
        ImGui::PushStyleColor(ImGuiCol_Text, kTextDim);
        ImGui::TextUnformatted(text);
        ImGui::PopStyleColor();
        ImGui::PopTextWrapPos();
    }

    void optionCheckbox(char const* label, char const* key, char const* description) {
        bool value = config::getBool(key);
        if (ImGui::Checkbox(label, &value)) config::setBool(key, value);
        tooltipForItem(description);
    }

    void optionInt(char const* label, char const* key, int min, int max, char const* description,
            ImGuiSliderFlags flags = ImGuiSliderFlags_None) {
        optionLabel(label);
        int value = static_cast<int>(config::getInt(key));
        auto id = fmt::format("##{}", key);
        if (ImGui::SliderInt(id.c_str(), &value, min, max, "%d", flags | ImGuiSliderFlags_AlwaysClamp)) {
            config::setInt(key, value);
        }
        tooltipForItem(description);
    }

    void optionFloat(char const* label, char const* key, float min, float max, char const* format, char const* description,
            ImGuiSliderFlags flags = ImGuiSliderFlags_None) {
        optionLabel(label);
        float value = static_cast<float>(config::getFloat(key));
        auto id = fmt::format("##{}", key);
        if (ImGui::SliderFloat(id.c_str(), &value, min, max, format, flags | ImGuiSliderFlags_AlwaysClamp)) {
            config::setFloat(key, value);
        }
        tooltipForItem(description);
    }

    // A button that shows a key, and waits for a new one when clicked
    void keyButton(char const* key, float width) {
        bool capturing = s_capturing == key;
        if (capturing) s_captureButtonDrawn = true;
        auto text = fmt::format("{}##{}", capturing ? "Press a key..." : keyName(config::getKey(key)), key);
        if (capturing) ImGui::PushStyleColor(ImGuiCol_Button, withAlpha(accent(), 0.45f));
        if (ImGui::Button(text.c_str(), { width, 0.f })) {
            if (capturing) {
                s_capturing.clear();
            }
            else {
                s_capturing = key;
                s_captureButtonDrawn = true;
            }
        }
        if (capturing) ImGui::PopStyleColor();
        tooltipForItem("Click, then press a key. Backspace or Delete removes the key, Escape cancels.");
    }

    void optionKey(char const* label, char const* key) {
        optionLabel(label);
        keyButton(key, px(150.f));
    }

    void pickFile(std::wstring title, std::wstring kind, std::wstring patterns, std::filesystem::path folder,
        std::function<void(std::filesystem::path const&)> picked);

    void notify(std::string const& text);

    // A button that only does its thing when clicked a second time within 3 seconds
    bool confirmButton(char const* label, char const* again, ImVec2 size = { 0.f, 0.f }) {
        static std::string s_asking;
        static double s_askedAt = -10.0;
        bool asking = s_asking == label && ImGui::GetTime() - s_askedAt < 3.0;
        auto text = fmt::format("{}##{}", asking ? again : label, label);
        if (!ImGui::Button(text.c_str(), size)) return false;
        if (asking) {
            s_asking.clear();
            return true;
        }
        s_asking = label;
        s_askedAt = ImGui::GetTime();
        return false;
    }

    // A hack that's a saved on/off option. Its options popup always ends with
    // a key to toggle it.
    void hackRow(char const* label, char const* key, char const* description, std::function<void()> const& options = {}) {
        if (!matchesSearch(label)) return;
        bool on = config::getBool(key);
        auto click = row(label, description, on);
        if (click.toggle) config::setBool(key, !on);
        if (click.options) ImGui::OpenPopup(label);
        if (beginOptions(label)) {
            if (options) options();
            optionKey("Toggle key", fmt::format("key.{}", key).c_str());
            endOptions();
        }
    }

    // A row whose switch shows something going on (the bot running, the
    // level frozen) instead of a saved option
    void stateRow(char const* label, bool on, char const* description, std::function<void()> const& toggle,
            std::function<void()> const& options) {
        if (!matchesSearch(label)) return;
        auto click = row(label, description, on);
        if (click.toggle) toggle();
        if (click.options) ImGui::OpenPopup(label);
        if (beginOptions(label)) {
            options();
            endOptions();
        }
    }

    // A line of normal controls inside a category window: a label, then the control
    void lineLabel(char const* label, float column = 92.f) {
        ImGui::SetCursorPosX(px(kPadding));
        ImGui::AlignTextToFramePadding();
        ImGui::TextUnformatted(label);
        ImGui::SameLine(px(column));
        ImGui::SetNextItemWidth(innerWidth() - px(column) - px(kPadding));
    }

    void dimText(std::string const& text) {
        ImGui::SetCursorPosX(px(kPadding));
        ImGui::PushTextWrapPos(innerWidth() - px(kPadding));
        ImGui::PushFont(nullptr, kFontSize - 1.5f);
        ImGui::PushStyleColor(ImGuiCol_Text, kTextDim);
        ImGui::TextUnformatted(text.c_str());
        ImGui::PopStyleColor();
        ImGui::PopFont();
        ImGui::PopTextWrapPos();
    }

    void menuWindow() {
        beginCategory("GrassyHack");
        space(2.f);
        ImGui::SetCursorPosX(px(kPadding));
        ImGui::SetNextItemWidth(innerWidth() - 2.f * px(kPadding));
        ImGui::InputTextWithHint("##search", "Search hacks...", s_search, sizeof(s_search));
        space(7.f);

        lineLabel("Menu key");
        keyButton("key.menu", innerWidth() - px(92.f) - px(kPadding));
        space(5.f);

        lineLabel("UI scale");
        float scale = s_pendingScale > 0.f ? s_pendingScale : static_cast<float>(config::getFloat("menu.scale"));
        ImGui::SliderFloat("##scale", &scale, 0.6f, 2.f, "%.2fx", ImGuiSliderFlags_AlwaysClamp);
        if (ImGui::IsItemDeactivatedAfterEdit()) {
            config::setFloat("menu.scale", scale);
            s_pendingScale = 0.f;
        }
        else if (ImGui::IsItemActive()) {
            s_pendingScale = scale;
        }
        else {
            s_pendingScale = 0.f;
        }
        tooltipForItem("Size of the menu. It changes when you let go of the slider.");
        space(5.f);

        lineLabel("Accent");
        bool rainbow = config::getBool("menu.rainbow");
        ImGui::BeginDisabled(rainbow);
        auto rgb = config::getInt("menu.accent");
        float picked[3] = { ((rgb >> 16) & 0xFF) / 255.f, ((rgb >> 8) & 0xFF) / 255.f, (rgb & 0xFF) / 255.f };
        if (ImGui::ColorEdit3("##accent", picked, ImGuiColorEditFlags_NoInputs)) {
            auto channel = [](float value) { return static_cast<int64_t>(std::lround(std::clamp(value, 0.f, 1.f) * 255.f)); };
            config::setInt("menu.accent", (channel(picked[0]) << 16) | (channel(picked[1]) << 8) | channel(picked[2]));
        }
        ImGui::EndDisabled();
        tooltipForItem("The menu's color. Click to pick one.");
        space(4.f);

        hackRow("Rainbow Accent", "menu.rainbow", "Slowly cycles the menu's color through the rainbow.");
        hackRow("Dim Background", "menu.dim", "Darkens the game behind the menu while it's open.");
        hackRow("Quick Menus", "menu.quick", "Turns off animations in menus: GrassyHack's menu, GD's screen changes, popups and "
            "drop-down menus all show up instantly. Levels themselves aren't changed.");

        space(4.f);
        ImGui::SetCursorPosX(px(kPadding));
        if (ImGui::Button("Keybinds", { innerWidth() - 2.f * px(kPadding), 0.f })) {
            s_keybindsOpen = !s_keybindsOpen;
        }
        tooltipForItem("Every hack's key in one list, to change or remove them.");
        space(4.f);
        ImGui::SetCursorPosX(px(kPadding));
        if (ImGui::Button("AI Chat", { innerWidth() - 2.f * px(kPadding), 0.f })) {
            s_chatOpen = !s_chatOpen;
            s_focusChat = s_chatOpen;
        }
        tooltipForItem("Talk to an AI that knows GrassyHack and can turn hacks on and off for you. It's free, with "
            "your own key from Groq.");
        space(4.f);
        ImGui::SetCursorPosX(px(kPadding));
        if (ImGui::Button("Bugs & Suggestions", { innerWidth() - 2.f * px(kPadding), 0.f })) {
            utils::web::openLinkInBrowser("https://discord.gg/GpSQcTrKAs");
        }
        tooltipForItem("Opens GrassyHack's Discord server in your browser, to report a bug or suggest something.");
        space(4.f);
        ImGui::SetCursorPosX(px(kPadding));
        if (ImGui::Button("Reset window positions", { innerWidth() - 2.f * px(kPadding), 0.f })) {
            s_resetLayoutNextFrame = true;
        }
        endCategory();
    }

    void globalWindow() {
        beginCategory("Global");
        hackRow("Speedhack", "speedhack", "Makes the whole game run faster or slower. Set the speed with the slider below.", [] {
            optionCheckbox("Change the music's speed too", "speedhack.audio",
                "Speeds the music and sounds up or slows them down with the game.");
        });
        if (matchesSearch("Speedhack")) {
            space(2.f);
            ImGui::SetCursorPosX(px(kPadding));
            ImGui::SetNextItemWidth(innerWidth() - 2.f * px(kPadding));
            float speed = static_cast<float>(config::getFloat("speedhack.value"));
            if (ImGui::SliderFloat("##speed", &speed, 0.1f, 10.f, "%.2fx",
                    ImGuiSliderFlags_Logarithmic | ImGuiSliderFlags_AlwaysClamp | ImGuiSliderFlags_NoRoundToFormat)) {
                config::setFloat("speedhack.value", speed);
            }
            if (ImGui::IsItemClicked(ImGuiMouseButton_Right)) config::setFloat("speedhack.value", 1.0);
            tooltipForItem("Drag to change the speed (0.1x to 10x). Ctrl+click to type one, right-click to go back to 1x.");
            space(6.f);
        }
        hackRow("Safe Mode", "safe-mode",
            "When a cheat was on during an attempt, dying or beating the level doesn't save your progress or send your "
            "score. Keeps cheated runs off your stats and the leaderboards. Turn it off to let cheated runs save.", [] {
            optionText("Counts as a cheat: noclip, the speedhack at any speed but 1x, the frame stepper, the auto bot, "
                "playing a macro, the auto clicker, the jump hack, instant complete, force platformer and a TPS other than 240.");
            optionCheckbox("Always on, even without cheats", "safe-mode.always",
                "Nothing saves at all, cheats or not. Handy for messing around without touching your stats.");
        });
        hackRow("FPS Bypass", "fps.unlock", "Lets the game run at more frames per second than GD's own setting allows. Pick "
            "the FPS in the options. Vertical Sync caps it at your screen's refresh rate, so turn that off for more.", [] {
            optionFloat("FPS", "fps.value", 30.f, 1000.f, "%.0f", "Frames per second. Ctrl+click to type one.");
        });
        hackRow("TPS Bypass", "tps.unlock", "Changes how many physics steps (ticks) GD does per second, normally 240. More is "
            "smoother but changes how levels play, so it counts as a cheat. Macros and the bot need 240.", [] {
            optionFloat("Ticks per second", "tps.value", 60.f, 1000.f, "%.0f", "Ticks per second. Ctrl+click to type one.");
        });
        stateRow("Vertical Sync", menus::vsyncOn(), "GD's own vertical sync setting: frames wait for your screen, which stops "
            "tearing but caps the FPS at the screen's refresh rate.", [] { menus::setVsync(!menus::vsyncOn()); }, [] {
            optionKey("Toggle key", "key.vsync");
        });
        hackRow("Fast Chest Opening", "chests.fast", "Chests open five times faster.");
        hackRow("See More Levels", "levels.zoom", "Zooms out the list of levels when you search, and in your saved and "
            "created levels, so more of them fit on the screen. Set how far in the options.", [] {
            optionFloat("Size", "levels.zoom.value", 0.3f, 1.f, "%.2fx", "How big the list is drawn. 1 is GD's own size, "
                "smaller fits more levels. Takes effect when the list loads again.");
        });
        if (matchesSearch("Crash the game")) {
            space(5.f);
            ImGui::SetCursorPosX(px(kPadding));
            if (confirmButton("Crash the game", "Click again to crash", { innerWidth() - 2.f * px(kPadding), 0.f })) level::crash();
            tooltipForItem("Closes GD on the spot, like a crash (Geode saves a crash report). Click twice.");
            space(2.f);
        }
        endCategory();
    }

    void bypassWindow() {
        beginCategory("Bypass");
        hackRow("Practice Music", "bypass.practice-music", "Practice mode plays the level's own song instead of the practice "
            "song, from where you respawn. That's GD's \"practice music sync\", normally bought in the shop.");
        hackRow("Unlock Main Levels", "bypass.main-levels", "Opens main levels that need secret coins (Clubstep, Theory of "
            "Everything 2, Deadlocked) and every door in the Tower.");
        hackRow("Unlock Everything", "bypass.unlock-all", "Every icon, color, shop item and vault is unlocked while this is on: "
            "the Vault, the Vault of Secrets, the Treasure Room and its shops. Nothing is unlocked in your save, so it's all "
            "back to normal when you turn it off.");
        hackRow("No Slider Limit", "bypass.slider", "Sliders (like the ones in the editor's triggers) can be dragged past "
            "their ends.");
        hackRow("No Text Length Limit", "bypass.text-length", "Text boxes take as many characters as you type, instead of "
            "stopping at GD's limit.");
        endCategory();
    }

    void playerWindow() {
        beginCategory("Player");
        hackRow("Noclip", "noclip", "Nothing kills you: spikes, saws and walls go right through you. Off while the bot runs.", [] {
            optionCheckbox("Flash red when hit", "noclip.flash", "Flashes the screen red whenever you would have died.");
        });
        hackRow("Instant Respawn", "respawn.instant", "Respawns you the moment you die, instead of after GD's usual wait.");
        hackRow("Respawn Time", "respawn.custom", "Respawns you after the time set with the slider below instead of "
            "GD's usual wait (1 second, or half a second with some GD settings). Instant Respawn wins when both are on.");
        if (matchesSearch("Respawn Time")) {
            space(2.f);
            ImGui::SetCursorPosX(px(kPadding));
            ImGui::SetNextItemWidth(innerWidth() - 2.f * px(kPadding));
            float time = static_cast<float>(config::getFloat("respawn.time"));
            if (ImGui::SliderFloat("##respawn", &time, 0.f, 3.f, "%.2f s", ImGuiSliderFlags_AlwaysClamp)) {
                config::setFloat("respawn.time", time);
            }
            if (ImGui::IsItemClicked(ImGuiMouseButton_Right)) config::setFloat("respawn.time", 1.0);
            tooltipForItem("Seconds from dying to respawning. Ctrl+click to type one, right-click to go back to 1 second.");
            space(6.f);
        }
        hackRow("Jump Hack", "jump-hack", "Every click jumps, even in the air (cube, ball, robot, spider). Counts as a cheat.");
        hackRow("Auto Clicker", "autoclicker", "Clicks for you over and over while you play. Counts as a cheat.", [] {
            optionInt("Click every", "autoclicker.interval", 2, 240, "Ticks from one click to the next (240 = 1 second).");
            optionInt("Hold for", "autoclicker.hold", 1, 239, "Ticks each click is held down. Has to be less than the above.");
            optionCheckbox("Click for player 2 too", "autoclicker.player2", "In dual mode, player 2 clicks too.");
        });
        stateRow("Click Between Frames", level::clickBetweenFramesOn(), level::clickBetweenFrames()
            ? "Turns the Click Between Frames mod (by syzzi) on and off: your clicks count at the exact moment you press, "
              "not at the next frame."
            : "Needs the Click Between Frames mod (by syzzi), installed and turned on in Geode's mod list. Then this "
              "switches it on and off.",
            [] {
                if (!level::clickBetweenFrames()) {
                    notify("Install or turn on Click Between Frames (by syzzi) in Geode's mod list first");
                    return;
                }
                level::setClickBetweenFrames(!level::clickBetweenFramesOn());
            }, [] {
                optionKey("Toggle key", "key.cbf");
            });
        hackRow("Click Between Steps", "click-between-steps", "GD's own hidden option: a click counts between two physics "
            "steps instead of at the next one.");
        hackRow("Click On Steps", "click-on-steps", "GD's own hidden option: clicks only count on physics steps.");
        endCategory();
    }

    void deathOptions() {
        optionCheckbox("Show crosses in the level", "deaths.markers", "Shows where you died while you play.");
        optionCheckbox("Count practice mode deaths", "deaths.practice", "Turn off to only count deaths in normal mode.");
        ImGui::Separator();
        auto summary = deaths::current();
        if (!summary) {
            optionText("Open a level to see where you died in it.");
            return;
        }
        auto heading = fmt::format("{}: {} {}", summary->levelName, summary->total, summary->total == 1 ? "death" : "deaths");
        optionText(heading.c_str());
        if (!summary->platformer && summary->total > 0) {
            float values[101];
            int most[3] = { -1, -1, -1 };
            for (int i = 0; i <= 100; i++) {
                values[i] = static_cast<float>(summary->percents[i]);
                if (!summary->percents[i]) continue;
                // Keep the three percents with the most deaths
                for (int slot = 0; slot < 3; slot++) {
                    if (most[slot] < 0 || summary->percents[i] > summary->percents[most[slot]]) {
                        for (int move = 2; move > slot; move--) most[move] = most[move - 1];
                        most[slot] = i;
                        break;
                    }
                }
            }
            ImGui::PlotHistogram("##deaths", values, 101, 0, nullptr, 0.f, FLT_MAX, { px(276.f), px(70.f) });
            tooltipForItem("Deaths at each percent, 0% on the left, 100% on the right. Hover a bar to see its percent and "
                "deaths.");
            std::string text = "Most deaths at:";
            for (int percent : most) {
                if (percent >= 0) text += fmt::format("  {}% ({})", percent, summary->percents[percent]);
            }
            optionText(text.c_str());
        }

        // Clicked once, the button asks to be clicked again
        static double s_clearAskedAt = -10.0;
        bool asking = ImGui::GetTime() - s_clearAskedAt < 3.0;
        ImGui::BeginDisabled(summary->total == 0);
        if (ImGui::Button(asking ? "Click again to clear" : "Clear this level's deaths")) {
            if (asking) {
                deaths::clearCurrent();
                s_clearAskedAt = -10.0;
            }
            else {
                s_clearAskedAt = ImGui::GetTime();
            }
        }
        ImGui::EndDisabled();
    }

    // Buttons that change the saved progress of the level being played or looked at
    void levelProgress() {
        if (!matchesSearch("Level progress") && !matchesSearch("Uncomplete") && !matchesSearch("Reset")) return;
        section("Level progress");
        auto gjLevel = level::current();
        if (!gjLevel) {
            dimText("Open a level (or its info page) to change its progress.");
            return;
        }
        dimText(fmt::format("{}: best {}%, practice {}%, {} attempts", std::string(gjLevel->m_levelName),
            gjLevel->m_normalPercent.value(), gjLevel->m_practicePercent, gjLevel->m_attempts.value()));
        ImVec2 size = { innerWidth() - 2.f * px(kPadding), 0.f };
        auto button = [&](char const* label, bool enabled, char const* description, auto action) {
            space(4.f);
            ImGui::SetCursorPosX(px(kPadding));
            ImGui::BeginDisabled(!enabled);
            if (confirmButton(label, "Click again to do it", size)) action();
            ImGui::EndDisabled();
            tooltipForItem(description);
        };
        button("Uncomplete level", level::completed(gjLevel), "Takes back the level's completion (only when it's completed). "
            "Its best goes back to 0%. Click twice.", [&] { level::uncomplete(gjLevel); });
        button("Uncomplete practice", level::practiceCompleted(gjLevel), "Takes back the practice mode completion (only "
            "when it's completed). Click twice.", [&] { level::uncompletePractice(gjLevel); });
        button("Reset level progress", true, "Normal mode only: best percentage, attempts, jumps, clicks and the completion "
            "go back to nothing. Click twice.", [&] { level::resetProgress(gjLevel); });
        button("Reset practice progress", true, "Practice mode only: the practice best goes back to 0%. Click twice.",
            [&] { level::resetPractice(gjLevel); });
        space(2.f);
    }

    void levelWindow() {
        beginCategory("Level");
        auto startPosText = fmt::format("In levels with start positions, {} and {} (or the arrows at the bottom of the screen) "
            "pick where the level starts. 0 is the real start. Starting from a start position never saves progress.",
            keyName(config::getKey("key.startpos.prev")), keyName(config::getKey("key.startpos.next")));
        hackRow("StartPos Switcher", "startpos", startPosText.c_str(), [] {
            optionKey("Previous", "key.startpos.prev");
            optionKey("Next", "key.startpos.next");
        });
        hackRow("Smart StartPos", "startpos.smart", "Start positions get the game mode, speed, size, dual mode and gravity of "
            "the portals before them, so you start the way you'd really get there.");

        auto stepperText = fmt::format("Freezes the level so it moves one tick (1/240 s) at a time: {} steps forward, {} steps "
            "back (practice mode only). {} freezes and unfreezes.", keyName(config::getKey("key.stepper.step")),
            keyName(config::getKey("key.stepper.back")), keyName(config::getKey("key.stepper")));
        stateRow("Frame Stepper", stepper::isFrozen(), stepperText.c_str(), [] { stepper::setFrozen(!stepper::isFrozen()); }, [] {
            optionKey("Freeze key", "key.stepper");
            optionKey("Step forward", "key.stepper.step");
            optionKey("Step back", "key.stepper.back");
            optionInt("Rewind history", "stepper.history", 10, 2400,
                "How many ticks you can step back (240 = 1 second). More uses more memory.");
            optionCheckbox("Show tick counter", "stepper.label", "Shows the current tick in the corner while the level is frozen.");
        });

        hackRow("Death Tracker", "deaths", "Remembers where you die in each level: a red cross at each spot, bigger the more "
            "you died there, with the count next to it. Right-click for a chart of your deaths per percent.", [] {
            deathOptions();
        });

        hackRow("Confirm Exit", "confirm-exit", "Asks before leaving a level from the pause menu, so you can't quit by accident.");
        hackRow("Confirm Practice", "confirm-practice", "Asks before going into or out of practice mode from the pause menu.");
        hackRow("0% Practice Complete", "practice-complete", "Beat a level in practice mode from the start without dying once, "
            "and it counts like a normal completion.");
        hackRow("Auto Kill", "autokill", "Kills you when you reach the percentage set in the options. Goes through noclip.", [] {
            optionInt("At", "autokill.percent", 1, 100, "The percentage you die at.");
            optionCheckbox("In practice mode too", "autokill.practice",
                "Off: only normal mode. In practice mode you'd keep dying at your checkpoint after this point.");
        });
        hackRow("Auto Deafen", "deafen", "Deafens you on Discord once you get past a percentage, and undeafens when the "
            "attempt ends. It presses Discord's deafen shortcut for you, so set the same key in Discord (User Settings, "
            "Keybinds, Toggle Deafen) and in the options here.", [] {
            optionInt("Deafen at", "deafen.percent", 1, 100, "The percentage you get deafened at (normal mode only).");
            optionKey("Discord's key", "deafen.key");
            optionCheckbox("Ctrl", "deafen.ctrl", nullptr);
            ImGui::SameLine();
            optionCheckbox("Shift", "deafen.shift", nullptr);
            ImGui::SameLine();
            optionCheckbox("Alt", "deafen.alt", nullptr);
            optionText("Use a key with Ctrl and Shift, so GD doesn't do anything with it too.");
        });
        hackRow("Jumpscare", "jumpscare", "Dying past a percentage flashes a picture over the whole screen with a loud sound. "
            "Pick your own picture in the options.", [] {
            optionInt("From", "jumpscare.percent", 0, 100, "Only deaths at or after this percentage.");
            optionInt("Chance", "jumpscare.chance", 1, 100, "How likely each of those deaths is to get one, in percent.");
            auto const& image = config::getString("jumpscare.image");
            auto name = image.empty() ? std::string("The extreme demon face") : std::filesystem::path(image).filename().string();
            optionText(fmt::format("Picture: {}", name).c_str());
            if (ImGui::Button("Pick a picture...")) {
                pickFile(L"Pick a jumpscare picture", L"Pictures", L"*.png;*.jpg;*.jpeg", {}, [](std::filesystem::path const& path) {
                    config::setString("jumpscare.image", path.string());
                });
            }
            ImGui::SameLine();
            if (ImGui::Button("Use the default")) config::setString("jumpscare.image", "");
            ImGui::SameLine();
            if (ImGui::Button("Test")) {
                if (!PlayLayer::get()) notify("Open a level to test it");
                else level::testJumpscare();
            }
        });
        hackRow("Instant Complete", "instant-complete", "Beats the level as soon as it starts. Counts as a cheat.");
        hackRow("Force Platformer", "force-platformer", "Every level plays as a platformer level: you walk left and right "
            "yourself. Takes effect when a level opens. Counts as a cheat.");
        hackRow("Auto Music Sync", "music-sync", "Keeps the song in time with the level when it drifts (lag, the frame "
            "stepper, the speedhack without changing the music).");

        if (matchesSearch("Restart from 0%")) {
            space(5.f);
            ImGui::SetCursorPosX(px(kPadding));
            if (ImGui::Button("Restart from 0%", { innerWidth() - 2.f * px(kPadding), 0.f }) && !level::restartFromStart()) {
                notify("Open a level first");
            }
            tooltipForItem("Restarts the level from the very start, even in practice mode.");
        }
        levelProgress();
        endCategory();
    }

    // The Macro tab

    char s_saveName[96] = "";
    // What the last open, convert or save did
    std::string s_macroMessage;

    std::vector<macro::FormatInfo const*> writableFormats() {
        std::vector<macro::FormatInfo const*> out;
        for (auto const& format : macro::formats()) {
            if (format.canWrite) out.push_back(&format);
        }
        return out;
    }

    std::string formatLabel(macro::FormatInfo const& format) {
        return fmt::format("{} ({})", format.name, format.extension);
    }

    void openMacro(std::filesystem::path const& path) {
        auto result = macro::open(path);
        auto name = path.filename().string();
        s_macroMessage = result ? fmt::format("Opened {}", name) : fmt::format("Couldn't open {}: {}", name, result.unwrapErr());
        if (!result) Notification::create(s_macroMessage, NotificationIcon::Error)->show();
    }

    // When the open file window last closed. Clicks and keys from it can reach
    // the menu right after, which shouldn't open it again.
    std::chrono::steady_clock::time_point s_browseClosedAt;
    bool s_browsing = false;

    // Windows' own open file window. It waits until the menu is done drawing.
    // The patterns are like "*.png;*.jpg".
    void pickFile(std::wstring title, std::wstring kind, std::wstring patterns, std::filesystem::path folder,
            std::function<void(std::filesystem::path const&)> picked) {
        if (s_browsing || std::chrono::steady_clock::now() - s_browseClosedAt < std::chrono::milliseconds(600)) return;
        s_browsing = true;
        queueInMainThread([title = std::move(title), kind = std::move(kind), patterns = std::move(patterns),
                folder = std::move(folder), picked = std::move(picked)] {
            // The kind, its patterns, "All files", "*.*", each ending in a zero
            std::wstring filter = kind;
            filter.push_back(L'\0');
            filter += patterns;
            filter.push_back(L'\0');
            filter += L"All files";
            filter.push_back(L'\0');
            filter += L"*.*";
            filter.push_back(L'\0');
            filter.push_back(L'\0');

            std::error_code error;
            if (!folder.empty()) std::filesystem::create_directories(folder, error);
            auto initial = folder.wstring();
            wchar_t chosenPath[MAX_PATH] = L"";
            OPENFILENAMEW options = {};
            options.lStructSize = sizeof(options);
            options.hwndOwner = GetActiveWindow();
            options.lpstrFilter = filter.c_str();
            options.lpstrFile = chosenPath;
            options.nMaxFile = MAX_PATH;
            options.lpstrInitialDir = initial.empty() ? nullptr : initial.c_str();
            options.lpstrTitle = title.c_str();
            options.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
            bool chosen = GetOpenFileNameW(&options);
            s_browsing = false;
            s_browseClosedAt = std::chrono::steady_clock::now();
            if (chosen) picked(std::filesystem::path(chosenPath));
        });
    }

    void browseForMacro() {
        std::wstring patterns;
        for (auto const& format : macro::formats()) {
            // "*.gdr.json" is already "*.json"
            std::string extension = format.extension;
            extension = extension.substr(extension.rfind('.'));
            std::wstring pattern = L"*" + std::wstring(extension.begin(), extension.end());
            if ((L";" + patterns + L";").find(L";" + pattern + L";") != std::wstring::npos) continue;
            if (!patterns.empty()) patterns += L";";
            patterns += pattern;
        }
        pickFile(L"Open a macro", L"Macros", patterns, macro::folder(), [](std::filesystem::path const& path) { openMacro(path); });
    }

    // A combo box of the formats GrassyHack can make, saved in an option
    void formatCombo(char const* id, char const* key) {
        auto current = static_cast<int>(config::getInt(key));
        auto const& chosen = macro::info(static_cast<macro::Format>(current));
        if (ImGui::BeginCombo(id, formatLabel(chosen).c_str(), ImGuiComboFlags_HeightLarge)) {
            for (auto format : writableFormats()) {
                bool selected = static_cast<int>(format->format) == current;
                if (ImGui::Selectable(formatLabel(*format).c_str(), selected)) {
                    config::setInt(key, static_cast<int>(format->format));
                }
                tooltipForItem(fmt::format("Used by {}", format->bots).c_str());
            }
            ImGui::EndCombo();
        }
    }

    void toggleMacro(macro::State state) {
        macro::setState(macro::state() == state ? macro::State::Off : state);
    }

    // A button as wide as the window's inside
    bool wideButton(char const* label) {
        ImGui::SetCursorPosX(px(kPadding));
        return ImGui::Button(label, { innerWidth() - 2.f * px(kPadding), 0.f });
    }

    void macroTab() {
        using macro::State;
        auto state = macro::state();
        stateRow("Record", state == State::Recording, "Records your clicks from the start of the level. Beat the level and the "
            "macro is saved in the macros folder. Practice mode works too: respawning takes the recording back to your "
            "checkpoint.", [] { toggleMacro(State::Recording); }, [] {
            optionLabel("Save as");
            formatCombo("##save-format", "macro.format");
            tooltipForItem("The kind of file recordings are saved as. GDR works in the most bots.");
            optionCheckbox("Save when you beat the level", "macro.autosave", "Saves the recording as soon as you beat the level.");
            optionKey("Start / stop key", "key.macro.record");
        });
        stateRow("Play", state == State::Playing, "Plays the macro picked below from the start of the level, and again on "
            "every restart. Your own clicks are ignored while it plays. Counts as a cheat.", [] { toggleMacro(State::Playing); }, [] {
            optionKey("Start / stop key", "key.macro.play");
        });

        space(4.f);
        lineLabel("Macro", 64.f);
        auto const& files = macro::files();
        auto loaded = macro::loaded();
        auto preview = loaded ? loaded->path.filename().string() : files.empty() ? std::string("No macros yet") : std::string("Pick one...");
        if (ImGui::BeginCombo("##macro-file", preview.c_str(), ImGuiComboFlags_HeightLarge)) {
            for (size_t i = 0; i < files.size(); i++) {
                auto label = fmt::format("{}  ({})##{}", files[i].name, files[i].formatName, i);
                if (ImGui::Selectable(label.c_str(), loaded && loaded->path == files[i].path)) openMacro(files[i].path);
            }
            ImGui::EndCombo();
        }
        tooltipForItem("The macros in GrassyHack's macros folder, newest first. Put other bots' macros in that folder, or use "
            "Browse to open one from anywhere.");

        space(5.f);
        float spacing = px(5.f);
        float width = (innerWidth() - 2.f * px(kPadding) - 2.f * spacing) / 3.f;
        ImGui::SetCursorPosX(px(kPadding));
        if (ImGui::Button("Browse...", { width, 0.f })) browseForMacro();
        tooltipForItem("Open a macro file from anywhere on your PC.");
        ImGui::SameLine(0.f, spacing);
        if (ImGui::Button("Folder", { width, 0.f })) file::openFolder(macro::folder());
        tooltipForItem("Opens the macros folder.");
        ImGui::SameLine(0.f, spacing);
        if (ImGui::Button("Refresh", { width, 0.f })) macro::files(true);
        tooltipForItem("Looks for new files in the macros folder.");

        if (loaded) {
            auto const& opened = loaded->macro;
            auto seconds = static_cast<int>(opened.seconds());
            auto text = fmt::format("{}: {} inputs, {}:{:02} long, {:g} ticks a second", macro::info(loaded->format).name,
                opened.inputs.size(), seconds / 60, seconds % 60, opened.fps);
            if (!opened.botName.empty()) text += fmt::format(", made with {}", opened.botName);
            if (std::abs(opened.fps - 240.0) > 0.01) text += ". GD normally runs at 240, so it may not play right.";
            space(4.f);
            dimText(text);

            space(6.f);
            lineLabel("Convert to", 82.f);
            formatCombo("##convert-format", "macro.convert-format");
            space(5.f);
            if (wideButton("Convert")) {
                auto format = static_cast<macro::Format>(config::getInt("macro.convert-format"));
                auto result = macro::convertLoaded(format);
                s_macroMessage = result ? fmt::format("Made {}", result.unwrap().filename().string())
                                        : fmt::format("Couldn't convert: {}", result.unwrapErr());
                Notification::create(s_macroMessage, result ? NotificationIcon::Success : NotificationIcon::Error)->show();
            }
            tooltipForItem("Saves the macro in the chosen format in the macros folder, for another bot to use.");
        }

        if (!macro::recording().inputs.empty() && state != State::Recording) {
            space(6.f);
            if (!s_saveName[0]) std::snprintf(s_saveName, sizeof(s_saveName), "%s", macro::recording().levelName.c_str());
            lineLabel("Name", 64.f);
            ImGui::InputText("##save-name", s_saveName, sizeof(s_saveName));
            space(5.f);
            if (wideButton("Save recording")) {
                auto format = static_cast<macro::Format>(config::getInt("macro.format"));
                auto result = macro::saveRecording(s_saveName, format);
                s_macroMessage = result ? fmt::format("Saved {}", result.unwrap().filename().string())
                                        : fmt::format("Couldn't save: {}", result.unwrapErr());
                Notification::create(s_macroMessage, result ? NotificationIcon::Success : NotificationIcon::Error)->show();
            }
            tooltipForItem("Saves your last recording in the macros folder, as the format picked in Record's options.");
        }

        auto status = macro::status();
        if (status.empty()) status = s_macroMessage;
        if (!status.empty()) {
            space(4.f);
            dimText(status);
        }
        space(4.f);
    }

    void autoBotTab() {
        auto botText = fmt::format("Plays the level by trial and error until it finds a way through, then plays that run from "
            "0% to check it. Turn on practice mode first. {} starts and stops it.", keyName(config::getKey("key.bot")));
        stateRow("Auto Bot", bot::isRunning(), botText.c_str(), [] { bot::toggle(); }, [] {
            optionInt("Search speed", "bot.search-speed", 1, 200,
                "How many times faster than normal the game runs while the bot searches. It never takes more than about "
                "12 ms per frame, so busy levels run slower than this.");
            optionInt("Full run speed", "bot.verify-speed", 1, 200,
                "How fast the bot plays the found run from 0% once it's done. 1 = normal speed, so you can watch it.");
            optionInt("Input precision", "bot.precision", 1, 8,
                "How often (in ticks) the bot normally changes its input. 1 = every tick (slowest), 4 = like a 60 FPS player. "
                "When stuck it also tries the ticks in between.");
            optionInt("Look-back", "bot.look-back", 30, 720,
                "After dying, the bot first changes its inputs this many ticks before the death (240 = 1 second), then "
                "looks further back if nothing works.");
            optionInt("Max snapshots", "bot.max-snapshots", 50, 3000,
                "How many restore points the bot keeps. More = faster search but more memory.");
            optionInt("Give up after", "bot.max-attempts", 0, 1000000,
                "The bot stops if it hasn't gotten further in this many attempts. 0 = never give up.",
                ImGuiSliderFlags_Logarithmic);
            optionCheckbox("Fast restarts", "bot.fast-restarts",
                "Restarts skip decoration that's in no group, which can't affect the player. Much faster on big levels. "
                "Turn it off if a found run doesn't work when played from 0%.");
            optionCheckbox("Show status", "bot.show-status", "Shows the bot's progress in the corner of the level.");
            optionKey("Start / stop key", "key.bot");
        });
        if (matchesSearch("Auto Bot")) {
            // Off, the status is how the last run ended
            auto status = bot::status();
            if (!bot::isRunning()) {
                status = fmt::format("{}{}Off. Open a level in practice mode and press {}.", status, status.empty() ? "" : "\n",
                    keyName(config::getKey("key.bot")));
            }
            dimText(status);
            space(4.f);
        }
    }

    void botWindow() {
        beginCategory("Bot");
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, { px(4.f), px(4.f) });
        ImGui::SetCursorPosX(px(kPadding));
        bool tabs = ImGui::BeginTabBar("##bot-tabs");
        ImGui::PopStyleVar();
        if (tabs) {
            if (ImGui::BeginTabItem("Auto Bot")) {
                space(3.f);
                autoBotTab();
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem("Macro")) {
                space(3.f);
                macroTab();
                ImGui::EndTabItem();
            }
            ImGui::EndTabBar();
        }
        endCategory();
    }

    // The cheat indicator's options: which ruleset it follows, and making your own
    void rulesetOptions() {
        auto& all = rulesets::all();
        optionLabel("Ruleset");
        if (ImGui::BeginCombo("##ruleset", rulesets::selected().name.c_str())) {
            for (int i = 0; i < static_cast<int>(all.size()); i++) {
                ImGui::PushID(i);
                if (ImGui::Selectable(all[i].name.c_str(), i == rulesets::selectedIndex())) rulesets::select(i);
                ImGui::PopID();
            }
            ImGui::EndCombo();
        }
        tooltipForItem("Decides what counts as cheating. GD: noclip, speedhack, frame stepper and the bot. "
            "Pointercrate (the Demon List): the same, plus starting from a start position.");

        auto& ruleset = all[rulesets::selectedIndex()];
        if (!ruleset.builtIn) {
            optionLabel("Name");
            char name[48];
            std::snprintf(name, sizeof(name), "%s", ruleset.name.c_str());
            if (ImGui::InputText("##ruleset-name", name, sizeof(name)) && name[0]) {
                ruleset.name = name;
                rulesets::save();
            }
        }

        optionText(ruleset.builtIn ? "Allowed in this ruleset (it's built in, so make a new one to pick your own):"
                                   : "Allowed in this ruleset:");
        ImGui::BeginDisabled(ruleset.builtIn);
        for (auto const& info : rulesets::cheats()) {
            bool allowed = !(ruleset.banned & info.cheat);
            if (ImGui::Checkbox(info.name, &allowed)) {
                ruleset.banned ^= info.cheat;
                rulesets::save();
            }
        }
        ImGui::EndDisabled();

        if (ImGui::Button("New ruleset")) rulesets::addCustom();
        tooltipForItem("Makes a new ruleset, starting from a copy of this one.");
        if (!ruleset.builtIn) {
            ImGui::SameLine();
            if (ImGui::Button("Delete this ruleset")) rulesets::removeSelected();
        }
    }

    void labelsWindow() {
        beginCategory("Labels");
        hackRow("Cheat Indicator", "cheat-indicator", "A dot in the bottom right corner of the level: green while this attempt "
            "only used what the chosen ruleset allows, red once it used something the ruleset bans. Right-click to pick the "
            "ruleset or make your own.", [] { rulesetOptions(); });
        hackRow("Custom Text", "labels.custom", "Your own text, at the top of the labels.", [] {
            optionLabel("Text");
            char text[128];
            std::snprintf(text, sizeof(text), "%s", config::getString("labels.custom.text").c_str());
            if (ImGui::InputText("##custom-text", text, sizeof(text))) config::setString("labels.custom.text", text);
        });
        hackRow("FPS", "labels.fps", "Frames per second the game is drawing.");
        hackRow("CPS", "labels.cps", "Clicks per second: your clicks in the last second.", [] {
            optionCheckbox("Also show your best", "labels.cps.best", "Adds the most clicks you did in one second in this level.");
        });
        hackRow("Frame", "labels.frame", "The tick you're on in this attempt (240 a second), like a bot's frame number.");
        hackRow("Clock", "labels.clock", "Shows the real time.", [] {
            optionCheckbox("12-hour clock (AM/PM)", "labels.clock.12h", nullptr);
            optionCheckbox("Show seconds", "labels.clock.seconds", nullptr);
        });
        hackRow("Session Time", "labels.session", "How long you've been in this level, from when you opened it.");
        hackRow("Attempts", "labels.attempts", "Your attempt in this session, like GD's own \"Attempt\" text.", [] {
            optionCheckbox("Also show the level's total", "labels.attempts.total", "Adds how many attempts the level has in all.");
        });
        hackRow("Percentage", "labels.percent", "Your exact percentage, with decimals. Not shown in platformer levels.", [] {
            optionInt("Decimals", "labels.percent.decimals", 0, 4, "How many numbers after the dot.");
        });
        hackRow("Noclip Accuracy", "labels.noclip-accuracy", "While noclip is on: how much of this attempt you spent not "
            "touching anything deadly.");
        hackRow("Noclip Deaths", "labels.noclip-deaths", "While noclip is on: how many times this attempt you went into "
            "something that would have killed you.");
        hackRow("Hide StartPos UI", "startpos.hide-ui", "Hides the start position number and arrows at the bottom of the "
            "screen. Switching with the keys still works.");

        if (matchesSearch("Transparency")) {
            space(4.f);
            lineLabel("Transparency", 104.f);
            int transparency = static_cast<int>(config::getInt("labels.transparency"));
            if (ImGui::SliderInt("##transparency", &transparency, 0, 100, "%d%%", ImGuiSliderFlags_AlwaysClamp)) {
                config::setInt("labels.transparency", transparency);
            }
            tooltipForItem("How see-through the labels, the cheat indicator, the start position arrows and the tick "
                "counter are. 0% is solid, 100% is invisible.");
        }
        if (matchesSearch("Size")) {
            space(4.f);
            lineLabel("Size", 104.f);
            float size = static_cast<float>(config::getFloat("labels.size"));
            if (ImGui::SliderFloat("##label-size", &size, 0.5f, 2.f, "%.2fx", ImGuiSliderFlags_AlwaysClamp)) {
                config::setFloat("labels.size", size);
            }
            tooltipForItem("How big the labels' text is.");
        }
        if (matchesSearch("Corner")) {
            space(4.f);
            lineLabel("Corner", 104.f);
            int corner = static_cast<int>(config::getInt("labels.corner"));
            if (ImGui::Combo("##corner", &corner, "Top left\0Top right\0")) config::setInt("labels.corner", corner);
            tooltipForItem("Where the labels go on the screen.");
        }
        space(2.f);
        endCategory();
    }

    struct InstalledFont {
        std::string name;
        std::filesystem::path path;
    };

    // The fonts installed on the PC, from Windows' list of them (for everyone,
    // then just this user). Read once.
    std::vector<InstalledFont> const& installedFonts() {
        static std::vector<InstalledFont> s_fonts;
        static bool s_read = false;
        if (s_read) return s_fonts;
        s_read = true;
        wchar_t windows[MAX_PATH] = L"C:\\Windows";
        GetWindowsDirectoryW(windows, MAX_PATH);
        auto fontFolder = std::filesystem::path(windows) / L"Fonts";
        for (auto root : { HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER }) {
            HKEY key;
            if (RegOpenKeyExW(root, L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Fonts", 0, KEY_READ, &key) != ERROR_SUCCESS) {
                continue;
            }
            for (DWORD index = 0;; index++) {
                wchar_t name[512];
                wchar_t data[MAX_PATH];
                DWORD nameLength = 512;
                DWORD dataSize = sizeof(data);
                DWORD type = 0;
                auto result = RegEnumValueW(key, index, name, &nameLength, nullptr, &type, reinterpret_cast<BYTE*>(data),
                    &dataSize);
                if (result == ERROR_NO_MORE_ITEMS) break;
                if (result != ERROR_SUCCESS || type != REG_SZ) continue;
                data[std::min<size_t>(dataSize / sizeof(wchar_t), MAX_PATH - 1)] = 0;
                std::filesystem::path path(data);
                auto extension = path.extension().wstring();
                std::transform(extension.begin(), extension.end(), extension.begin(), ::towlower);
                if (extension != L".ttf" && extension != L".otf" && extension != L".ttc") continue;
                if (path.is_relative()) path = fontFolder / path;
                // "Arial Bold (TrueType)" is shown as "Arial Bold"
                auto shown = geode::utils::string::wideToUtf8(std::wstring_view(name, nameLength));
                if (auto bracket = shown.rfind(" ("); bracket != std::string::npos) shown.resize(bracket);
                s_fonts.push_back({ shown, path });
            }
            RegCloseKey(key);
        }
        std::sort(s_fonts.begin(), s_fonts.end(), [](auto const& a, auto const& b) {
            return geode::utils::string::toLower(a.name) < geode::utils::string::toLower(b.name);
        });
        return s_fonts;
    }

    // Custom Font: which font, and how big
    void fontOptions() {
        auto const& file = config::getString("font.file");
        std::string current = file.empty() ? "None picked yet" : std::filesystem::path(file).filename().string();
        for (auto const& font : installedFonts()) {
            if (!file.empty() && font.path == std::filesystem::path(file)) current = font.name;
        }
        optionLabel("Font");
        if (ImGui::BeginCombo("##font", current.c_str(), ImGuiComboFlags_HeightLarge)) {
            static char s_filter[64] = "";
            if (ImGui::IsWindowAppearing()) ImGui::SetKeyboardFocusHere();
            ImGui::SetNextItemWidth(-FLT_MIN);
            ImGui::InputTextWithHint("##font-filter", "Search fonts...", s_filter, sizeof(s_filter));
            auto filter = geode::utils::string::toLower(s_filter);
            for (auto const& font : installedFonts()) {
                if (!filter.empty() && geode::utils::string::toLower(font.name).find(filter) == std::string::npos) continue;
                bool picked = !file.empty() && font.path == std::filesystem::path(file);
                if (ImGui::Selectable(font.name.c_str(), picked)) config::setString("font.file", font.path.string());
                if (picked && ImGui::IsWindowAppearing()) ImGui::SetScrollHereY();
            }
            ImGui::EndCombo();
        }
        tooltipForItem("The fonts installed on your PC.");
        if (fonts::failed()) optionText("That font couldn't be read, so GD's own font is used.");
        if (ImGui::Button("Pick a font file...")) {
            auto profile = _wgetenv(L"USERPROFILE");
            auto downloads = profile ? std::filesystem::path(profile) / L"Downloads" : std::filesystem::path();
            pickFile(L"Pick a font", L"Fonts", L"*.ttf;*.otf;*.ttc", downloads, [](std::filesystem::path const& path) {
                config::setString("font.file", path.string());
            });
        }
        tooltipForItem("A .ttf or .otf font you downloaded, if it isn't installed.");
        optionFloat("Size", "font.size", 0.5f, 1.5f, "%.2fx", "How big the letters are next to GD's own font.");
        optionText("Text that's already on the screen keeps its font until you go to another screen.");
    }

    void visualWindow() {
        beginCategory("Visual");
        hackRow("Show Hitboxes", "hitboxes", "Shows what can hit you: red for things that kill, blue for blocks, green for "
            "orbs, pads and portals. GD's own practice mode hitboxes, in any mode.");
        hackRow("Hitboxes On Death", "hitboxes.death", "Shows the hitboxes only once you die, so you can see what got you.");
        hackRow("Hitbox Trail", "hitboxes.trail", "Draws your hitbox at each of the last 240 ticks, so you can see the path "
            "you took. Player 2's is blue. With Hitboxes On Death, it shows once you die.");
        hackRow("Show Trajectory", "trajectory", "Draws where you'll go: green if you hold from now, red if you let go. "
            "Counts as a cheat in the Pointercrate ruleset.");
        hackRow("Show Layout", "layout", "Hides decoration and gives the background and ground GD's default colors, so only "
            "what you can touch is left. Takes effect when a level opens.");
        hackRow("Show Triggers", "show-triggers", "Shows the triggers in the level, which GD hides while you play. Takes "
            "effect when a level opens.");
        endCategory();
    }

    void cosmeticWindow() {
        beginCategory("Cosmetic");
        section("Player");
        hackRow("Hide Player", "cosmetic.hide-player", "Makes the players and their trails invisible.");
        hackRow("Icon Randomizer", "cosmetic.icon-randomizer", "Every time you open a level, your icons and colors are picked "
            "at random from the ones you have unlocked. Your real icons stay as they are.");
        hackRow("Player Icon On Top", "cosmetic.icon-on-top", "Draws the players above everything else in the level.");
        hackRow("Player 1 On Top", "cosmetic.p1-on-top", "In dual mode, player 1 is drawn over player 2.");
        hackRow("Player 2 On Top", "cosmetic.p2-on-top", "In dual mode, player 2 is drawn over player 1.");
        section("Trails");
        hackRow("No Trail", "cosmetic.no-trail", "Hides the player's trail.");
        hackRow("Trail Always On", "cosmetic.trail-always", "The trail shows in every game mode, cube included.");
        hackRow("No Wave Trail", "cosmetic.no-wave-trail", "Hides the wave's trail.");
        hackRow("No Trail Behind Wave", "cosmetic.no-trail-behind-wave", "Hides the normal trail while you're the wave, so "
            "only the wave's own trail is left.");
        hackRow("No Wave Pulse", "cosmetic.no-wave-pulse", "The wave's trail stays the same width instead of pulsing with the "
            "music.");
        hackRow("Wave Pulse Size", "cosmetic.wave-pulse-size", "Sets how much the wave's trail pulses. Pick it in the options.", [] {
            optionFloat("Strength", "cosmetic.wave-pulse-size.value", 0.f, 5.f, "%.2fx", "How strongly the trail pulses. 1 is GD's own, 0 is no pulse.");
        });
        section("Effects");
        hackRow("No Death Effect", "cosmetic.no-death-effect", "No explosion when you die.");
        hackRow("No Respawn Flash", "cosmetic.no-respawn-flash", "No flash and circle when you respawn.");
        hackRow("No Ghost Trail", "cosmetic.no-ghost-trail", "No ghost copies of the player behind it (from ghost trail triggers).");
        hackRow("No Dash Fire", "cosmetic.no-dash-fire", "No fire on the player while it dashes from a dash orb.");
        hackRow("No Robot Fire", "cosmetic.no-robot-fire", "No fire under the robot when it jumps.");
        hackRow("No Swing Fire", "cosmetic.no-swing-fire", "No fire on the swing.");
        hackRow("No Spider Dash", "cosmetic.no-spider-dash", "No streak when the spider teleports up or down.");
        hackRow("No Orb Ring", "cosmetic.no-orb-ring", "No ring growing out of an orb when you click it.");
        hackRow("No Particles", "cosmetic.no-particles", "Hides every particle effect in levels.");
        hackRow("No Glow", "cosmetic.no-glow", "Objects have no glow around them. Takes effect when a level opens.");
        hackRow("No Pulse", "cosmetic.no-pulse", "Objects stop pulsing to the music.");
        hackRow("No Shaders", "cosmetic.no-shaders", "Turns off shader effects (shader triggers): no blur, glitch, colors "
            "and so on.");
        section("Camera");
        hackRow("No Shake", "cosmetic.no-shake", "The screen never shakes.");
        hackRow("No End Shake", "cosmetic.no-end-shake", "No shake when you beat a level.");
        hackRow("No Camera Zoom", "cosmetic.no-zoom", "Zoom triggers don't zoom the camera.");
        hackRow("No Mirror", "cosmetic.no-mirror", "Mirror portals don't flip the screen. Counts as a cheat in the "
            "Pointercrate ruleset.");
        hackRow("StartPos Reset Camera", "cosmetic.startpos-camera", "Starting from a start position puts the camera back "
            "to normal, like GD's \"Reset Camera\" option on start positions.");
        section("Text");
        hackRow("Accurate Percentage", "cosmetic.accurate-percent", "GD's percentage at the top shows decimals.", [] {
            optionInt("Decimals", "cosmetic.accurate-percent.decimals", 0, 6, "How many numbers after the dot.");
        });
        hackRow("Show Total Attempts", "cosmetic.total-attempts", "The \"Attempt\" text in the level counts all your "
            "attempts on the level, not just this session's.");
        hackRow("No New Best Popup", "cosmetic.no-new-best", "No \"New Best\" text when you get further than before.");
        hackRow("No \"Do Not\" Flip", "cosmetic.no-do-not", "GD's hidden \"Do Not\" setting mirrors the attempt and new "
            "best text. This puts it back the right way around.");
        hackRow("Custom Font", "font", "GD's text uses a font from your PC (a .ttf or .otf file), with GD's black outline "
            "and gold colors. Text placed in levels keeps the creator's font. Pick the font in the options.", [] {
            fontOptions();
        });
        section("Other");
        hackRow("Stop Triggers On Death", "cosmetic.stop-triggers", "When you die, everything in the level stops moving "
            "until you respawn.");
        hackRow("Pitch Shifter", "cosmetic.pitch", "Changes the pitch of the music without changing its speed. Set it in the "
            "options.", [] {
            optionFloat("Pitch", "cosmetic.pitch.value", 0.5f, 2.f, "%.2fx", "1 is normal, 2 is an octave higher, 0.5 an "
                "octave lower.");
        });
        endCategory();
    }

    std::string bindKey(Bind const& bind) {
        return fmt::format("key.{}", bind.option);
    }

    // Every keybind in one list: click a key to change it, the x removes it
    void keybindsWindow() {
        if (!s_keybindsOpen) return;
        auto display = ImGui::GetIO().DisplaySize;
        float width = px(360.f);
        ImGui::SetNextWindowPos({ display.x / 2.f, display.y / 2.f }, s_resetLayout ? ImGuiCond_Always : ImGuiCond_FirstUseEver,
            { 0.5f, 0.5f });
        if (s_moveWindows != 1.f && !s_resetLayout) {
            if (auto window = ImGui::FindWindowByName("Keybinds")) {
                ImGui::SetNextWindowPos({ window->Pos.x * s_moveWindows, window->Pos.y * s_moveWindows });
            }
        }
        ImGui::SetNextWindowSize({ width, 0.f });
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, { 0.f, 0.f });
        ImGui::Begin("Keybinds", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
            ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoCollapse);
        ImGui::PopStyleVar();
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, { 0.f, 0.f });
        drawHeader("Keybinds", width);

        // The close button in the header
        float header = px(kHeaderHeight);
        float closeSize = px(22.f);
        ImVec2 after = ImGui::GetCursorPos();
        ImGui::SetCursorPos({ width - closeSize - px(6.f), (header - closeSize) / 2.f });
        if (crossButton("##close", closeSize, "Close")) s_keybindsOpen = false;
        ImGui::SetCursorPos(after);

        // Count the keys, so ones used twice can be shown
        std::unordered_map<int, int> uses;
        for (auto const& bind : kBinds) {
            auto key = config::getKey(bindKey(bind));
            if (key != KEY_None) uses[key]++;
        }

        float pad = px(kPadding);
        float keyWidth = px(118.f);
        float rowHeight = ImGui::GetFrameHeight() + px(4.f);
        float listHeight = std::min(display.y * 0.7f, rowHeight * 34.f);
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, { px(6.f), px(4.f) });
        ImGui::BeginChild("##list", { width, listHeight }, ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground);
        char const* group = nullptr;
        for (auto const& bind : kBinds) {
            if (!matchesSearch(bind.name) && !matchesSearch(bind.group)) continue;
            if (!group || std::string_view(group) != bind.group) {
                group = bind.group;
                space(group == kBinds[0].group ? 2.f : 6.f);
                ImGui::SetCursorPosX(pad);
                ImGui::PushFont(s_boldFont, 0.f);
                ImGui::TextColored(accent(), "%s", group);
                ImGui::PopFont();
            }
            auto option = bindKey(bind);
            auto key = config::getKey(option);
            ImGui::PushID(bind.option);
            ImGui::SetCursorPosX(pad);
            ImGui::AlignTextToFramePadding();
            bool twice = key != KEY_None && uses[key] > 1;
            if (twice) ImGui::PushStyleColor(ImGuiCol_Text, ImVec4{ 1.f, 0.62f, 0.3f, 1.f });
            ImGui::TextUnformatted(bind.name);
            if (twice) ImGui::PopStyleColor();
            if (twice) tooltipForItem("This key is also used for something else. Both happen when you press it, or only "
                "one of them.");
            float closeX = width - pad - ImGui::GetFrameHeight() - px(14.f);
            ImGui::SameLine(closeX - px(6.f) - keyWidth);
            keyButton(option.c_str(), keyWidth);
            ImGui::SameLine(closeX);
            ImGui::BeginDisabled(key == KEY_None);
            if (crossButton("##remove", ImGui::GetFrameHeight(), "Remove this key")) {
                config::setKey(option, KEY_None);
                if (s_capturing == option) s_capturing.clear();
            }
            ImGui::EndDisabled();
            ImGui::PopID();
        }
        space(6.f);
        ImGui::EndChild();
        ImGui::PopStyleVar();
        dimText("Click a key, then press the new one. Backspace or Delete also removes it, Escape cancels.");
        space(8.f);
        ImGui::PopStyleVar();
        ImGui::End();
    }

    // Models on Groq's free plan, the first one is the default
    struct ChatModel {
        char const* id;
        char const* name;
        char const* description;
    };

    constexpr ChatModel kChatModels[] = {
        { "openai/gpt-oss-20b", "GPT-OSS 20B", "OpenAI's small free model. Quick, and plenty for chatting." },
        { "openai/gpt-oss-120b", "GPT-OSS 120B", "OpenAI's big free model. Smarter, but a bit slower." },
    };

    // The hacks the AI can turn on and off: every one with a toggle key
    std::vector<chat::Hack> chatHacks() {
        std::vector<chat::Hack> hacks;
        for (auto const& bind : kBinds) {
            if (bind.toggles) hacks.push_back({ bind.option, bind.name, bind.group });
        }
        return hacks;
    }

    void openChat(bool open) {
        s_chatOpen = open;
        s_focusChat = open;
    }

    // A round picture in the chat, with the top left corner at pos
    void drawPicture(chat::Picture const& picture, ImVec2 pos, float size) {
        auto draw = ImGui::GetWindowDrawList();
        float radius = size / 2.f;
        draw->AddCircleFilled({ pos.x + radius, pos.y + radius }, radius, color(kFrameHover));
        if (!picture.texture) return;
        draw->AddImageRounded(ImTextureRef(static_cast<ImTextureID>(picture.texture)), pos, { pos.x + size, pos.y + size },
            { picture.u0, picture.v0 }, { picture.u1, picture.v1 }, color(kWhite), radius);
    }

    // A color button for an option saved as 0xRRGGBB
    void colorOption(char const* id, char const* key, char const* description) {
        auto rgb = config::getInt(key);
        float picked[3] = { ((rgb >> 16) & 0xFF) / 255.f, ((rgb >> 8) & 0xFF) / 255.f, (rgb & 0xFF) / 255.f };
        if (ImGui::ColorEdit3(id, picked, ImGuiColorEditFlags_NoInputs)) {
            auto channel = [](float value) { return static_cast<int64_t>(std::lround(std::clamp(value, 0.f, 1.f) * 255.f)); };
            config::setInt(key, (channel(picked[0]) << 16) | (channel(picked[1]) << 8) | channel(picked[2]));
        }
        tooltipForItem(description);
    }

    // GD's icon types the AI's picture can be, as IconType values
    struct IconKind {
        int type;
        char const* name;
    };

    constexpr IconKind kIconKinds[] = {
        { 0, "Cube" }, { 1, "Ship" }, { 2, "Ball" }, { 3, "UFO" }, { 4, "Wave" }, { 5, "Robot" }, { 6, "Spider" },
        { 7, "Swing" }, { 8, "Jetpack" },
    };

    // The AI's picture: a GD icon of any kind, number and colors, or a picture from the PC
    void aiPictureOptions() {
        float preview = px(44.f);
        ImVec2 pos = ImGui::GetCursorScreenPos();
        drawPicture(chat::aiPicture(), pos, preview);
        ImGui::SetCursorScreenPos({ pos.x + preview + px(10.f), pos.y + (preview - ImGui::GetTextLineHeight()) / 2.f });
        ImGui::PushStyleColor(ImGuiCol_Text, kTextDim);
        ImGui::TextUnformatted("The AI's picture. Yours is your cube.");
        ImGui::PopStyleColor();
        ImGui::SetCursorScreenPos({ pos.x, pos.y + preview + px(6.f) });

        optionLabel("AI picture");
        int kind = static_cast<int>(config::getInt("chat.ai.picture"));
        char const* kinds[] = { "A GD icon", "A picture from your PC" };
        if (ImGui::Combo("##ai-picture", &kind, kinds, 2)) config::setInt("chat.ai.picture", kind);

        if (kind == 1) {
            auto const& image = config::getString("chat.ai.image");
            auto name = image.empty() ? std::string("None picked yet") : std::filesystem::path(image).filename().string();
            optionText(fmt::format("Picture: {}", name).c_str());
            if (!image.empty() && chat::aiImageMissing()) {
                optionText("That picture couldn't be opened, so the AI has its GD icon for now.");
            }
            if (ImGui::Button("Pick a picture...")) {
                pickFile(L"Pick the AI's picture", L"Pictures", L"*.png;*.jpg;*.jpeg", {}, [](std::filesystem::path const& path) {
                    config::setString("chat.ai.image", path.string());
                });
            }
            tooltipForItem("Any PNG or JPG. Only the middle square of it is shown, in a circle.");
            return;
        }

        optionLabel("Icon type");
        auto type = static_cast<int>(config::getInt("chat.ai.icon-type"));
        char const* typeName = "Cube";
        for (auto const& iconKind : kIconKinds) {
            if (iconKind.type == type) typeName = iconKind.name;
        }
        if (ImGui::BeginCombo("##ai-icon-type", typeName)) {
            for (auto const& iconKind : kIconKinds) {
                if (ImGui::Selectable(iconKind.name, iconKind.type == type)) {
                    config::setInt("chat.ai.icon-type", iconKind.type);
                    config::setInt("chat.ai.icon", 1);
                }
            }
            ImGui::EndCombo();
        }
        int count = std::max(1, GameManager::get()->countForType(static_cast<IconType>(type)));
        if (config::getInt("chat.ai.icon") > count) config::setInt("chat.ai.icon", count);
        optionInt("Icon", "chat.ai.icon", 1, count, "Which icon of that type, numbered like in GD's icon kit.");

        optionLabel("Colors");
        colorOption("##ai-color", "chat.ai.color", "The icon's main color.");
        ImGui::SameLine();
        colorOption("##ai-color2", "chat.ai.color2", "The icon's second color.");
        optionCheckbox("Glow", "chat.ai.glow", "An outline around the icon, like GD's glow.");
        if (config::getBool("chat.ai.glow")) {
            ImGui::SameLine();
            colorOption("##ai-glow", "chat.ai.glow-color", "The glow's color.");
        }
    }

    // Shown until there's a key: how to get one, and where to put it
    void chatKeySetup(float width) {
        float pad = px(kPadding);
        float full = width - 2.f * pad;
        space(8.f);
        dimText("The AI chat runs on Groq, which has free AI models. To use it, get your own free key:");
        space(4.f);
        dimText("1. Click Get a free key and make a Groq account. Groq is meant for people 18 and older.");
        dimText("2. Click Create API Key and copy the key.");
        dimText("3. Paste it here and click Save.");
        space(8.f);
        ImGui::SetCursorPosX(pad);
        if (ImGui::Button("Get a free key", { full, 0.f })) {
            utils::web::openLinkInBrowser("https://console.groq.com/keys");
        }
        tooltipForItem("Opens Groq's key page in your browser.");
        space(6.f);

        float buttonWidth = px(62.f);
        float gap = px(6.f);
        ImGui::SetCursorPosX(pad);
        ImGui::SetNextItemWidth(full - 2.f * (buttonWidth + gap));
        bool entered = ImGui::InputTextWithHint("##key", "Paste your key here", s_keyInput, sizeof(s_keyInput),
            ImGuiInputTextFlags_Password | ImGuiInputTextFlags_EnterReturnsTrue);
        ImGui::SameLine(0.f, gap);
        if (ImGui::Button("Paste", { buttonWidth, 0.f })) {
            auto pasted = utils::clipboard::read();
            pasted.erase(std::remove_if(pasted.begin(), pasted.end(), [](unsigned char c) { return std::isspace(c); }),
                pasted.end());
            std::snprintf(s_keyInput, sizeof(s_keyInput), "%s", pasted.c_str());
        }
        tooltipForItem("Puts the key you copied into the box.");
        ImGui::SameLine(0.f, gap);
        ImGui::BeginDisabled(!s_keyInput[0]);
        bool save = ImGui::Button("Save", { buttonWidth, 0.f });
        ImGui::EndDisabled();
        if ((save || entered) && s_keyInput[0]) {
            config::setString("chat.key", s_keyInput);
            config::save();
            s_keyInput[0] = 0;
            s_changingKey = false;
            s_focusChat = true;
        }
        std::string_view typed = s_keyInput;
        if (!typed.empty() && !typed.starts_with("gsk_")) {
            space(4.f);
            ImGui::SetCursorPosX(pad);
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4{ 1.f, 0.62f, 0.3f, 1.f });
            ImGui::TextUnformatted("Groq keys start with gsk_");
            ImGui::PopStyleColor();
        }
        space(6.f);
        dimText("Your key is only saved on this PC. Only Groq gets what you type in the chat.");
        if (s_changingKey && chat::hasKey()) {
            space(6.f);
            ImGui::SetCursorPosX(pad);
            if (ImGui::Button("Back to the chat", { full, 0.f })) s_changingKey = false;
        }
        space(10.f);
    }

    void chatMessages(float width) {
        float pad = px(kPadding);
        auto const& lines = chat::lines();
        float height = std::min(px(340.f), ImGui::GetIO().DisplaySize.y * 0.55f);
        ImGui::BeginChild("##messages", { width, height }, ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground);
        space(8.f);
        if (lines.empty()) {
            dimText("Ask anything about GrassyHack or Geometry Dash, or ask the AI to change hacks, like \"turn on "
                "noclip\" or \"make the game half speed\".");
        }
        using Who = chat::Line::Who;
        float pictureSize = px(30.f);
        // Text starts right of the pictures
        float textX = pad + pictureSize + px(9.f);
        auto you = chat::playerPicture();
        auto ai = chat::aiPicture();
        for (auto const& line : lines) {
            ImGui::PushTextWrapPos(innerWidth() - pad);
            if (line.who == Who::You || line.who == Who::Ai) {
                ImGui::SetCursorPosX(pad);
                ImVec2 top = ImGui::GetCursorScreenPos();
                drawPicture(line.who == Who::You ? you : ai, top, pictureSize);
                ImGui::SetCursorPosX(textX);
                ImGui::PushFont(s_boldFont, kFontSize - 2.f);
                ImGui::PushStyleColor(ImGuiCol_Text, line.who == Who::You ? accent() : kTextDim);
                ImGui::TextUnformatted(line.who == Who::You ? "You" : "AI");
                ImGui::PopStyleColor();
                ImGui::PopFont();
                space(1.f);
                ImGui::SetCursorPosX(textX);
                ImGui::TextUnformatted(line.text.c_str());
                // A short message still takes up the picture's height
                float below = top.y + pictureSize - ImGui::GetCursorScreenPos().y;
                if (below > 0.f) ImGui::Dummy({ 0.f, below });
            }
            else {
                ImGui::SetCursorPosX(textX);
                auto tint = line.who == Who::Error ? ImVec4{ 1.f, 0.62f, 0.3f, 1.f } : withAlpha(accent(), 0.9f);
                ImGui::PushFont(nullptr, kFontSize - 1.5f);
                ImGui::PushStyleColor(ImGuiCol_Text, tint);
                ImGui::TextUnformatted(line.text.c_str());
                ImGui::PopStyleColor();
                ImGui::PopFont();
            }
            ImGui::PopTextWrapPos();
            space(9.f);
        }
        if (chat::busy()) {
            int dots = static_cast<int>(ImGui::GetTime() * 3.0) % 3 + 1;
            dimText(fmt::format("AI is typing{}", std::string(dots, '.')));
            space(6.f);
        }
        // Scrolls down to new messages. Twice, as wrapped text only has its
        // final height a frame later.
        if (s_chatSeen != chat::changes() || s_chatSeenBusy != chat::busy()) {
            s_chatSeen = chat::changes();
            s_chatSeenBusy = chat::busy();
            s_chatScroll = 2;
        }
        if (s_chatScroll > 0) {
            s_chatScroll--;
            ImGui::SetScrollHereY(1.f);
        }
        ImGui::EndChild();
    }

    void chatSettings() {
        if (!beginOptions("AI Chat settings")) return;
        optionLabel("Model");
        auto const& current = config::getString("chat.model");
        char const* shown = current.c_str();
        for (auto const& model : kChatModels) {
            if (current == model.id) shown = model.name;
        }
        if (ImGui::BeginCombo("##model", shown)) {
            for (auto const& model : kChatModels) {
                if (ImGui::Selectable(model.name, current == model.id)) config::setString("chat.model", model.id);
                tooltipForItem(model.description);
            }
            ImGui::EndCombo();
        }
        tooltipForItem("Which of Groq's free AI models answers. They're all free.");
        optionCheckbox("Let the AI change hacks", "chat.tools",
            "The AI can turn hacks on and off and change the game speed when you ask it to.");
        optionKey("Open / close key", "key.chat");
        ImGui::Separator();
        if (ImGui::Button("Change key")) {
            s_changingKey = true;
            ImGui::CloseCurrentPopup();
        }
        ImGui::SameLine();
        if (confirmButton("Remove key", "Click again to remove")) {
            config::setString("chat.key", "");
            config::save();
            ImGui::CloseCurrentPopup();
        }
        optionText("Your key is only saved on this PC. Only Groq gets what you type in the chat.");
        ImGui::Separator();
        aiPictureOptions();
        endOptions();
    }

    // Talking to an AI through Groq (Chat.cpp does the talking)
    void chatWindow() {
        if (!s_chatOpen) return;
        auto display = ImGui::GetIO().DisplaySize;
        float width = px(400.f);
        ImGui::SetNextWindowPos({ display.x / 2.f, display.y / 2.f }, s_resetLayout ? ImGuiCond_Always : ImGuiCond_FirstUseEver,
            { 0.5f, 0.5f });
        if (s_moveWindows != 1.f && !s_resetLayout) {
            if (auto window = ImGui::FindWindowByName("AI Chat")) {
                ImGui::SetNextWindowPos({ window->Pos.x * s_moveWindows, window->Pos.y * s_moveWindows });
            }
        }
        ImGui::SetNextWindowSize({ width, 0.f });
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, { 0.f, 0.f });
        ImGui::Begin("AI Chat", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
            ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoCollapse);
        ImGui::PopStyleVar();
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, { 0.f, 0.f });
        drawHeader("AI Chat", width);

        float header = px(kHeaderHeight);
        float closeSize = px(22.f);
        ImVec2 after = ImGui::GetCursorPos();
        ImGui::SetCursorPos({ width - closeSize - px(6.f), (header - closeSize) / 2.f });
        if (crossButton("##close", closeSize, "Close")) openChat(false);
        ImGui::SetCursorPos(after);

        if (!chat::hasKey() || s_changingKey) {
            chatKeySetup(width);
        }
        else {
            chatMessages(width);
            float pad = px(kPadding);
            float gap = px(6.f);
            float sendWidth = px(64.f);
            space(4.f);
            ImGui::SetCursorPosX(pad);
            ImGui::SetNextItemWidth(width - 2.f * pad - sendWidth - gap);
            if (s_focusChat) {
                ImGui::SetKeyboardFocusHere();
                s_focusChat = false;
            }
            bool entered = ImGui::InputTextWithHint("##message", "Type a message...", s_chatInput, sizeof(s_chatInput),
                ImGuiInputTextFlags_EnterReturnsTrue);
            ImGui::SameLine(0.f, gap);
            ImGui::BeginDisabled(chat::busy() || !s_chatInput[0]);
            bool clicked = ImGui::Button("Send", { sendWidth, 0.f });
            ImGui::EndDisabled();
            if ((entered || clicked) && s_chatInput[0] && !chat::busy()) {
                chat::send(s_chatInput, chatHacks());
                s_chatInput[0] = 0;
            }
            // Enter takes the cursor out of the box, this puts it back to keep typing
            if (entered) s_focusChat = true;

            space(6.f);
            float half = (width - 2.f * pad - gap) / 2.f;
            ImGui::SetCursorPosX(pad);
            if (ImGui::Button("Settings", { half, 0.f })) ImGui::OpenPopup("AI Chat settings");
            tooltipForItem("The AI model, your key, and whether the AI can change hacks.");
            ImGui::SameLine(0.f, gap);
            if (ImGui::Button("Clear chat", { half, 0.f })) chat::clear();
            tooltipForItem("Starts a new chat. The AI forgets the old one.");
            chatSettings();
            space(10.f);
        }
        ImGui::PopStyleVar();
        ImGui::End();
    }

    void watermark() {
        auto display = ImGui::GetIO().DisplaySize;
        auto text = fmt::format("GrassyHack {}  |  {} to close", Mod::get()->getVersion().toVString(),
            keyName(config::getKey("key.menu")));
        auto size = ImGui::CalcTextSize(text.c_str());
        ImGui::GetForegroundDrawList()->AddText({ display.x - size.x - px(10.f), display.y - size.y - px(8.f) },
            color(withAlpha(kTextDim, 0.8f)), text.c_str());
    }

    void setOpen(bool open);

    void drawMenu() {
        auto& io = ImGui::GetIO();
        float step = config::getBool("menu.quick") ? 1.f : io.DeltaTime / kFadeSeconds;
        s_fade = s_open ? std::min(1.f, s_fade + step) : std::max(0.f, s_fade - step);
        if (!s_open && s_fade <= 0.f) {
            ImGuiCocos::get().setVisible(false);
            return;
        }

        // The UI scale option is on top of a size that suits the screen, 1 at 900 pixels high
        float screenScale = std::clamp(io.DisplaySize.y / 900.f, 0.75f, 3.f);
        s_scale = static_cast<float>(config::getFloat("menu.scale")) * screenScale;
        if (s_scale != s_styleScale) {
            if (s_styleScale > 0.f) s_moveWindows = s_scale / s_styleScale;
            applyStyle();
        }
        applyAccent(accent());
        s_resetLayout = s_resetLayoutNextFrame;
        s_resetLayoutNextFrame = false;
        s_captureButtonDrawn = false;
        s_windowIndex = 0;
        s_columnBottoms.clear();

        float alpha = s_fade * s_fade * (3.f - 2.f * s_fade);
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, alpha);
        if (config::getBool("menu.dim")) {
            ImGui::GetBackgroundDrawList()->AddRectFilled({ 0.f, 0.f }, io.DisplaySize, color({ 0.f, 0.f, 0.f, 0.38f }));
        }
        menuWindow();
        globalWindow();
        playerWindow();
        levelWindow();
        botWindow();
        // Last, so they get free spots instead of ones a window already has
        labelsWindow();
        bypassWindow();
        visualWindow();
        cosmeticWindow();
        keybindsWindow();
        chatWindow();
        watermark();
        ImGui::PopStyleVar();
        s_moveWindows = 1.f;

        // The button waiting for a key is gone (its popup closed), so stop waiting
        if (!s_captureButtonDrawn) s_capturing.clear();
        // Options changed in the menu show up in the level right away
        startpos::refresh();
        deaths::refresh();
    }

    void setOpen(bool open) {
        auto& imgui = ImGuiCocos::get();
        if (s_open == open || !imgui.isInitialized()) return;
        s_open = open;
        if (open) {
            imgui.setVisible(true);
            PlatformToolbox::showCursor();
            return;
        }
        s_capturing.clear();
        config::save();
        // GD hides the cursor while a level is being played
        auto pl = PlayLayer::get();
        if (pl && !pl->m_isPaused && !pl->m_hasCompletedLevel) PlatformToolbox::hideCursor();
    }

    void notify(std::string const& text) {
        Notification::create(text, NotificationIcon::Info, 1.f)->show();
    }

    // Returns whether the key did something, so GD doesn't also get it
    bool handleKey(enumKeyCodes key, bool repeat) {
        auto bound = [&](std::string_view option) {
            auto boundKey = config::getKey(option);
            return boundKey != KEY_None && boundKey == key;
        };
        // Holding a step key keeps stepping
        if (bound("key.stepper.step") && stepper::stepForward()) return true;
        if (bound("key.stepper.back") && stepper::stepBack()) return true;
        if (repeat) return false;

        if (bound("key.menu")) {
            menu::toggle();
            return true;
        }
        if (bound("key.stepper") && PlayLayer::get()) {
            stepper::setFrozen(!stepper::isFrozen());
            return true;
        }
        if (bound("key.bot") && PlayLayer::get()) {
            bot::toggle();
            return true;
        }
        if (bound("key.macro.record")) {
            toggleMacro(macro::State::Recording);
            return true;
        }
        if (bound("key.macro.play")) {
            toggleMacro(macro::State::Playing);
            return true;
        }
        if (bound("key.chat")) {
            openChat(!s_chatOpen);
            if (s_chatOpen) setOpen(true);
            return true;
        }
        if (bound("key.restart") && level::restartFromStart()) return true;
        if (bound("key.vsync")) {
            menus::setVsync(!menus::vsyncOn());
            notify(fmt::format("Vertical Sync {}", menus::vsyncOn() ? "on" : "off"));
            return true;
        }
        if (bound("key.cbf") && level::clickBetweenFrames()) {
            level::setClickBetweenFrames(!level::clickBetweenFramesOn());
            notify(fmt::format("Click Between Frames {}", level::clickBetweenFramesOn() ? "on" : "off"));
            return true;
        }
        if (bound("key.startpos.prev") && startpos::previous()) return true;
        if (bound("key.startpos.next") && startpos::next()) return true;
        for (auto const& bind : kBinds) {
            if (!bind.toggles || !bound(bindKey(bind))) continue;
            bool on = !config::getBool(bind.option);
            config::setBool(bind.option, on);
            notify(fmt::format("{} {}", bind.name, on ? "on" : "off"));
            return true;
        }
        return false;
    }

    // Keys that type something into a text box
    bool isTypingKey(enumKeyCodes key) {
        int code = static_cast<int>(key);
        return (key >= KEY_A && key <= KEY_Z) || (key >= KEY_Zero && key <= KEY_Nine) || key == KEY_Space ||
            (key >= KEY_NumPad0 && key <= KEY_Divide) || (code >= 0xBA && code <= 0xE2);
    }

    bool onKey(KeyboardInputData& data) {
        using Action = KeyboardInputData::Action;
        if (data.action == Action::Release) return false;
        bool repeat = data.action == Action::Repeat;
        auto key = data.key;

        if (!s_capturing.empty()) {
            if (repeat) return true;
            if (key == KEY_Backspace || key == KEY_Delete) config::setKey(s_capturing, KEY_None);
            else if (key != KEY_Escape) config::setKey(s_capturing, key);
            s_capturing.clear();
            return true;
        }

        // Typing in the search box: only the menu key does anything, and only
        // if it's not a key that types
        auto& imgui = ImGuiCocos::get();
        if (imgui.isInitialized() && imgui.isVisible() && ImGui::GetIO().WantTextInput) {
            if (repeat || isTypingKey(key) || key != config::getKey("key.menu")) return false;
            menu::toggle();
            return true;
        }
        return handleKey(key, repeat);
    }

    // imgui-cocos only passes on left clicks (as touches), so right clicks,
    // which open a hack's options, are given to ImGui here
    bool onMouse(MouseInputData& data) {
        if (data.button != MouseInputData::Button::Right) return false;
        auto& imgui = ImGuiCocos::get();
        if (!imgui.isInitialized() || !imgui.isVisible()) return false;
        auto& io = ImGui::GetIO();
        bool down = data.action == MouseInputData::Action::Press;
        io.AddMouseButtonEvent(ImGuiMouseButton_Right, down);
        return down && io.WantCaptureMouse;
    }
}

void grassy::menu::toggle() {
    setOpen(!s_open);
}

$on_mod(Loaded) {
    ImGuiCocos::get().setup([] {
        loadFonts();
        // The context is new (toggling fullscreen makes a new one), so build the style again
        s_styleScale = 0.f;
    }).draw([] {
        drawMenu();
    });
    ImGuiCocos::get().setVisible(false);
    // Before imgui-cocos's own listener (priority 0), so keybinds are seen first
    KeyboardInputEvent().listen(onKey, -100).leak();
    MouseInputEvent().listen(onMouse).leak();
}
