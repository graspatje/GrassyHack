#pragma once

#include <Geode/Geode.hpp>

#include <array>
#include <string>

// What the menu and the hacks need from each other
namespace grassy {
    namespace menu {
        void toggle();
    }

    namespace bot {
        bool isRunning();
        // Starts the bot in the current level, or stops it
        void toggle();
        // What the bot is doing right now, empty when it's off
        std::string status();
    }

    // Frozen means the level only moves one tick at a time
    namespace stepper {
        bool isFrozen();
        void setFrozen(bool frozen);
        // Return false when there's nothing to step, so the key goes to GD
        bool stepForward();
        bool stepBack();
    }

    namespace startpos {
        // Return false when there's nothing to switch, so the key goes to GD
        bool previous();
        bool next();
        void refresh();
    }

    // GD's menus, the FPS limit and vertical sync
    namespace menus {
        // How much faster the game runs right now (while a chest opens)
        float timeScale();
        // Keeps the FPS limit in line with the options, every frame
        void update();
        // GD's own vertical sync setting
        bool vsyncOn();
        void setVsync(bool enabled);
    }

    namespace cosmetic {
        // Keeps the music's pitch shift in line with the options, every frame
        void update();
    }

    namespace tps {
        // Physics steps per second, 240 unless the TPS bypass is on
        double value();
        bool changed();
    }

    namespace speedhack {
        // How fast the game runs, 1 while the speedhack is off
        float speed();
    }

    namespace noclip {
        // This attempt so far, counted while noclip is on: the share of ticks
        // not spent inside something deadly, and how many times you went in
        float accuracy();
        int deaths();
        // Kills the player, even with noclip on (auto kill)
        void kill(PlayLayer* pl);
    }

    namespace labels {
        // How see-through GrassyHack's text and buttons in the level are, as
        // a cocos opacity (255 is solid)
        GLubyte opacity();
    }

    namespace respawn {
        // Instant respawn or a custom respawn time is on
        bool changed();
    }

    namespace deaths {
        struct Summary {
            std::string levelName;
            int total = 0;
            bool platformer = false;
            // Deaths at each whole percent, 0 to 100
            std::array<int, 101> percents{};
        };

        // The level being played, nullptr outside levels
        Summary const* current();
        void clearCurrent();
        // Shows, hides or redraws the crosses after an option changed
        void refresh();
    }

    // The level being played or looked at, and changing its saved progress
    namespace level {
        // The level in the level being played or the level's info page, else nullptr
        GJGameLevel* current();
        bool completed(GJGameLevel* level);
        bool practiceCompleted(GJGameLevel* level);
        // Takes back the completion (and the best percentage)
        void uncomplete(GJGameLevel* level);
        void uncompletePractice(GJGameLevel* level);
        // Normal mode: best percentage, attempts, jumps, clicks, completion
        void resetProgress(GJGameLevel* level);
        void resetPractice(GJGameLevel* level);
        // Returns false outside levels
        bool restartFromStart();
        void testJumpscare();
        [[noreturn]] void crash();
        // Click Between Frames, another mod: nullptr when it isn't installed and on
        geode::Mod* clickBetweenFrames();
        bool clickBetweenFramesOn();
        void setClickBetweenFrames(bool enabled);
    }

    namespace safemode {
        // Called right before GD handles a death that isn't noclipped
        void beforeDeath(PlayLayer* pl);
        // Gives back the level's real test mode flag if safe mode replaced it
        void restoreTestMode(PlayLayer* pl);
    }
}
