#pragma once

#include <cstddef>
#include <climits>
#include <cstdint>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

// Finds a sequence of jump inputs that gets through a level by trial and error.
//
// A plan says, for every block of `ticksPerBlock` ticks, whether jump is held,
// plus what happens after its last block (the "tail": held or released). Every
// plan tried is an earlier plan with one block flipped:
//   - in tap modes (cube, ball, UFO...) that's a single press, and jump is
//     released again after it
//   - in hold modes (ship, wave, robot) it switches the input, and the new
//     input is kept from there on
// When an attempt dies, the blocks shortly before the death become candidates
// to flip next, and once those are used up the window moves further back, down
// to the attempt's own flip. Candidates from attempts that got furthest are
// tried first, so the search keeps pushing forward and only backs up when
// nothing near the front works. Each flip costs `flipCostTicks` of progress
// though, so an attempt that only gets a few ticks further by changing one
// more input doesn't crowd out its parent's simpler options, and so does dying
// where many attempts died before (see PlannerConfig::crowdDeaths). A plan only ever
// adds flips after its parent's flip, so every combination of inputs is
// reached exactly one way.
//
// After its last flip, every attempt plays its tail, so two attempts with the
// same tail that reach the exact same player state at the same tick will play
// out the same from there. The caller reports the state now and then, and the
// later attempt is dropped as a duplicate. That's what keeps the search from
// retrying every tiny variation of one failed jump.
//
// The planner never touches the game. The caller restores snapshots, feeds
// inputs from held() and reports how each attempt ended.
namespace gdbot {

struct PlannerConfig {
    int ticksPerBlock = 2;
    // How far back from a death to try flipping inputs first
    int windowTicks = 180;
    // Minimum ticks between two snapshots in one attempt
    int snapshotInterval = 60;
    // The same, before the attempt's own flip. That stretch replays its
    // parent's path, which its siblings share, so snapshots there get used
    // a lot more than ones past the flip, which only its own children can use.
    int replaySnapshotInterval = 60;
    size_t maxSnapshots = 400;
    // How much further an extra flip has to get to be worth exploring before
    // the remaining simpler options
    int flipCostTicks = 24;
    // Flips normally only go on every `flipSpacing`-th block. The blocks in
    // between are only tried near the front, once the search has been stuck
    // for `stuckAttempts` attempts: some jumps only work on one exact tick,
    // but trying every tick everywhere makes the search far too wide.
    int flipSpacing = 1;
    int stuckAttempts = 4000;
    // Attempts that die in the same place as many before them are explored
    // less: every doubling of the deaths there past this many costs as much
    // as a flip. Otherwise a route that can't work but gets a bit further
    // than the real one soaks up every attempt, like going over the saw at 3%
    // of Swing Swing when the way through is under it. Counting only deaths
    // near the furthest one did worse in GD: the search then kept dying in a
    // few places just behind it without that ever counting against them.
    int crowdDeaths = 128;
};

class Planner {
public:
    void reset(PlannerConfig const& config);

    // Picks the next plan to try. Returns false once there is nothing left to try.
    bool beginAttempt();
    // The current attempt is being played again from `tick`, e.g. after an outside restart
    void restartAttempt(int tick) {
        m_lastSnapshotTick = tick;
        m_lastStateCheck = -1;
    }
    // Snapshot to restore before the attempt, or -1 to start from the beginning
    int startSnapshot() const { return m_startSnapshot; }
    int startTick() const { return m_startTick; }
    void setReplaySnapshotInterval(int ticks) { m_config.replaySnapshotInterval = ticks; }
    int replaySnapshotInterval() const { return m_config.replaySnapshotInterval; }
    // Forgets a snapshot that doesn't restore properly, and stops taking new
    // ones close to it. Returns the tick it was at, or -1 if it's unknown.
    int dropBadSnapshot(int id);
    // Picks the snapshot to start the current attempt from again, e.g. after
    // dropping the one it was going to use
    void chooseStart();

    // Whether jump is held during `tick` in the current plan
    bool held(int tick) const;

    // Tells the planner whether the player is in a hold mode (ship, wave,
    // robot, or a dash orb) at `tick`, which decides how flips there behave,
    // and whether pressing jump there would do nothing (a cube, ball or
    // spider in the air with no orb around)
    void noteMode(int tick, bool holdMode, bool pressDoesNothing);

    // Asked between ticks, after `tick` ticks have run. Snapshots are normally
    // only taken with jump released, since restoring has to recreate the button
    // state; `holdOk` allows it while held, for modes where that's safe.
    bool wantSnapshot(int tick, bool holdOk);
    // Registers a snapshot the caller saved at `tick` and returns its id.
    // Ids of snapshots dropped to stay under the limit are added to `evicted`.
    int addSnapshot(int tick, std::vector<int>& evicted);

    // Asked between ticks, after `tick` ticks have run: should the caller pass
    // the player's state to isDuplicate() here?
    bool wantStateCheck(int tick) const;
    // Records the player's exact state at `tick`. Returns true if an earlier
    // attempt with the same tail already got there after its last flip; then
    // end the attempt with reportDuplicate().
    bool isDuplicate(int tick, uint64_t state);
    // Whether any attempt reported this exact state at `tick` (only ticks
    // where wantStateCheck() said yes). Used to find where a straight run
    // stops matching what the search saw.
    bool wasSeen(int tick, uint64_t state) const;
    static bool isStateCheckTick(int tick);
    // Ids of the snapshots taken at `tick` on the current plan's path
    std::vector<int> snapshotsOnPath(int tick) const;
    // Hash of the current plan's inputs before `tick`
    uint64_t prefixHash(int tick) const;

    // `place` says where the player died, e.g. the level block it was in,
    // see PlannerConfig::crowdDeaths
    void reportDeath(int tick, uint64_t place);
    void reportDuplicate();

    // The current plan, one entry per block, and what happens after it
    std::vector<uint8_t> const& plan() const { return m_plan; }
    bool tail() const { return m_tail; }
    int ticksPerBlock() const { return m_config.ticksPerBlock; }
    int flipSpacing() const { return m_config.flipSpacing; }
    // The current attempt's flipped block (-1 for the first attempt), and
    // whether it was flipped as a hold-mode switch
    int flippedBlock() const { return m_node >= 0 ? m_nodes[m_node].block : -1; }
    bool flipInHoldMode() const { return m_node >= 0 && m_nodes[m_node].holdMode; }
    int bestTick() const { return m_bestTick; }
    // For debugging a stall: the ticks the current plan flips after the
    // parent of the attempt that got furthest, if it descends from that
    // parent through at most `depth` flips, else nothing
    std::vector<int> flipsBelowBestParent(int depth) const;
    size_t pendingCount() const { return m_candidates.size(); }
    size_t snapshotCount() const { return m_snapshotCount; }

private:
    // A plan that has been tried: its parent plan and the block that was flipped
    struct Node {
        int parent;
        // -1 for the very first plan
        int block;
        // Whether the flip happened in a hold mode, see the comment at the top
        bool holdMode;
        // Flips in the plan, 0 for the first attempt
        int depth;
        int death = 0;
        // Index into m_deathsAt of where it died, -1 if it didn't
        int place = -1;
        // Lowest block whose flip has been queued so far
        int lowestQueued = 0;
        // Queued flips that haven't been tried yet
        int pending = 0;
        // Whether the blocks between the normal flips have been queued
        bool finePassed = false;
        // Last block its children may flip. A duplicate's later flips would
        // only repeat those of the attempt it matched, see reportDuplicate().
        int lastFlip = INT_MAX;
        // First block this attempt played itself, and the blocks [from, to)
        // where it was in a hold mode. Its children flip by these, not by
        // what other attempts saw there: whether the player touches an orb
        // depends on the route.
        int playedFrom = 0;
        std::vector<std::pair<int, int>> holdSpans;
        // Blocks where it had jump let go and a press would have done nothing
        std::vector<std::pair<int, int>> idleSpans;
    };
    struct Candidate {
        int parent;
        int block;
        // How far the parent got, minus the cost of its flips and this one
        // and of the crowd where it died
        int priority;
        // Order inside one death's window, lowest first: spread out over the
        // window, with the last few ticks before the death tried last
        int order;
        bool holdMode = false;
        // The priority without the crowd, which keeps growing after queueing
        int base = 0;
    };
    struct CandidateOrder {
        bool operator()(Candidate const& a, Candidate const& b) const;
    };
    struct Snapshot {
        int id;
        uint64_t prefix;
        uint64_t lastUsed;
    };

    void buildPlan(int node, std::vector<uint8_t>& plan, bool& tail) const;
    void setPlan(std::vector<uint8_t> plan, bool tail);
    bool holdModeAt(int block) const;
    bool holdModeIn(Node const& node, int block) const;
    // Whether a tap at `block` on top of `node`'s plan can't change anything,
    // going by what its attempt saw there. Most such taps in the air would
    // otherwise each cost a restore before turning out to be duplicates.
    bool pressDoesNothing(Node const& node, int block) const;
    void evictOldest(std::vector<int>& evicted);
    bool nearBadSnapshot(int tick) const;
    // Queues flips of blocks [from, to] on top of `node`'s plan: the normal
    // ones, or with `fine` the ones between them. Returns how many.
    int queueFlips(int node, int from, int to, bool fine);
    // Queues the flips in a node's window before where it died
    void queueWindow(int node);
    // Moves a node's window further back once everything in it has been tried
    void widenWindow(int node);
    bool nearFront(Node const& node) const;
    // Priority lost to the deaths at a place, see PlannerConfig::crowdDeaths
    int crowdPenalty(int place) const;
    void pushCandidate(Candidate const& candidate);
    // Queues the blocks between the normal flips in the window of a node near the front
    void queueFineFlips(int node);

    PlannerConfig m_config;
    std::vector<Node> m_nodes;
    // A heap ordered by CandidateOrder
    std::vector<Candidate> m_candidates;
    std::unordered_set<uint64_t> m_triedPlans;
    // (tick, tail, player state) reached while playing a tail
    // and the node that got there first
    std::unordered_map<uint64_t, int> m_seenStates;
    std::map<int, std::vector<Snapshot>> m_snapshots;
    size_t m_snapshotCount = 0;
    int m_nextSnapshotId = 0;
    uint64_t m_useClock = 0;
    int m_bestTick = 0;
    int m_bestNode = -1;
    int m_attemptsSinceBest = 0;
    // Stuck: nodes near the front also get the flips between the normal ones
    bool m_fineMode = false;
    // Ticks around snapshots that didn't restore properly, where no more are taken
    std::vector<std::pair<int, int>> m_badSnapshotRanges;
    // Last mode seen at each block, which is where the portals are
    std::vector<uint8_t> m_holdModes;
    // Deaths so far at each place reported to reportDeath()
    std::unordered_map<uint64_t, int> m_placeIndex;
    std::vector<int> m_deathsAt;

    // The attempt in progress
    int m_node = -1;
    std::vector<uint8_t> m_plan;
    bool m_tail = false;
    // m_prefix[i] = hash of the inputs of blocks [0, i). Past the plan it's
    // extended on demand when the tail is held.
    mutable std::vector<uint64_t> m_prefix;
    int m_startSnapshot = -1;
    int m_startTick = 0;
    int m_lastSnapshotTick = 0;
    // From here on the attempt only plays its tail
    int m_tailFrom = 0;
    // Where the attempt was in a hold mode so far, see Node::holdSpans
    int m_playedFrom = 0;
    std::vector<std::pair<int, int>> m_holdSpans;
    std::vector<std::pair<int, int>> m_idleSpans;
    // GD can run updates without physics, which would ask about the same tick
    // twice, and the second check would match the first
    int m_lastStateCheck = -1;
    // What the last isDuplicate() match was a duplicate of, and when
    int m_duplicateOf = -1;
    int m_duplicateTick = 0;
};

}
