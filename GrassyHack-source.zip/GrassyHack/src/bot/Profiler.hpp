#pragma once

#include <string>

// A small sampling profiler for finding what makes GD slow. A background
// thread pauses the game's main thread about once a millisecond while
// sampling is active, records which functions are on its call stack, and
// lets it continue. Functions show up as module+offset; offsets in
// GeometryDash.exe match the "win" addresses in Geode's bindings.
namespace gdbot::profiler {

// Call on the game's main thread
void start();
void stop();
// What the main thread is doing, so samples of different work are kept
// apart: 0 = nothing worth sampling, 1 and up = whatever the caller decides
void setChannel(int channel);
// The functions seen most often in one channel since its last report, then
// starts that channel over
std::string report(int channel, int top);
// Memory the game is using, in MB
int memoryMB();

}
