#include "Profiler.hpp"

#include <Windows.h>
#include <psapi.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <thread>
#include <unordered_map>
#include <vector>

namespace gdbot::profiler {

namespace {
    constexpr int kMaxFrames = 48;

    constexpr int kChannels = 3;
    // Which kind of work is being sampled right now, 0 for none
    std::atomic<int> s_channel = 0;
    std::atomic<bool> s_running = false;
    HANDLE s_mainThread = nullptr;

    std::mutex s_mutex;
    // Per channel: function start address -> samples where it was anywhere on the stack
    std::unordered_map<uint64_t, int> s_inclusive[kChannels];
    // Per channel: function start address -> samples where it was the one running
    std::unordered_map<uint64_t, int> s_self[kChannels];
    int s_samples[kChannels] = {};

    // Walks the paused thread's stack. The thread may be paused while holding
    // the heap lock, so this must not allocate.
    int walkStack(CONTEXT context, uint64_t* frames) {
        int count = 0;
        __try {
            while (count < kMaxFrames && context.Rip) {
                frames[count++] = context.Rip;
                DWORD64 imageBase = 0;
                auto function = RtlLookupFunctionEntry(context.Rip, &imageBase, nullptr);
                if (!function) {
                    // Only the innermost function can be a leaf without unwind info
                    if (count > 1) break;
                    context.Rip = *reinterpret_cast<DWORD64*>(context.Rsp);
                    context.Rsp += 8;
                    continue;
                }
                PVOID handlerData = nullptr;
                DWORD64 establisherFrame = 0;
                RtlVirtualUnwind(UNW_FLAG_NHANDLER, imageBase, context.Rip, function, &context,
                    &handlerData, &establisherFrame, nullptr);
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {}
        return count;
    }

    uint64_t functionStart(uint64_t address) {
        DWORD64 imageBase = 0;
        auto function = RtlLookupFunctionEntry(address, &imageBase, nullptr);
        return function ? imageBase + function->BeginAddress : address;
    }

    void record(int channel, uint64_t const* frames, int count) {
        std::lock_guard lock(s_mutex);
        s_samples[channel]++;
        std::array<uint64_t, kMaxFrames> seen;
        int seenCount = 0;
        for (int i = 0; i < count; i++) {
            uint64_t start = functionStart(frames[i]);
            if (i == 0) s_self[channel][start]++;
            if (std::find(seen.begin(), seen.begin() + seenCount, start) != seen.begin() + seenCount) continue;
            seen[seenCount++] = start;
            s_inclusive[channel][start]++;
        }
    }

    void sampleLoop() {
        std::array<uint64_t, kMaxFrames> frames;
        while (s_running) {
            int channel = s_channel;
            if (channel > 0 && SuspendThread(s_mainThread) != static_cast<DWORD>(-1)) {
                // The thread may have moved on to other work before it paused
                channel = s_channel;
                CONTEXT context{};
                context.ContextFlags = CONTEXT_FULL;
                int count = channel > 0 && GetThreadContext(s_mainThread, &context) ? walkStack(context, frames.data()) : 0;
                ResumeThread(s_mainThread);
                if (count > 0) record(channel, frames.data(), count);
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
    }

    // Mods' hooks sit between GD's functions on the stack and mostly just
    // pass the call on, so the "on the stack" list leaves them out
    bool inMod(uint64_t address) {
        HMODULE module = nullptr;
        if (!GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                reinterpret_cast<LPCSTR>(address), &module) || !module) {
            // Hook trampolines live in memory no module owns
            return true;
        }
        char path[MAX_PATH] = {};
        GetModuleFileNameA(module, path, MAX_PATH);
        return std::strstr(path, "geode\\unzipped") != nullptr;
    }

    std::string describe(uint64_t address) {
        HMODULE module = nullptr;
        char text[MAX_PATH + 32];
        if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                reinterpret_cast<LPCSTR>(address), &module) && module) {
            char path[MAX_PATH] = {};
            GetModuleFileNameA(module, path, MAX_PATH);
            char const* name = path;
            for (char const* c = path; *c; c++) {
                if (*c == '\\' || *c == '/') name = c + 1;
            }
            std::snprintf(text, sizeof text, "%s+0x%llx", name,
                static_cast<unsigned long long>(address - reinterpret_cast<uint64_t>(module)));
        }
        else {
            std::snprintf(text, sizeof text, "0x%llx", static_cast<unsigned long long>(address));
        }
        return text;
    }
}

void start() {
    if (s_running) return;
    if (!DuplicateHandle(GetCurrentProcess(), GetCurrentThread(), GetCurrentProcess(), &s_mainThread,
            THREAD_SUSPEND_RESUME | THREAD_GET_CONTEXT | THREAD_QUERY_INFORMATION, FALSE, 0)) {
        return;
    }
    s_running = true;
    // Detached, so the game can close without waiting for it
    std::thread(sampleLoop).detach();
}

void stop() {
    s_channel = 0;
    s_running = false;
}

void setChannel(int channel) {
    s_channel = channel > 0 && channel < kChannels ? channel : 0;
}

int memoryMB() {
    PROCESS_MEMORY_COUNTERS_EX counters{};
    if (!K32GetProcessMemoryInfo(GetCurrentProcess(), reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&counters), sizeof counters)) {
        return 0;
    }
    return static_cast<int>(counters.PrivateUsage / (1024 * 1024));
}

std::string report(int channel, int top) {
    std::lock_guard lock(s_mutex);
    int samples = s_samples[channel];
    if (samples == 0) return "no samples";

    auto byCount = [](std::unordered_map<uint64_t, int> const& counts) {
        std::vector<std::pair<uint64_t, int>> sorted(counts.begin(), counts.end());
        std::sort(sorted.begin(), sorted.end(), [](auto const& a, auto const& b) { return a.second > b.second; });
        return sorted;
    };
    auto line = [samples](uint64_t address, int count) {
        char numbers[32];
        std::snprintf(numbers, sizeof numbers, " %.0f%%", count * 100.0 / samples);
        return "\n    " + describe(address) + numbers;
    };

    std::string out = std::to_string(samples) + " samples. On the stack, not counting mods' hooks:";
    int shown = 0;
    for (auto [address, count] : byCount(s_inclusive[channel])) {
        if (shown == top) break;
        if (inMod(address)) continue;
        out += line(address, count);
        shown++;
    }
    out += "\n  Running itself:";
    shown = 0;
    for (auto [address, count] : byCount(s_self[channel])) {
        if (shown++ == top / 2) break;
        out += line(address, count);
    }

    s_inclusive[channel].clear();
    s_self[channel].clear();
    s_samples[channel] = 0;
    return out;
}

}
