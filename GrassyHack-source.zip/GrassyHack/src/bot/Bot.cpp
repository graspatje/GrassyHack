#include <Geode/Geode.hpp>
#include <Geode/modify/FMODAudioEngine.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/GJEffectManager.hpp>
#include <Geode/modify/PlayerObject.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/ui/Notification.hpp>

#include "../Config.hpp"
#include "../Hacks.hpp"
#include "../macro/Player.hpp"
#include "GameFields.hpp"
#include "Planner.hpp"
#include "Profiler.hpp"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cmath>
#include <cstring>
#include <deque>
#include <filesystem>
#include <fstream>
#include <map>
#include <set>
#include <type_traits>
#include <unordered_map>

using namespace geode::prelude;

// Plays levels in practice mode by trial and error. Each attempt restores a
// snapshot (a practice checkpoint the bot made earlier), presses jump the way
// the planner says, and reports back when the player dies. Once a plan
// reaches the end, it's played again from 0% with no snapshots, to make sure
// it works in one go.
//
// While the bot runs, every GJBaseGameLayer::update call is exactly one
// physics tick (1/240 s), so a plan plays out the same at any frame rate.

// resetRecord checks this byte, see pauseRecording
static_assert(offsetof(PlayLayer, m_recordInputs) == 0x32A8);

namespace {
    constexpr float kTickSeconds = 1.f / 240.f;
    constexpr int kJumpButton = 1;
    // Longest and shortest gap between two snapshots on one attempt's path
    constexpr int kSnapshotInterval = 60;
    constexpr int kMinSnapshotInterval = 8;
    // Ticks between updates of what's drawn while searching, see BotPlayLayer::updateVisibility
    constexpr int kVisibilityInterval = 4;
    // Profiler channels
    constexpr int kProfileRestores = 1;
    constexpr int kProfileTicks = 2;
    // Most time the bot spends per frame, so the game stays responsive even
    // when every attempt is short and restoring dominates
    constexpr auto kFrameBudget = std::chrono::milliseconds(12);
    // Caps the warnings about snapshots not restoring exactly
    constexpr int kMaxRestoreWarnings = 20;
    // After this many snapshots that didn't restore properly, restoring itself
    // is what's off, and dropping them would only keep the bot from progressing
    constexpr int kMaxBadSnapshots = 200;

    enum class Mode { Off, Searching, Verifying };

    // Player values GD's checkpoints don't bring back the way a straight run has
    // them: the y speed comes back rounded, the player's own clock and the
    // "last jumped / landed / flipped" times aren't saved, a press buffered
    // just before landing is lost, and so on. That made runs found with
    // restores fail when played straight through, so these are saved with
    // each snapshot and put back after it. All plain values, no pointers.
#define GDBOT_PLAYER_VALUES(X) \
    X(m_yVelocity) X(m_fallSpeed) X(m_yVelocityRelated) X(m_groundYVelocity) X(m_yVelocityBeforeSlope) \
    X(m_currentSlopeYVelocity) X(m_gravity) X(m_platformerXVelocity) X(m_slopeVelocity) X(m_rotateSpeed) \
    X(m_gravityMod) X(m_xVelocityRelated) X(m_xVelocityRelated2) X(m_yVelocityRelated3) \
    X(m_platformerVelocityRelated) X(m_accelerationOrSpeed) X(m_maybeReverseAcceleration) X(m_fallStartY) \
    X(m_jumpBuffered) X(m_stateJumpBuffered) X(m_wasJumpBuffered) X(m_wasRobotJump) X(m_stateRingJump) \
    X(m_stateRingJump2) X(m_ringJumpRelated) X(m_isAccelerating) X(m_maybeIsFalling) X(m_maybeIsBoosted) \
    X(m_decreaseBoostSlide) X(m_hasEverJumped) X(m_fixRobotJump) X(m_slopeFlipGravityRelated) \
    X(m_stateBoostX) X(m_stateBoostY) X(m_stateNoAutoJump) X(m_stateDartSlide) X(m_stateFlipGravity) \
    X(m_jumpRelatedAC2) X(m_totalTime) X(m_lastJumpTime) X(m_lastFlipTime) X(m_lastSpiderFlipTime) \
    X(m_lastLandTime) X(m_gameModeChangedTime) X(m_dashStartTime) X(m_slopeStartTime) \
    X(m_changedDirectionsTime) X(m_slopeEndTime) X(m_maybeSlidingStartTime) X(m_maybeSlidingTime) \
    X(m_lastMovedTime)

    struct PlayerExtras {
#define GDBOT_DECLARE(name) std::remove_cvref_t<decltype(PlayerObject::name)> name;
        GDBOT_PLAYER_VALUES(GDBOT_DECLARE)
#undef GDBOT_DECLARE
        float rotation;

        static PlayerExtras from(PlayerObject* player) {
            PlayerExtras extras;
#define GDBOT_COPY(name) extras.name = player->name;
            GDBOT_PLAYER_VALUES(GDBOT_COPY)
#undef GDBOT_COPY
            extras.rotation = player->getRotation();
            return extras;
        }

        void applyTo(PlayerObject* player) const {
#define GDBOT_APPLY(name) player->name = name;
            GDBOT_PLAYER_VALUES(GDBOT_APPLY)
#undef GDBOT_APPLY
            player->setRotation(rotation);
        }

        // Names of the values that differ
        std::vector<char const*> differences(PlayerExtras const& other) const {
            std::vector<char const*> out;
#define GDBOT_COMPARE(name) if (std::memcmp(&name, &other.name, sizeof(name)) != 0) out.push_back(#name);
            GDBOT_PLAYER_VALUES(GDBOT_COMPARE)
#undef GDBOT_COMPARE
            if (rotation != other.rotation) out.push_back("rotation");
            return out;
        }
    };

    // How often each value had to be put back since the last report
    std::map<std::string, int> s_fixedValues;

    // What pressing or releasing jump does besides holding it. A press uses
    // any orb the player is touching (in the ship, that's the only way an orb
    // gets used) and makes orbs usable again; a release ends that. When a
    // restore has to put back a held jump, the straight run it stands in for
    // didn't press there, so all of this is kept as the snapshot had it.
#define GDBOT_PRESS_VALUES(X) \
    X(m_jumpBuffered) X(m_stateRingJump) X(m_stateJumpBuffered) X(m_stateRingJump2) X(m_touchedRing) \
    X(m_touchedCustomRing) X(m_touchedGravityPortal) X(m_maybeTouchedBreakableBlock) X(m_touchedPad) \
    X(m_padRingRelated) X(m_ringRelatedSet)

    struct PressState {
#define GDBOT_DECLARE(name) std::remove_cvref_t<decltype(PlayerObject::name)> name;
        GDBOT_PRESS_VALUES(GDBOT_DECLARE)
#undef GDBOT_DECLARE

        static PressState from(PlayerObject* player) {
            PressState state;
#define GDBOT_COPY(name) state.name = player->name;
            GDBOT_PRESS_VALUES(GDBOT_COPY)
#undef GDBOT_COPY
            return state;
        }

        void applyTo(PlayerObject* player) const {
#define GDBOT_APPLY(name) player->name = name;
            GDBOT_PRESS_VALUES(GDBOT_APPLY)
#undef GDBOT_APPLY
        }
    };

    struct Snapshot {
        Ref<CheckpointObject> checkpoint;
        unsigned int progress;
        CCPoint position;
        double yVelocity;
        PlayerExtras player1;
        PlayerExtras player2;
        // playerState() without the button, which is set after restoring
        uint64_t state;
        // Readable copy of what goes into the state, to show what differs
        std::string stateText;
        // Raw copies of the player and the level object, to find every value a
        // restore doesn't bring back
        std::vector<uint8_t> playerBytes;
        std::vector<uint8_t> layerBytes;
    };

    // How often each GD value came back different after a restore, since the last report
    std::map<std::string, int> s_restoreDiffs;
    int s_diffedRestores = 0;

    std::vector<uint8_t> copyBytes(void const* object, size_t size) {
        auto bytes = static_cast<uint8_t const*>(object);
        return std::vector<uint8_t>(bytes, bytes + size);
    }

    // More values restores get wrong, found by comparing everything before and
    // after: which portal the player last went through (so a portal can fire
    // twice), where it last touched ground or a wall, and GD's own tick
    // counter and random seed
    constexpr char const* kPlayerValuesToPutBack[] = {
        "m_lastActivatedPortal", "m_lastPortalPos", "m_lastGroundedPos", "m_lastCollisionBottom",
        "m_lastCollisionTop", "m_lastCollisionLeft", "m_lastCollisionRight", "m_collidedBottomMaxY",
        "m_collidedTopMinY", "m_collidedLeftMaxX", "m_collidedRightMinX", "m_unk50C", "m_unk510", "m_unkA29",
        "m_rotationSpeed", "m_isRotating", "m_isBallRotating", "m_isBallRotating2",
    };
    constexpr char const* kLevelValuesToPutBack[] = { "m_tickIndex", "m_randomSeed" };

    template <size_t N, size_t M>
    void putBack(std::vector<uint8_t> const& saved, void* object, gdbot::GameField const (&fields)[N],
            char const* const (&names)[M]) {
        for (auto name : names) {
            for (auto& field : fields) {
                if (std::strcmp(field.name, name) != 0 || field.offset + field.size > saved.size()) continue;
                std::memcpy(static_cast<uint8_t*>(object) + field.offset, saved.data() + field.offset, field.size);
            }
        }
    }

    // Adds the names of the values in `object` that differ from the saved copy
    // of it to `out`. `base` is where the fields start, for a struct inside it.
    template <size_t N>
    void diffFields(char const* prefix, std::vector<uint8_t> const& saved, void const* object,
            gdbot::GameField const (&fields)[N], std::vector<std::string>& out, size_t base = 0) {
        auto now = static_cast<uint8_t const*>(object);
        for (auto& field : fields) {
            size_t offset = base + field.offset;
            if (offset + field.size > saved.size()) continue;
            if (std::memcmp(saved.data() + offset, now + offset, field.size) != 0) {
                out.push_back(std::string(prefix) + field.name);
            }
        }
    }

    // Every GD value that differs from what a snapshot saved
    std::vector<std::string> diffWithSnapshot(PlayLayer* pl, Snapshot const& snapshot) {
        std::vector<std::string> out;
        diffFields("player.", snapshot.playerBytes, pl->m_player1, gdbot::kPlayerObjectFields, out);
        diffFields("level.", snapshot.layerBytes, pl, gdbot::kPlayLayerFields, out);
        size_t gameState = reinterpret_cast<uint8_t*>(&pl->m_gameState) - reinterpret_cast<uint8_t*>(pl);
        diffFields("level.m_gameState.", snapshot.layerBytes, pl, gdbot::kGJGameStateFields, out, gameState);
        return out;
    }

    std::string describeState(PlayLayer* pl) {
        auto player = pl->m_player1;
        return fmt::format("pos ({}, {}) y-speed {} size {} speed {} ship {} ufo {} ball {} wave {} robot {} spider {} "
            "swing {} upside down {} on ground {} dashing {} jump buffered {} buffer state {} rings {} dual {}",
            player->m_position.x, player->m_position.y, player->m_yVelocity, player->m_vehicleSize, player->m_playerSpeed,
            player->m_isShip, player->m_isBird, player->m_isBall, player->m_isDart, player->m_isRobot, player->m_isSpider,
            player->m_isSwing, player->m_isUpsideDown, player->m_isOnGround, player->m_isDashing, player->m_jumpBuffered,
            player->m_stateJumpBuffered, player->m_touchingRings ? player->m_touchingRings->count() : 0,
            pl->m_gameState.m_isDualMode);
    }

    // The hazards, solid blocks and slopes around the player, logged when the
    // search gets stuck, to see what it has to get through
    std::string describeObstacles(PlayLayer* pl) {
        float x = pl->m_player1->m_position.x;
        std::string out;
        for (auto object : CCArrayExt<GameObject*>(pl->m_objects)) {
            auto type = object->m_objectType;
            char const* kind = type == GameObjectType::Hazard ? "hazard" : type == GameObjectType::Solid ? "solid"
                : type == GameObjectType::Slope ? "slope" : nullptr;
            if (!kind) continue;
            auto pos = object->getPosition();
            if (pos.x < x - 120 || pos.x > x + 240) continue;
            auto rect = object->getObjectRect();
            out += fmt::format("\n    {} {} at ({:.1f}, {:.1f}), box ({:.1f}, {:.1f})-({:.1f}, {:.1f}), radius {:.1f}, rotation {:.0f}",
                kind, object->m_objectID, pos.x, pos.y,
                rect.getMinX(), rect.getMinY(), rect.getMaxX(), rect.getMaxY(), object->m_objectRadius, object->getRotation());
        }
        return out;
    }

    gdbot::Planner s_planner;
    Mode s_mode = Mode::Off;
    // Ticks since the level started
    int s_tick = 0;
    bool s_inBotTick = false;
    int s_commandsThisTick = 0;
    bool s_inBotReset = false;
    bool s_botPressing = false;
    bool s_needAttempt = false;
    // Something else restarted the level, so the current attempt has to be replayed
    bool s_needRetry = false;
    bool s_died = false;
    bool s_levelEnded = false;
    bool s_held = false;
    bool s_checkHeldAfterRestore = false;
    // Whether jump should already be held when play continues after a restore
    bool s_heldGoingIn = false;
    // The bot is pressing or releasing jump only to put back the button
    // state a snapshot had, see PressState
    bool s_restoringHold = false;
    double s_tickBudget = 0.0;
    std::unordered_map<int, Snapshot> s_snapshots;
    // With the "fingerprints" debug switch: every snapshot ever taken (without
    // its checkpoint) by tick, even ones dropped since, to check the full run against
    struct Fingerprint {
        uint64_t prefix;
        int id;
        Snapshot snapshot;
    };
    std::map<int, std::vector<Fingerprint>> s_fingerprints;
    int s_restoredSnapshot = -1;
    // GD keeps pointing at the last checkpoint it loaded, so keep that one alive
    Ref<CheckpointObject> s_lastRestored;
    std::vector<uint8_t> s_solution;
    bool s_solutionTail = false;
    int s_solutionTicksPerBlock = 1;
    int s_attempts = 0;
    // Where the current attempt's own input starts, and how many ticks
    // attempts played from there, for choosing the snapshot gap
    int s_attemptFlipTick = 0;
    long long s_ticksPastFlip = 0;
    int s_attemptsMeasured = 0;
    int s_attemptsSinceBest = 0;
    int s_duplicates = 0;
    // What the last death hit, for the log
    std::string s_killer;
    // Where the player that died was
    CCPoint s_deathPosition;
    // Deaths per level block since the last progress report
    std::map<std::pair<int, int>, int> s_recentDeaths;
    // Where the player went in the current attempt, and in the one that got
    // furthest, logged when the search gets stuck
    struct PathPoint {
        int tick;
        float x, y;
        bool onGround, upsideDown, held;
    };
    std::vector<PathPoint> s_path;
    std::vector<PathPoint> s_bestPath;
    // The block a player is running into right now. GD doesn't pass it on
    // when that kills the player.
    GameObject* s_collidingWith = nullptr;
    int s_frontierLines = 0;
    std::vector<std::string> s_frontDeaths;
    bool s_loggedObstacles = false;
    // Off while replaying an attempt, which would otherwise match its own earlier states
    bool s_checkStates = true;
    int s_bestTick = 0;
    float s_bestPercent = 0.f;
    bool s_warnedTickCount = false;
    int s_restoreWarnings = 0;
    int s_badSnapshots = 0;
    int s_updatesWithoutPhysics = 0;
    // Whether the full run has already been logged as drifting from the search
    bool s_reportedDrift = false;
    // The full run compared with the snapshots the search took on its path,
    // the last few kept to log if it fails. Values that already differed at
    // the first one (timers and such) are left out of the rest.
    std::deque<std::string> s_comparisons;
    std::set<std::string> s_alwaysDifferent;
    bool s_comparedOnce = false;
    bool s_reportedSnapshotDrift = false;
    // Developer switches, one word each in debug.txt in the mod's save folder
    std::set<std::string> s_debugFlags;
    // How the last run ended, for the menu
    std::string s_lastMessage;

    // How fast the game is really running compared to normal play
    using Clock = std::chrono::steady_clock;
    long long s_ticksRun = 0;
    long long s_speedSampleTicks = 0;
    Clock::time_point s_speedSampleTime;
    Clock::time_point s_lastSpeedLog;
    double s_measuredSpeed = 0.0;
    // Attempts per second, which is what the speed-ups actually buy: with
    // less replaying per attempt, game time can run slower while more gets tried
    double s_attemptRate = 0.0;
    int s_speedSampleAttempts = 0;

    // Where the time goes, logged with the speed
    struct Timing {
        int count = 0;
        double seconds = 0.0;

        void add(Clock::time_point start) {
            count++;
            seconds += std::chrono::duration<double>(Clock::now() - start).count();
        }
        std::string summary() const {
            return count ? fmt::format("{} x {:.2f} ms", count, seconds * 1000.0 / count) : "none";
        }
    };
    Timing s_restoreTiming;
    Timing s_holdRestoreTiming;
    Timing s_snapshotTiming;
    Timing s_frameTiming;
    Timing s_tickTiming;
    // Running averages for choosing the snapshot gap, halved after each use
    // so they follow what the level is like around the current best
    Timing s_tickCost;
    Timing s_snapshotCost;
    // Loading a checkpoint is what makes restarts slow, these are its parts
    Timing s_loadCheckpointTiming;
    Timing s_loadAudioTiming;
    Timing s_loadEffectsTiming;
    Timing s_loadPlayerTiming;

    // Per-attempt lines while the bot is stuck, capped until the next new best
    constexpr int kMaxTraceLines = 300;
    constexpr int kStuckAttempts = 150;
    int s_traceLines = 0;

    // Restores getting this slow, or this many extra nodes, mean something is
    // piling up, and the bot stops before it drags the whole PC down
    constexpr double kMaxRestoreMs = 250.0;
    constexpr auto kMaxFrame = std::chrono::milliseconds(1000);
    constexpr int kMaxExtraNodes = 20000;
    int s_baselineNodes = 0;

    void countNodes(CCNode* node, std::unordered_map<std::string, int>& byClass, int& total) {
        total++;
        byClass[std::string(geode::cocos::getObjectName(node))]++;
        if (auto children = node->getChildren()) {
            for (unsigned i = 0; i < children->count(); i++) {
                countNodes(static_cast<CCNode*>(children->objectAtIndex(i)), byClass, total);
            }
        }
    }

    // Total nodes in the level, and a line naming the most common kinds
    int countLevelNodes(PlayLayer* pl, std::string* summary = nullptr) {
        std::unordered_map<std::string, int> byClass;
        int total = 0;
        countNodes(pl, byClass, total);
        if (summary) {
            std::vector<std::pair<std::string, int>> sorted(byClass.begin(), byClass.end());
            std::sort(sorted.begin(), sorted.end(), [](auto const& a, auto const& b) { return a.second > b.second; });
            *summary = "";
            for (size_t i = 0; i < std::min<size_t>(6, sorted.size()); i++) {
                *summary += fmt::format("{}{} {}", i ? ", " : "", sorted[i].first, sorted[i].second);
            }
        }
        return total;
    }

    void stopBot(PlayLayer* pl, std::string const& message, NotificationIcon icon);

    // Snapshots closer together mean less replaying of known ticks after each
    // restore, but taking one costs time too. With D ticks played past an
    // attempt's own input, a gap of G costs about G/2 replayed ticks plus D/G
    // snapshots per attempt, which is least at G = sqrt(2 * D * snapshot / tick).
    // On busy levels that's far fewer than the 60 ticks that suit light ones.
    int s_speedLogs = 0;

    void adjustSnapshotInterval() {
        if (s_tickCost.count < 240 || s_snapshotCost.count < 3 || s_attemptsMeasured < 20) return;
        double tick = s_tickCost.seconds / s_tickCost.count;
        double snapshot = s_snapshotCost.seconds / s_snapshotCost.count;
        double pastFlip = static_cast<double>(s_ticksPastFlip) / s_attemptsMeasured;
        for (auto timing : { &s_tickCost, &s_snapshotCost }) {
            timing->count /= 2;
            timing->seconds /= 2;
        }
        s_ticksPastFlip /= 2;
        s_attemptsMeasured /= 2;
        int spacing = std::max(1, s_planner.ticksPerBlock() * s_planner.flipSpacing());
        int gap = static_cast<int>(std::lround(std::sqrt(2.0 * pastFlip * snapshot / tick)));
        gap = std::clamp(gap, kMinSnapshotInterval, kSnapshotInterval);
        // Snapshots only go where normal flips do
        gap = (gap + spacing - 1) / spacing * spacing;
        if (gap == s_planner.replaySnapshotInterval()) return;
        log::info("Snapshots before an attempt's own input now every {} ticks (a tick takes {:.2f} ms, a snapshot {:.2f} ms, "
            "attempts play {:.0f} ticks past their input)", gap, tick * 1000.0, snapshot * 1000.0, pastFlip);
        s_planner.setReplaySnapshotInterval(gap);
    }

    void measureSpeed(PlayLayer* pl) {
        auto now = Clock::now();
        double elapsed = std::chrono::duration<double>(now - s_speedSampleTime).count();
        if (elapsed < 0.5) return;
        s_measuredSpeed = (s_ticksRun - s_speedSampleTicks) / 240.0 / elapsed;
        s_speedSampleTicks = s_ticksRun;
        s_attemptRate = (s_attempts - s_speedSampleAttempts) / elapsed;
        s_speedSampleAttempts = s_attempts;
        s_speedSampleTime = now;
        if (now - s_lastSpeedLog >= std::chrono::seconds(10)) {
            s_lastSpeedLog = now;
            std::string nodeKinds;
            int nodes = countLevelNodes(pl, &nodeKinds);
            log::info("Running at {:.1f}x normal speed ({} attempts so far). Frames {}, restores {} (in ship/wave/robot/dash {}), "
                "snapshots {} ({} kept, game using {} MB)", s_measuredSpeed, s_attempts, s_frameTiming.summary(),
                s_restoreTiming.summary(), s_holdRestoreTiming.summary(), s_snapshotTiming.summary(),
                s_planner.snapshotCount(), gdbot::profiler::memoryMB());
            log::info("Level has {} objects, {} nodes ({} at start): {}", pl->m_objects ? pl->m_objects->count() : 0,
                nodes, s_baselineNodes, nodeKinds);
            log::info("Loading checkpoints: {} in total, of which audio {}, effects {}, players {}",
                s_loadCheckpointTiming.summary(), s_loadAudioTiming.summary(), s_loadEffectsTiming.summary(),
                s_loadPlayerTiming.summary());
            for (auto timing : { &s_loadCheckpointTiming, &s_loadAudioTiming, &s_loadEffectsTiming, &s_loadPlayerTiming }) {
                *timing = {};
            }
            log::info("Ticks: {}", s_tickTiming.summary());
            s_tickTiming = {};
            // The profiles are long, so only every minute
            if (++s_speedLogs % 6 == 0) {
                log::info("Where restarts spend their time: {}", gdbot::profiler::report(kProfileRestores, 20));
                log::info("Where ticks spend their time: {}", gdbot::profiler::report(kProfileTicks, 20));
            }
            if (s_diffedRestores > 0) {
                std::vector<std::pair<std::string, int>> sorted(s_restoreDiffs.begin(), s_restoreDiffs.end());
                std::sort(sorted.begin(), sorted.end(), [](auto const& a, auto const& b) { return a.second > b.second; });
                std::string diffs;
                for (size_t i = 0; i < sorted.size(); i++) diffs += fmt::format(" {} {}", sorted[i].first, sorted[i].second);
                log::info("Out of {} restores, GD values that came back different:{}", s_diffedRestores, diffs);
                s_restoreDiffs.clear();
                s_diffedRestores = 0;
            }
            if (!s_fixedValues.empty()) {
                std::string fixed;
                for (auto& [name, count] : s_fixedValues) fixed += fmt::format(" {} {}", name, count);
                log::info("Player values restores got wrong (and the bot fixed):{}", fixed);
                s_fixedValues.clear();
            }

            if (s_mode == Mode::Searching) adjustSnapshotInterval();

            Timing restores = s_restoreTiming;
            restores.count += s_holdRestoreTiming.count;
            restores.seconds += s_holdRestoreTiming.seconds;
            s_frameTiming = {};
            s_restoreTiming = {};
            s_holdRestoreTiming = {};
            s_snapshotTiming = {};

            if (nodes > s_baselineNodes + kMaxExtraNodes) {
                stopBot(pl, "Bot stopped: things were piling up in the level and slowing the game down. Please report this, with your Geode log.",
                    NotificationIcon::Error);
            }
            else if (restores.count > 0 && restores.seconds * 1000.0 / restores.count > kMaxRestoreMs) {
                stopBot(pl, "Bot stopped: restarting got too slow and would freeze the game. Please report this, with your Geode log.",
                    NotificationIcon::Error);
            }
        }
    }

    int64_t intSetting(char const* key) {
        return grassy::config::getInt(fmt::format("bot.{}", key));
    }

    bool isHolding(PlayerObject* player) {
        if (!player) return false;
        auto it = player->m_holdingButtons.find(kJumpButton);
        return it != player->m_holdingButtons.end() && it->second;
    }

    void pressJump(PlayLayer* pl, bool down) {
        s_botPressing = true;
        pl->handleButton(down, kJumpButton, true);
        s_botPressing = false;
        s_held = down;
    }

    bool solutionHeld(int tick) {
        size_t block = tick / s_solutionTicksPerBlock;
        return block < s_solution.size() ? s_solution[block] != 0 : s_solutionTail;
    }

    bool touchingDashOrb(PlayerObject* player) {
        if (!player->m_touchingRings) return false;
        for (auto ring : CCArrayExt<CCObject*>(player->m_touchingRings)) {
            if (typeinfo_cast<DashRingObject*>(ring)) return true;
        }
        return false;
    }

    // Modes where how long jump is held matters, not just when it's pressed.
    // That includes dash orbs: the dash lasts as long as jump is held.
    bool inHoldMode(PlayLayer* pl) {
        bool dual = pl->m_gameState.m_isDualMode;
        for (auto player : { pl->m_player1, pl->m_player2 }) {
            if (player && (player->m_isShip || player->m_isDart || player->m_isRobot)) return true;
            if (!player || (player == pl->m_player2 && !dual)) continue;
            if (player->m_isDashing || touchingDashOrb(player)) return true;
        }
        return false;
    }

    // A cube, ball or spider in the air can't do anything with a press unless
    // it's still held when landing or at an orb, and letting go clears it
    bool pressDoesNothing(PlayLayer* pl) {
        bool dual = pl->m_gameState.m_isDualMode;
        for (auto player : { pl->m_player1, pl->m_player2 }) {
            if (!player || (player == pl->m_player2 && !dual)) continue;
            if (player->m_isShip || player->m_isBird || player->m_isDart || player->m_isRobot || player->m_isSwing) return false;
            if (player->m_isOnGround || player->m_isOnGround2 || player->m_isOnSlope || player->m_isDashing) return false;
            if (player->m_touchingRings && player->m_touchingRings->count() > 0) return false;
        }
        return true;
    }

    // Whether a snapshot taken while jump is held restores the same as a
    // straight run. Not for the robot: how high it jumps depends on how long
    // jump has been held, which checkpoints don't save.
    bool canSnapshotWhileHeld(PlayLayer* pl) {
        bool dual = pl->m_gameState.m_isDualMode;
        for (auto player : { pl->m_player1, pl->m_player2 }) {
            if (!player || (player == pl->m_player2 && !dual)) continue;
            if (!player->m_isShip && !player->m_isDart) return false;
        }
        return true;
    }

    // The players' exact state, so attempts that end up playing out the same
    // as an earlier one can be dropped
    uint64_t playerState(PlayLayer* pl, bool includeHolding = true) {
        uint64_t hash = 1469598103934665603ull;
        auto add = [&](uint64_t value) {
            hash = (hash ^ value) * 1099511628211ull;
        };
        auto addNumber = [&](double value) {
            uint64_t bits;
            std::memcpy(&bits, &value, sizeof bits);
            add(bits);
        };
        bool dual = pl->m_gameState.m_isDualMode;
        add(dual);
        for (auto player : { pl->m_player1, pl->m_player2 }) {
            // The second player sits hidden with leftover values outside dual mode
            if (!player || (player == pl->m_player2 && !dual)) continue;
            addNumber(player->m_position.x);
            addNumber(player->m_position.y);
            addNumber(player->m_yVelocity);
            addNumber(player->m_vehicleSize);
            addNumber(player->m_playerSpeed);
            uint64_t flags = 0;
            for (bool flag : { player->m_isShip, player->m_isBird, player->m_isBall, player->m_isDart,
                    player->m_isRobot, player->m_isSpider, player->m_isSwing, player->m_isUpsideDown,
                    player->m_isOnGround, player->m_isDashing, player->m_jumpBuffered, includeHolding && isHolding(player) }) {
                flags = flags * 2 + (flag ? 1 : 0);
            }
            add(flags);
            add(player->m_stateJumpBuffered);
            add(player->m_touchingRings ? player->m_touchingRings->count() : 0);
        }
        return hash;
    }

    std::string levelKey(PlayLayer* pl) {
        int id = pl->m_level->m_levelID.value();
        if (id > 0) return std::to_string(id);
        std::string name = "local-";
        for (char c : std::string(pl->m_level->m_levelName)) {
            name += std::isalnum(static_cast<unsigned char>(c)) ? c : '_';
        }
        return name;
    }

    void updateStatus(PlayLayer* pl) {
        if (!pl || !pl->m_uiLayer) return;

        auto label = static_cast<CCLabelBMFont*>(pl->m_uiLayer->getChildByID("status"_spr));
        bool show = s_mode != Mode::Off && grassy::config::getBool("bot.show-status");
        if (!show) {
            if (label) label->setVisible(false);
            return;
        }

        if (!label) {
            label = CCLabelBMFont::create("", "bigFont.fnt");
            label->setID("status"_spr);
            label->setAnchorPoint({ 0.f, 0.f });
            label->setScale(0.35f);
            label->setOpacity(200);
            label->setPosition({ 5.f, 20.f });
            pl->m_uiLayer->addChild(label, 1000);
        }

        std::string text;
        if (s_mode == Mode::Searching) {
            text = fmt::format("Bot | attempt {} | best {:.1f}% | {:.0f} attempts/s",
                s_attempts, s_bestPercent, s_attemptRate);
        }
        else {
            text = "Bot | playing the found run from 0%";
        }
        label->setVisible(true);
        label->setString(text.c_str());
    }

    // On online levels GD records every input so it can send the run in when
    // the level is beaten. Practice runs never are, and the record grows with
    // every snapshot (each restart walks all of it), so restarts got slower
    // the longer the bot ran. It's off while the bot runs.
    bool s_recordingPaused = false;
    bool s_savedRecordInputs = false;

    void pauseRecording(PlayLayer* pl) {
        if (s_recordingPaused) return;
        s_savedRecordInputs = pl->m_recordInputs;
        pl->m_recordInputs = false;
        s_recordingPaused = true;
    }

    void resumeRecording(PlayLayer* pl) {
        if (!s_recordingPaused) return;
        if (pl) pl->m_recordInputs = s_savedRecordInputs;
        s_recordingPaused = false;
    }

    void stopBot(PlayLayer* pl, std::string const& message, NotificationIcon icon) {
        if (pl && s_held) pressJump(pl, false);
        s_mode = Mode::Off;
        s_needAttempt = false;
        s_needRetry = false;
        s_died = false;
        s_levelEnded = false;
        s_snapshots.clear();
        s_fingerprints.clear();
        resumeRecording(pl);
        if (pl) {
            // Don't leave the bot's last snapshot behind as a practice checkpoint
            pl->m_checkpointArray->removeAllObjects();
            pl->m_currentCheckpoint = nullptr;
            updateStatus(pl);
        }
        if (!message.empty()) {
            log::info("Bot stopped: {}", message);
            Notification::create(message, icon, 4.f)->show();
            s_lastMessage = message;
        }
        grassy::startpos::refresh();
    }

    // GD's restart resets every object in the level one at a time, which on
    // big levels is most of what a restart costs (it reads several scattered
    // pieces of every object). Decoration that's in no group can't touch the
    // player and no trigger can move it, so while searching, restarts get a
    // list without it. The full run from 0% gets GD's normal reset.
    CCArray* s_leanObjects = nullptr;
    unsigned s_leanFrom = 0;
    bool s_leanReset = false;
    // The level's real object list while the lean one is swapped in
    CCArray* s_allObjects = nullptr;

    bool needsReset(GameObject* object) {
        return object->m_objectType != GameObjectType::Decoration || object->m_groupCount > 0;
    }

    void prepareLeanObjects(PlayLayer* pl) {
        if (!pl->m_objects) return;
        unsigned count = pl->m_objects->count();
        if (s_leanObjects && s_leanFrom == count) return;
        if (s_leanObjects) s_leanObjects->release();
        s_leanObjects = CCArray::createWithCapacity(count);
        s_leanObjects->retain();
        s_leanFrom = count;
        for (auto object : CCArrayExt<GameObject*>(pl->m_objects)) {
            if (needsReset(object)) s_leanObjects->addObject(object);
        }
        log::info("Restarts reset {} of the level's {} objects (the rest is decoration in no group)",
            s_leanObjects->count(), count);
    }

    void swapInLeanObjects(GJBaseGameLayer* layer) {
        if (!s_leanReset || s_allObjects || !s_leanObjects || layer != PlayLayer::get()) return;
        s_allObjects = layer->m_objects;
        layer->m_objects = s_leanObjects;
    }

    void swapOutLeanObjects(GJBaseGameLayer* layer) {
        if (!s_allObjects) return;
        layer->m_objects = s_allObjects;
        s_allObjects = nullptr;
    }

    void forgetLeanObjects() {
        if (s_leanObjects) s_leanObjects->release();
        s_leanObjects = nullptr;
        s_leanFrom = 0;
        s_leanReset = false;
    }

    void forgetEverything() {
        forgetLeanObjects();
        s_recordingPaused = false;
        s_mode = Mode::Off;
        s_needAttempt = false;
        s_needRetry = false;
        s_died = false;
        s_levelEnded = false;
        s_held = false;
        s_inBotTick = false;
        s_inBotReset = false;
        s_snapshots.clear();
        s_lastRestored = nullptr;
    }

    // Respawns at a snapshot (or the level start for -1) the way practice mode
    // respawns at a checkpoint
    // Respawns at a snapshot (or the level start for -1). Returns false if the
    // player didn't come back the way the snapshot was saved.
    bool restore(PlayLayer* pl, int snapshotId, bool pauseMusic) {
        auto checkpoints = pl->m_checkpointArray;
        checkpoints->removeAllObjects();

        Snapshot* snapshot = nullptr;
        if (snapshotId >= 0) {
            auto it = s_snapshots.find(snapshotId);
            if (it != s_snapshots.end()) snapshot = &it->second;
            else log::error("Snapshot {} is missing, restarting from the beginning", snapshotId);
        }
        if (snapshot) {
            checkpoints->addObject(snapshot->checkpoint);
        }
        else {
            pl->m_currentCheckpoint = nullptr;
        }

        auto started = Clock::now();
        s_inBotReset = true;
        s_leanReset = s_mode == Mode::Searching && grassy::config::getBool("bot.fast-restarts") &&
            !s_debugFlags.contains("no-lean");
        if (s_leanReset) prepareLeanObjects(pl);
        gdbot::profiler::setChannel(kProfileRestores);
        pl->resetLevel();
        gdbot::profiler::setChannel(0);
        swapOutLeanObjects(pl);
        s_leanReset = false;
        s_inBotReset = false;
        (inHoldMode(pl) ? s_holdRestoreTiming : s_restoreTiming).add(started);
        // Only now, GD may have still pointed at the previous one during the reset
        s_lastRestored = snapshot ? snapshot->checkpoint : nullptr;
        if (pauseMusic) FMODAudioEngine::sharedEngine()->pauseAllMusic(true);

        // The bot skips GD's end-of-level sequence, so clear what it left behind
        if (pl->m_levelEndAnimationStarted) {
            log::debug("Clearing the level end flag after a restore");
            pl->m_levelEndAnimationStarted = false;
        }

        s_held = false;
        s_checkHeldAfterRestore = true;
        s_heldGoingIn = false;
        s_restoredSnapshot = snapshot ? snapshotId : -1;

        if (!snapshot) return true;

        // Practice checkpoints don't save everything, so check the basics came back
        if (s_restoreWarnings < kMaxRestoreWarnings) {
            auto player = pl->m_player1;
            bool samePlace = player->m_position.getDistance(snapshot->position) < 0.01f;
            bool sameProgress = pl->m_gameState.m_currentProgress == snapshot->progress;
            if (!samePlace || !sameProgress) {
                s_restoreWarnings++;
                log::warn("Snapshot {} didn't restore exactly: pos ({}, {}) vs ({}, {}), progress {} vs {}",
                    snapshotId, player->m_position.x, player->m_position.y, snapshot->position.x, snapshot->position.y,
                    pl->m_gameState.m_currentProgress, snapshot->progress);
            }
        }
        for (auto name : PlayerExtras::from(pl->m_player1).differences(snapshot->player1)) {
            s_fixedValues[name]++;
        }
        snapshot->player1.applyTo(pl->m_player1);
        snapshot->player2.applyTo(pl->m_player2);
        putBack(snapshot->playerBytes, pl->m_player1, gdbot::kPlayerObjectFields, kPlayerValuesToPutBack);
        putBack(snapshot->layerBytes, pl, gdbot::kPlayLayerFields, kLevelValuesToPutBack);

        s_diffedRestores++;
        for (auto& name : diffWithSnapshot(pl, *snapshot)) s_restoreDiffs[name]++;

        if (playerState(pl, false) != snapshot->state) {
            if (s_restoreWarnings < kMaxRestoreWarnings) {
                s_restoreWarnings++;
                log::warn("Snapshot {} came back in a different state.\n    saved:    {}\n    restored: {}",
                    snapshotId, snapshot->stateText, describeState(pl));
            }
            return false;
        }
        return true;
    }

    // Restores the snapshot the current attempt starts from and returns its
    // tick. One that comes back different from how it was saved makes every
    // attempt through it play out wrong (on Bloodbath, a few at 21% once cost
    // 12,000 attempts that all died right after restoring), so it's dropped
    // and an earlier one is used instead.
    int restoreStart(PlayLayer* pl) {
        while (true) {
            int id = s_planner.startSnapshot();
            if (id < 0) {
                restore(pl, -1, true);
                return 0;
            }
            bool known = s_snapshots.contains(id);
            if (known && restore(pl, id, true)) return s_planner.startTick();
            if (known && s_badSnapshots >= kMaxBadSnapshots) {
                if (s_badSnapshots++ == kMaxBadSnapshots) {
                    log::warn("{} snapshots didn't restore properly, so the bot keeps using them from now on", kMaxBadSnapshots);
                }
                return s_planner.startTick();
            }
            int tick = s_planner.dropBadSnapshot(id);
            s_snapshots.erase(id);
            if (known && s_badSnapshots++ < kMaxRestoreWarnings) {
                log::info("Dropped snapshot {} at tick {}: it doesn't restore properly, so no new ones are taken near it", id, tick);
            }
            s_planner.chooseStart();
        }
    }

    void takeSnapshot(PlayLayer* pl) {
        auto started = Clock::now();
        Ref<CheckpointObject> checkpoint = pl->createCheckpoint();
        s_snapshotTiming.add(started);
        s_snapshotCost.add(started);
        if (!checkpoint) {
            log::warn("Couldn't create a snapshot at tick {}", s_tick);
            return;
        }
        std::vector<int> evicted;
        int id = s_planner.addSnapshot(s_tick, evicted);
        s_snapshots[id] = {
            checkpoint, pl->m_gameState.m_currentProgress, pl->m_player1->m_position, pl->m_player1->m_yVelocity,
            PlayerExtras::from(pl->m_player1), PlayerExtras::from(pl->m_player2),
            playerState(pl, false), describeState(pl),
            copyBytes(pl->m_player1, sizeof(PlayerObject)), copyBytes(pl, sizeof(PlayLayer)),
        };
        for (int gone : evicted) {
            s_snapshots.erase(gone);
        }
        if (s_debugFlags.contains("fingerprints")) {
            Snapshot copy = s_snapshots[id];
            copy.checkpoint = nullptr;
            s_fingerprints[s_tick].push_back({ s_planner.prefixHash(s_tick), id, std::move(copy) });
        }
    }

    // While verifying: how the full run compares with the snapshots the search
    // took on the found run's path, to show which of GD's values went off first
    void compareWithSearch(PlayLayer* pl) {
        std::vector<std::pair<int, Snapshot const*>> onPath;
        if (s_debugFlags.contains("fingerprints")) {
            auto it = s_fingerprints.find(s_tick);
            if (it != s_fingerprints.end()) {
                uint64_t prefix = s_planner.prefixHash(s_tick);
                for (auto& fingerprint : it->second) {
                    if (fingerprint.prefix == prefix) onPath.push_back({ fingerprint.id, &fingerprint.snapshot });
                }
            }
        }
        else {
            for (int id : s_planner.snapshotsOnPath(s_tick)) {
                auto it = s_snapshots.find(id);
                if (it != s_snapshots.end()) onPath.push_back({ id, &it->second });
            }
        }
        for (auto [id, snapshotPtr] : onPath) {
            auto& snapshot = *snapshotPtr;
            auto diffs = diffWithSnapshot(pl, snapshot);
            std::string names;
            for (auto& name : diffs) {
                if (!s_alwaysDifferent.contains(name)) names += " " + name;
            }
            if (!s_comparedOnce) {
                s_comparedOnce = true;
                s_alwaysDifferent.insert(diffs.begin(), diffs.end());
                log::info("Checking the full run against the search's snapshots. Values that differ from the start:{}", names);
                names.clear();
            }
            bool same = playerState(pl, false) == snapshot.state;
            s_comparisons.push_back(fmt::format("tick {}: {} snapshot {}, other values that differ:{}",
                s_tick, same ? "matches" : "DOESN'T match", id, names.empty() ? " none" : names));
            if (s_comparisons.size() > 12) s_comparisons.pop_front();
            if (!same && !s_reportedSnapshotDrift) {
                s_reportedSnapshotDrift = true;
                log::warn("The full run doesn't match the search's snapshot {} at tick {}.\n    snapshot: {}\n    full run: {}",
                    id, s_tick, snapshot.stateText, describeState(pl));
            }
        }
    }

    void retryAttempt(PlayLayer* pl) {
        s_needRetry = false;
        s_tick = restoreStart(pl);
        s_path.clear();
        s_heldGoingIn = s_tick > 0 && s_planner.held(s_tick - 1);
        s_planner.restartAttempt(s_tick);
        s_checkStates = false;
        log::info("Replaying attempt {} from tick {}", s_attempts, s_tick);
    }

    void startAttempt(PlayLayer* pl) {
        s_needAttempt = false;
        s_needRetry = false;
        auto maxAttempts = intSetting("max-attempts");
        if (maxAttempts > 0 && s_attemptsSinceBest >= maxAttempts) {
            stopBot(pl, fmt::format("Bot gave up after {} attempts without getting further. Best: {:.1f}%",
                s_attemptsSinceBest, s_bestPercent), NotificationIcon::Warning);
            return;
        }
        if (s_attempts > 0) {
            s_ticksPastFlip += std::max(0, s_tick - s_attemptFlipTick);
            s_attemptsMeasured++;
        }
        if (!s_planner.beginAttempt()) {
            stopBot(pl, fmt::format("Bot ran out of things to try. Best: {:.1f}%", s_bestPercent), NotificationIcon::Warning);
            return;
        }

        s_tick = restoreStart(pl);
        s_path.clear();
        s_heldGoingIn = s_tick > 0 && s_planner.held(s_tick - 1);
        s_checkStates = true;
        s_attemptFlipTick = std::max(s_tick, s_planner.flippedBlock() * s_planner.ticksPerBlock());
        s_attempts++;
        s_attemptsSinceBest++;
        if (s_attempts % 1000 == 0) {
            // Where the search has been dying lately, to see whether it's stuck on one route
            std::vector<std::pair<int, std::pair<int, int>>> places;
            for (auto& [block, count] : s_recentDeaths) places.push_back({ count, block });
            std::sort(places.rbegin(), places.rend());
            std::string where;
            for (size_t i = 0; i < places.size() && i < 6; i++) {
                where += fmt::format(" ({}, {}) {}x", places[i].second.first * 30, places[i].second.second * 30, places[i].first);
            }
            s_recentDeaths.clear();
            log::info("Attempt {}: best {:.2f}%, {} flips waiting, {} duplicates dropped, {} snapshots. Recent deaths by block:{}",
                s_attempts, s_bestPercent, s_planner.pendingCount(), s_duplicates, s_planner.snapshotCount(), where);
        }

        if (s_attempts <= 5) {
            log::info("Attempt {} starts at tick {} (snapshot {}), GD progress {}",
                s_attempts, s_tick, s_planner.startSnapshot(), pl->m_gameState.m_currentProgress);
        }
    }

    void saveSolution(PlayLayer* pl) {
        auto dir = Mod::get()->getSaveDir() / "solutions";
        std::error_code error;
        std::filesystem::create_directories(dir, error);
        auto path = dir / (levelKey(pl) + ".txt");

        std::ofstream out(path);
        out << "gd-bot solution v1\n";
        out << "level " << std::string(pl->m_level->m_levelName) << "\n";
        out << "ticks-per-block " << s_solutionTicksPerBlock << "\n";
        out << "blocks ";
        for (auto block : s_solution) out << (block ? '1' : '0');
        out << "\n";
        out << "after-last-block " << (s_solutionTail ? "held" : "released") << "\n";
        log::info("Saved solution to {}", path.string());
    }

    // What the current attempt changed, for the per-attempt log lines
    std::string describeAttempt() {
        int block = s_planner.flippedBlock();
        if (block < 0) return "no inputs";
        int tick = block * s_planner.ticksPerBlock();
        bool pressed = s_planner.held(tick);
        char const* what = !pressed ? "lets go" : s_planner.flipInHoldMode() ? "starts holding" : "taps";
        return fmt::format("{} at tick {}, started from tick {}", what, tick, s_planner.startTick());
    }

    bool shouldTrace() {
        return s_traceLines < kMaxTraceLines && s_attemptsSinceBest >= kStuckAttempts;
    }

    void onDeath(PlayLayer* pl) {
        s_died = false;
        float percent = pl->getCurrentPercent();

        if (s_mode == Mode::Searching && shouldTrace()) {
            s_traceLines++;
            auto player = pl->m_player1;
            log::info("Try {}: {}; died at tick {} ({:.2f}%), y {:.1f}, y-speed {:.2f}, holding {}, killed by {}",
                s_attempts, describeAttempt(), s_tick, percent, player->m_position.y, player->m_yVelocity, isHolding(player), s_killer);
        }

        // Deaths at the furthest point so far, kept until the search gets stuck
        // there and then logged, to see what blocks it
        if (s_mode == Mode::Searching && s_tick >= s_bestTick - 8 && s_frontierLines < kMaxTraceLines) {
            s_frontierLines++;
            s_frontDeaths.push_back(fmt::format("Death at the front: {}; tick {}, killed by {}; {}",
                describeAttempt(), s_tick, s_killer, describeState(pl)));
        }
        if (s_mode == Mode::Searching && s_debugFlags.contains("best-parent")) {
            auto flips = s_planner.flipsBelowBestParent(3);
            if (!flips.empty()) {
                log::info("Below the best's parent: flips at {}; died at tick {}, killed by {}",
                    fmt::join(flips, ", "), s_tick, s_killer);
            }
        }
        if (s_mode == Mode::Searching && s_attemptsSinceBest >= kStuckAttempts) {
            if (!s_loggedObstacles) {
                s_loggedObstacles = true;
                log::info("Stuck at tick {}. Obstacles around the player:{}", s_tick, describeObstacles(pl));
                std::string path;
                for (auto& point : s_bestPath) {
                    if (point.tick % 4 != 0 && &point != &s_bestPath.back()) continue;
                    path += fmt::format("\n    tick {} ({:.1f}, {:.1f}){}{}{}", point.tick, point.x, point.y,
                        point.onGround ? " on ground" : "", point.upsideDown ? " upside down" : "", point.held ? " holding" : "");
                }
                log::info("Path of the attempt that got furthest:{}", path);
            }
            for (auto& line : s_frontDeaths) log::info("{}", line);
            s_frontDeaths.clear();
        }

        if (s_mode == Mode::Verifying) {
            log::warn("Full run died at tick {} ({:.2f}%): {}", s_tick, percent, describeState(pl));
            // The found run's inputs leading up to it
            std::string held;
            int from = -1;
            for (int tick = std::max(0, s_tick - 480); tick <= s_tick; tick++) {
                bool on = tick < s_tick && solutionHeld(tick);
                if (on && from < 0) from = tick;
                if (!on && from >= 0) {
                    held += fmt::format(" {}-{}", from, tick - 1);
                    from = -1;
                }
            }
            log::warn("Found run holds jump during ticks:{}", held.empty() ? " none" : held);
            if (!s_comparisons.empty()) {
                std::string lines;
                for (auto& line : s_comparisons) lines += "\n    " + line;
                log::warn("The full run against the search's last snapshots on its path:{}", lines);
            }
            stopBot(pl, fmt::format("The full run failed at {:.1f}%. Practice checkpoints didn't match a real run there.", percent),
                NotificationIcon::Error);
            return;
        }

        if (s_attempts <= 5) {
            log::info("Attempt {} died at tick {} ({:.2f}%), GD progress {}",
                s_attempts, s_tick, percent, pl->m_gameState.m_currentProgress);
        }
        if (s_tick > s_bestTick) {
            s_bestTick = s_tick;
            s_bestPercent = percent;
            s_attemptsSinceBest = 0;
            s_traceLines = 0;
            s_frontierLines = 0;
            s_frontDeaths.clear();
            s_loggedObstacles = false;
            log::info("New best {:.2f}% (tick {}) on attempt {}: {}", percent, s_tick, s_attempts, describeAttempt());
            s_bestPath = s_path;
        }
        // The level block it died in, see PlannerConfig::crowdDeaths
        auto blockX = static_cast<int64_t>(std::floor(s_deathPosition.x / 30.f));
        auto blockY = static_cast<int64_t>(std::floor(s_deathPosition.y / 30.f));
        s_recentDeaths[{ static_cast<int>(blockX), static_cast<int>(blockY) }]++;
        s_planner.reportDeath(s_tick, (static_cast<uint64_t>(blockX) << 32) ^ static_cast<uint32_t>(blockY));
        s_needAttempt = true;
    }

    void onLevelEnd(PlayLayer* pl) {
        s_levelEnded = false;

        if (s_mode == Mode::Verifying) {
            log::info("Full run from 0% reached the end");
            // Kept as a macro too, which can be played or converted for other bots
            std::vector<grassy::macro::Input> inputs;
            bool held = false;
            for (size_t block = 0; block <= s_solution.size(); block++) {
                bool want = block < s_solution.size() ? s_solution[block] != 0 : s_solutionTail;
                if (want == held) continue;
                held = want;
                inputs.push_back({ static_cast<uint64_t>(block) * s_solutionTicksPerBlock, 1, false, want });
            }
            grassy::macro::saveBotRun(pl, inputs);
            stopBot(pl, "Bot beat the level from 0% in one go! Its run is saved in the Macro tab.", NotificationIcon::Success);
            return;
        }

        s_solution = s_planner.plan();
        s_solutionTail = s_planner.tail();
        s_solutionTicksPerBlock = s_planner.ticksPerBlock();
        log::info("Found a way through after {} attempts ({} ticks)", s_attempts, s_tick);
        saveSolution(pl);
        Notification::create(fmt::format("Found a way through in {} attempts! Now playing it from 0%...", s_attempts),
            NotificationIcon::Success, 4.f)->show();

        // Snapshots are kept to check the full run against, see compareWithSearch
        s_mode = Mode::Verifying;
        s_reportedDrift = false;
        s_comparisons.clear();
        s_alwaysDifferent.clear();
        s_comparedOnce = false;
        s_reportedSnapshotDrift = false;
        restore(pl, -1, false);
        s_tick = 0;
    }

    void startBot(PlayLayer* pl) {
        if (!pl->m_isPracticeMode) {
            Notification::create("Turn on practice mode first (pause menu)", NotificationIcon::Warning)->show();
            return;
        }
        if (pl->m_isPlatformer) {
            Notification::create("Platformer levels aren't supported yet", NotificationIcon::Warning)->show();
            return;
        }
        if (pl->m_levelSettings && pl->m_levelSettings->m_twoPlayerMode) {
            Notification::create("2-player levels aren't supported yet", NotificationIcon::Warning)->show();
            return;
        }
        if (pl->m_hasCompletedLevel || pl->m_levelEndAnimationStarted) {
            Notification::create("Restart the level first", NotificationIcon::Warning)->show();
            return;
        }

        // The bot runs the level itself, one tick at a time
        if (grassy::stepper::isFrozen()) grassy::stepper::setFrozen(false);

        s_debugFlags.clear();
        std::ifstream debugFile(Mod::get()->getSaveDir() / "debug.txt");
        for (std::string word; debugFile >> word;) s_debugFlags.insert(word);
        for (auto& flag : s_debugFlags) log::info("Debug switch on: {}", flag);

        gdbot::PlannerConfig config;
        // Plans can change input on any tick, but normal flips only go every
        // `precision` ticks, see PlannerConfig::flipSpacing
        config.ticksPerBlock = 1;
        config.flipSpacing = static_cast<int>(intSetting("precision"));
        config.windowTicks = static_cast<int>(intSetting("look-back"));
        config.snapshotInterval = kSnapshotInterval;
        config.maxSnapshots = static_cast<size_t>(intSetting("max-snapshots"));
        s_planner.reset(config);

        s_snapshots.clear();
        s_fingerprints.clear();
        s_attempts = 0;
        s_attemptsSinceBest = 0;
        s_duplicates = 0;
        s_bestTick = 0;
        s_bestPercent = 0.f;
        s_loggedObstacles = false;
        s_recentDeaths.clear();
        s_path.clear();
        s_bestPath.clear();
        s_tickBudget = 0.0;
        s_died = false;
        s_levelEnded = false;
        s_needRetry = false;
        s_warnedTickCount = false;
        s_restoreWarnings = 0;
        s_badSnapshots = 0;
        s_updatesWithoutPhysics = 0;
        s_speedSampleTicks = s_ticksRun;
        s_speedSampleAttempts = 0;
        s_attemptRate = 0.0;
        s_speedSampleTime = Clock::now();
        s_lastSpeedLog = s_speedSampleTime;
        s_measuredSpeed = 0.0;
        s_frameTiming = {};
        s_restoreTiming = {};
        s_holdRestoreTiming = {};
        s_snapshotTiming = {};
        s_tickCost = {};
        s_snapshotCost = {};
        s_ticksPastFlip = 0;
        s_attemptsMeasured = 0;
        s_baselineNodes = countLevelNodes(pl);
        s_traceLines = 0;
        gdbot::profiler::start();
        gdbot::profiler::report(kProfileRestores, 0);
        gdbot::profiler::report(kProfileTicks, 0);
        s_tickTiming = {};

        // The bot manages practice checkpoints itself from here on
        pl->removeAllCheckpoints();
        pauseRecording(pl);
        s_mode = Mode::Searching;
        s_needAttempt = true;
        s_lastMessage.clear();
        grassy::startpos::refresh();

        log::info("Bot started on \"{}\" ({}): precision {}, look-back {}, speed {}x, max snapshots {}",
            std::string(pl->m_level->m_levelName), levelKey(pl), config.flipSpacing, config.windowTicks,
            intSetting("search-speed"), config.maxSnapshots);
        Notification::create("Bot started", NotificationIcon::Info)->show();
    }

    void applyInput(PlayLayer* pl) {
        if (s_checkHeldAfterRestore) {
            s_checkHeldAfterRestore = false;
            // GD may or may not have kept the button state through the respawn,
            // so set it to what it was when the snapshot was taken
            bool holding = isHolding(pl->m_player1) || isHolding(pl->m_player2);
            if (holding != s_heldGoingIn) {
                // GD presses the players right away, so the flag only covers this
                s_restoringHold = true;
                pressJump(pl, s_heldGoingIn);
                s_restoringHold = false;
            }
            s_held = s_heldGoingIn;
        }
        bool want = s_mode == Mode::Searching ? s_planner.held(s_tick) : solutionHeld(s_tick);
        if (want != s_held) pressJump(pl, want);
    }
}

class $modify(BotGameLayer, GJBaseGameLayer) {
    void update(float dt) {
        auto pl = PlayLayer::get();
        if (s_mode == Mode::Off || !pl || pl != static_cast<GJBaseGameLayer*>(this) || pl->m_isPaused) {
            return GJBaseGameLayer::update(dt);
        }

        auto frameStart = Clock::now();
        double speed = static_cast<double>(intSetting(s_mode == Mode::Searching ? "search-speed" : "verify-speed"));
        // Don't pile up ticks after a lag spike
        s_tickBudget = std::min(s_tickBudget + dt * 240.0 * speed, 24.0 * speed + 1.0);
        int ticks = static_cast<int>(s_tickBudget);
        s_tickBudget -= ticks;

        for (int i = 0; i < ticks && s_mode != Mode::Off; i++) {
            // Out of time for this frame: drop the rest rather than trying to
            // catch up next frame, which would only make that frame slower
            if (i > 0 && Clock::now() - frameStart > kFrameBudget) {
                s_tickBudget = 0.0;
                break;
            }
            if (s_needAttempt) {
                startAttempt(pl);
                if (s_mode == Mode::Off) break;
            }
            else if (s_needRetry) {
                retryAttempt(pl);
            }
            if (s_mode == Mode::Searching) {
                bool holdMode = inHoldMode(pl);
                s_planner.noteMode(s_tick, holdMode, pressDoesNothing(pl));
                auto player = pl->m_player1;
                s_path.push_back({ s_tick, player->m_position.x, player->m_position.y, player->m_isOnGround,
                    player->m_isUpsideDown, s_planner.held(s_tick) });
                // Plays out exactly like an earlier attempt from here, nothing new to learn
                if (s_checkStates && s_planner.wantStateCheck(s_tick) && s_planner.isDuplicate(s_tick, playerState(pl))) {
                    if (shouldTrace()) {
                        s_traceLines++;
                        log::info("Try {}: {}; same as an earlier try at tick {}", s_attempts, describeAttempt(), s_tick);
                    }
                    s_planner.reportDuplicate();
                    s_duplicates++;
                    s_needAttempt = true;
                    continue;
                }
                if (s_planner.wantSnapshot(s_tick, canSnapshotWhileHeld(pl))) takeSnapshot(pl);
            }
            else if (s_tick > 0 && !s_checkHeldAfterRestore) {
                compareWithSearch(pl);
            }
            if (s_mode == Mode::Verifying && !s_reportedDrift && s_tick > 0 && gdbot::Planner::isStateCheckTick(s_tick) &&
                    !s_checkHeldAfterRestore && !s_planner.wasSeen(s_tick, playerState(pl))) {
                // Every point of the found run was reached during the search, so
                // the first one the full run doesn't match is where restores drifted
                s_reportedDrift = true;
                auto player = pl->m_player1;
                log::warn("The full run first stops matching the search at tick {} ({:.2f}%): pos ({}, {}), y-speed {}, "
                    "ship {} ufo {} ball {} wave {} robot {} spider {} swing {} upside down {} on ground {}",
                    s_tick, pl->getCurrentPercent(), player->m_position.x, player->m_position.y, player->m_yVelocity,
                    player->m_isShip, player->m_isBird, player->m_isBall, player->m_isDart, player->m_isRobot,
                    player->m_isSpider, player->m_isSwing, player->m_isUpsideDown, player->m_isOnGround);
            }

            s_inBotTick = true;
            s_commandsThisTick = 0;
            auto tickStarted = Clock::now();
            gdbot::profiler::setChannel(kProfileTicks);
            GJBaseGameLayer::update(kTickSeconds);
            gdbot::profiler::setChannel(0);
            s_tickTiming.add(tickStarted);
            s_tickCost.add(tickStarted);
            s_inBotTick = false;
            if (s_commandsThisTick > 1 && !s_warnedTickCount) {
                s_warnedTickCount = true;
                log::warn("An update ran {} physics steps instead of 1 (tick {})", s_commandsThisTick, s_tick);
            }
            // A few updates without physics are normal right after a respawn, many in a row aren't
            if (s_commandsThisTick > 0) {
                s_updatesWithoutPhysics = 0;
            }
            else if (++s_updatesWithoutPhysics == 240) {
                log::warn("No physics for 240 updates at tick {}: started {}, resume timer {}",
                    s_tick, m_started, m_resumeTimer);
                stopBot(pl, "Bot stopped: the game isn't moving. Please report this, with your Geode log.", NotificationIcon::Error);
                break;
            }

            if (s_levelEnded || pl->m_levelEndAnimationStarted || pl->m_hasCompletedLevel) {
                onLevelEnd(pl);
            }
            else if (s_died) {
                onDeath(pl);
            }
        }
        s_frameTiming.add(frameStart);
        if (s_mode != Mode::Off && Clock::now() - frameStart > kMaxFrame) {
            log::warn("A frame took {:.0f} ms", std::chrono::duration<double, std::milli>(Clock::now() - frameStart).count());
            stopBot(pl, "Bot stopped: the game froze for over a second. Please report this, with your Geode log.", NotificationIcon::Error);
        }
        if (s_mode != Mode::Off) measureSpeed(pl);
        updateStatus(pl);
    }

    double getModifiedDelta(float dt) {
        // GD holds physics for a few frames after a respawn and only counts that
        // down in here, so leave those frames to GD
        if (!s_inBotTick || m_resumeTimer > 0) return GJBaseGameLayer::getModifiedDelta(dt);

        // Exactly one tick, the same amount GD's own formula gives for a single
        // step (time warp below 1 shrinks the tick)
        double warp = std::min(m_gameState.m_timeWarp, 1.f);
        m_extraDelta = 0.0;
        return warp * kTickSeconds;
    }

    // One call is one physics step, so the bot counts ticks here
    void processCommands(float dt, bool isHalfTick, bool isLastTick) {
        if (!s_inBotTick) return GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);

        if (auto pl = PlayLayer::get()) applyInput(pl);
        s_commandsThisTick++;
        GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
        s_tick++;
        s_ticksRun++;
    }

    void handleButton(bool down, int button, bool isPlayer1) {
        // Ignore your own clicks while the bot is playing
        if (s_mode != Mode::Off && !s_botPressing && PlayLayer::get() == static_cast<GJBaseGameLayer*>(this)) return;
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
    }

    // resetLevel calls this right before its loop over every object, see s_leanObjects
    void resetActiveEnterEffects() {
        GJBaseGameLayer::resetActiveEnterEffects();
        swapInLeanObjects(this);
    }
};

class $modify(BotPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        forgetEverything();
        return PlayLayer::init(level, useReplay, dontCreateObjects);
    }

    void onQuit() {
        forgetEverything();
        PlayLayer::onQuit();
    }

    void destroyPlayer(PlayerObject* player, GameObject* object) {
        PlayLayer::destroyPlayer(player, object);
        if (s_mode == Mode::Off || object == m_anticheatSpike) return;
        if (player && player->m_isDead) {
            s_died = true;
            s_deathPosition = player->m_position;
            if (!object) object = s_collidingWith;
            s_killer = !object ? "nothing" : fmt::format("object {} (type {}) at ({:.1f}, {:.1f}), player {} at ({:.1f}, {:.1f})",
                object->m_objectID, static_cast<int>(object->m_objectType), object->getPositionX(), object->getPositionY(),
                player == m_player2 ? 2 : 1, player->m_position.x, player->m_position.y);
        }
    }

    void delayedResetLevel() {
        // The bot restarts attempts itself, right away
        if (s_mode != Mode::Off) return;
        PlayLayer::delayedResetLevel();
    }

    void resetLevel() {
        PlayLayer::resetLevel();
        if (s_inBotReset || s_mode == Mode::Off) return;

        // Restarted by something else (a keybind, the pause menu...)
        log::info("Level was reset outside the bot");
        if (s_mode == Mode::Searching) {
            s_needRetry = true;
        }
        else {
            s_tick = 0;
            s_held = false;
            s_heldGoingIn = false;
            s_checkHeldAfterRestore = true;
        }
    }

    // Only decides which objects get drawn, and on busy levels it's the
    // biggest part of a tick. GD does it once per frame, but the bot runs
    // every tick as its own update, so while searching it's done every 4th
    // tick, as when playing at 60 FPS. The full run from 0% does every tick,
    // and its check against the search would show if this ever changed physics.
    void updateVisibility(float dt) {
        bool searching = s_mode == Mode::Searching && !s_debugFlags.contains("full-visibility");
        if (searching && s_inBotTick && s_tick % kVisibilityInterval != 0) return;
        // Restarts do it too, and the next 4th tick will
        if (searching && s_leanReset) return;
        PlayLayer::updateVisibility(dt);
    }

    // resetLevel calls this right after its loop over every object
    void loadDefaultColors() {
        swapOutLeanObjects(this);
        PlayLayer::loadDefaultColors();
    }

    // Timed to find which part of GD's restart is slow
    void loadFromCheckpoint(CheckpointObject* checkpoint) {
        auto started = Clock::now();
        PlayLayer::loadFromCheckpoint(checkpoint);
        if (s_inBotReset) s_loadCheckpointTiming.add(started);
    }

    void updateAttempts() {
        // Bot attempts don't count towards the level's attempt count
        if (s_inBotReset) return;
        PlayLayer::updateAttempts();
    }

    void levelComplete() {
        if (s_mode == Mode::Searching) {
            // Skip the end screen, the bot restarts to play the run from 0%
            s_levelEnded = true;
            return;
        }
        PlayLayer::levelComplete();
    }

    void playEndAnimationToPos(CCPoint position) {
        if (s_mode == Mode::Searching) {
            s_levelEnded = true;
            return;
        }
        PlayLayer::playEndAnimationToPos(position);
    }

    void togglePracticeMode(bool practiceMode) {
        if (!practiceMode && s_mode != Mode::Off) {
            stopBot(this, "Bot stopped: you left practice mode", NotificationIcon::Info);
        }
        PlayLayer::togglePracticeMode(practiceMode);
    }
};

// The parts of loading a checkpoint, timed to find which one is slow
class $modify(BotAudioEngine, FMODAudioEngine) {
    // Restarting rewinds the song to the checkpoint, and seeking in an MP3 is
    // what makes restarts slow (more so further into the song). The music is
    // paused while the bot searches anyway, and it doesn't affect gameplay.
    void setMusicTimeMS(unsigned int time, bool dontWait, int musicID) {
        if (s_inBotReset && s_mode == Mode::Searching) return;
        FMODAudioEngine::setMusicTimeMS(time, dontWait, musicID);
    }

    void loadAudioState(FMODAudioState& state) {
        auto started = Clock::now();
        FMODAudioEngine::loadAudioState(state);
        if (s_inBotReset) s_loadAudioTiming.add(started);
    }
};

class $modify(BotEffectManager, GJEffectManager) {
    void loadFromState(EffectManagerState& state) {
        auto started = Clock::now();
        GJEffectManager::loadFromState(state);
        if (s_inBotReset) s_loadEffectsTiming.add(started);
    }
};

class $modify(BotPlayerObject, PlayerObject) {
    void loadFromCheckpoint(PlayerCheckpoint* checkpoint) {
        auto started = Clock::now();
        PlayerObject::loadFromCheckpoint(checkpoint);
        if (s_inBotReset) s_loadPlayerTiming.add(started);
    }

    bool collidedWithObjectInternal(float dt, GameObject* object, CCRect rect, bool skipCheck) {
        s_collidingWith = object;
        bool result = PlayerObject::collidedWithObjectInternal(dt, object, rect, skipCheck);
        s_collidingWith = nullptr;
        return result;
    }

    void collidedWithSlopeInternal(float dt, GameObject* object, bool forced) {
        s_collidingWith = object;
        PlayerObject::collidedWithSlopeInternal(dt, object, forced);
        s_collidingWith = nullptr;
    }

    // On Cataclysm, a snapshot taken holding jump in the ship right at an orb
    // used the orb when the bot pressed again after restoring it, which a run
    // holding all along never does, so the found run failed at 22%
    bool pushButton(PlayerButton button) {
        if (!s_restoringHold || button != PlayerButton::Jump) return PlayerObject::pushButton(button);
        static Ref<CCArray> noRings = CCArray::create();
        auto kept = PressState::from(this);
        auto rings = m_touchingRings;
        m_touchingRings = noRings;
        bool result = PlayerObject::pushButton(button);
        m_touchingRings = rings;
        kept.applyTo(this);
        return result;
    }

    bool releaseButton(PlayerButton button) {
        if (!s_restoringHold || button != PlayerButton::Jump) return PlayerObject::releaseButton(button);
        auto kept = PressState::from(this);
        bool result = PlayerObject::releaseButton(button);
        kept.applyTo(this);
        return result;
    }
};

bool grassy::bot::isRunning() {
    return s_mode != Mode::Off;
}

void grassy::bot::toggle() {
    auto pl = PlayLayer::get();
    if (!pl) {
        Notification::create("Open a level first", NotificationIcon::Warning)->show();
        return;
    }
    if (s_mode != Mode::Off) {
        stopBot(pl, "Bot stopped", NotificationIcon::Info);
    }
    else {
        startBot(pl);
    }
}

std::string grassy::bot::status() {
    if (s_mode == Mode::Searching) {
        return fmt::format("Searching: attempt {}, best {:.1f}%, {:.0f} attempts/s", s_attempts, s_bestPercent, s_attemptRate);
    }
    if (s_mode == Mode::Verifying) return "Playing the found run from 0%";
    return s_lastMessage;
}
