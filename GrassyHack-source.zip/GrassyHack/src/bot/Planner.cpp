#include "Planner.hpp"

#include <algorithm>
#include <cmath>

namespace gdbot {

namespace {
    // Ticks between duplicate checks. Two attempts that match once keep
    // matching, so a sparse check only costs a few extra ticks.
    constexpr int kStateCheckInterval = 16;
    // Right after a flip, check more often: an attempt that dies before its
    // first sparse check is never compared, and in modes where most taps do
    // nothing (ball in the air) thousands of such attempts are really the same
    constexpr int kDenseCheckTicks = 16;
    constexpr int kDenseCheckInterval = 2;
    constexpr uint64_t kHeldTail = 0x7461696c68656c64ull;
    constexpr int kTooLateTicks = 6;
    constexpr int kOrderBits = 12;
    constexpr int kMaxOrder = 1 << kOrderBits;
    // How close to a snapshot that didn't restore properly no new ones are taken
    constexpr int kBadSnapshotMargin = 60;
    // Blocks around a tap that must all be idle for the tap to be skipped,
    // see Planner::pressDoesNothing
    constexpr int kIdleMargin = 2;

    int reverseBits(int value) {
        int result = 0;
        for (int i = 0; i < kOrderBits; i++) {
            result = (result << 1) | ((value >> i) & 1);
        }
        return result;
    }

    // Notes whether `at` is in a span of blocks. The same block can be noted
    // twice, and a replayed attempt starts over, so later blocks are forgotten.
    void noteSpan(std::vector<std::pair<int, int>>& spans, int at, bool in) {
        while (!spans.empty() && spans.back().first >= at) spans.pop_back();
        if (!spans.empty() && spans.back().second > at) spans.back().second = at;
        if (!in) return;
        if (!spans.empty() && spans.back().second == at) spans.back().second = at + 1;
        else spans.push_back({ at, at + 1 });
    }

    uint64_t mix(uint64_t x) {
        x += 0x9e3779b97f4a7c15ull;
        x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ull;
        x = (x ^ (x >> 27)) * 0x94d049bb133111ebull;
        return x ^ (x >> 31);
    }

    // Flips one block, see the comment in the header. Blocks after it are
    // dropped, and trailing blocks equal to the tail are trimmed so the same
    // inputs always give the same plan.
    // A press in a tap mode lasts `tapBlocks` blocks, as long as with the normal flip spacing.
    void flipBlock(std::vector<uint8_t>& plan, bool& tail, int block, bool holdMode, int tapBlocks) {
        bool current = static_cast<size_t>(block) < plan.size() ? plan[block] : tail;
        plan.resize(block, tail);
        int length = holdMode || current ? 1 : tapBlocks;
        plan.insert(plan.end(), length, !current);
        tail = holdMode && !current;
        while (!plan.empty() && (plan.back() != 0) == tail) {
            plan.pop_back();
        }
    }
}

bool Planner::CandidateOrder::operator()(Candidate const& a, Candidate const& b) const {
    // The heap keeps the largest on top, so this returns whether a comes after b
    if (a.priority != b.priority) return a.priority < b.priority;
    if (a.order != b.order) return a.order > b.order;
    if (a.block != b.block) return a.block < b.block;
    return a.parent < b.parent;
}

void Planner::reset(PlannerConfig const& config) {
    m_config = config;
    m_nodes.clear();
    m_candidates.clear();
    m_triedPlans.clear();
    m_seenStates.clear();
    m_snapshots.clear();
    m_snapshotCount = 0;
    m_nextSnapshotId = 0;
    m_useClock = 0;
    m_bestTick = 0;
    m_bestNode = -1;
    m_attemptsSinceBest = 0;
    m_fineMode = false;
    m_holdModes.clear();
    m_placeIndex.clear();
    m_deathsAt.clear();
    m_badSnapshotRanges.clear();
    m_node = -1;
    setPlan({}, false);
    m_startSnapshot = -1;
    m_startTick = 0;
    m_lastSnapshotTick = 0;
    m_tailFrom = 0;
    m_lastStateCheck = -1;
    m_playedFrom = 0;
    m_holdSpans.clear();
    // The first attempt doesn't press anything
    pushCandidate({ -1, -1, 0, 0 });
}

void Planner::buildPlan(int node, std::vector<uint8_t>& plan, bool& tail) const {
    std::vector<int> chain;
    for (int n = node; n >= 0; n = m_nodes[n].parent) {
        if (m_nodes[n].block >= 0) chain.push_back(n);
    }
    plan.clear();
    tail = false;
    for (auto it = chain.rbegin(); it != chain.rend(); ++it) {
        flipBlock(plan, tail, m_nodes[*it].block, m_nodes[*it].holdMode, m_config.flipSpacing);
    }
}

void Planner::setPlan(std::vector<uint8_t> plan, bool tail) {
    m_plan = std::move(plan);
    m_tail = tail;
    m_prefix.assign(m_plan.size() + 1, 0);
    m_prefix[0] = 0x6764626f74ull;
    for (size_t i = 0; i < m_plan.size(); i++) {
        m_prefix[i + 1] = m_plan[i] ? mix(m_prefix[i] ^ mix(i + 1)) : m_prefix[i];
    }
}

bool Planner::holdModeAt(int block) const {
    return block >= 0 && static_cast<size_t>(block) < m_holdModes.size() && m_holdModes[block];
}

bool Planner::holdModeIn(Node const& node, int block) const {
    // Started from a snapshot past this block, so it never saw it
    if (block < node.playedFrom) return holdModeAt(block);
    for (auto& [from, to] : node.holdSpans) {
        if (block >= from && block < to) return true;
    }
    return false;
}

uint64_t Planner::prefixHash(int tick) const {
    size_t blocks = tick / m_config.ticksPerBlock;
    if (blocks <= m_plan.size()) return m_prefix[blocks];
    if (!m_tail) return m_prefix[m_plan.size()];
    // Every block past the plan is held
    while (m_prefix.size() <= blocks) {
        size_t i = m_prefix.size() - 1;
        m_prefix.push_back(mix(m_prefix[i] ^ mix(i + 1)));
    }
    return m_prefix[blocks];
}

bool Planner::held(int tick) const {
    size_t block = tick / m_config.ticksPerBlock;
    return block < m_plan.size() ? m_plan[block] != 0 : m_tail;
}

void Planner::noteMode(int tick, bool holdMode, bool pressDoesNothing) {
    size_t block = tick / m_config.ticksPerBlock;
    if (m_holdModes.size() <= block) m_holdModes.resize(block + 1, 0);
    m_holdModes[block] = holdMode;

    int at = static_cast<int>(block);
    m_playedFrom = std::min(m_playedFrom, at);
    noteSpan(m_holdSpans, at, holdMode);
    // Only where jump was let go, so a flip there is a press
    noteSpan(m_idleSpans, at, pressDoesNothing && !held(tick));
}

bool Planner::pressDoesNothing(Node const& node, int block) const {
    // The press lasts as long as a normal tap, and a little either side of it
    // is checked too, in case GD reacts a tick early or late
    int from = block - kIdleMargin;
    int to = block + m_config.flipSpacing + kIdleMargin;
    if (from < node.playedFrom) return false;
    for (auto& [first, end] : node.idleSpans) {
        if (first <= from && to < end) return true;
    }
    return false;
}

bool Planner::beginAttempt() {
    if (++m_attemptsSinceBest >= m_config.stuckAttempts && !m_fineMode && m_config.flipSpacing > 1) {
        m_fineMode = true;
        for (int node = 0; node < static_cast<int>(m_nodes.size()); node++) {
            queueFineFlips(node);
        }
    }
    while (!m_candidates.empty()) {
        std::pop_heap(m_candidates.begin(), m_candidates.end(), CandidateOrder());
        Candidate candidate = m_candidates.back();
        m_candidates.pop_back();
        if (candidate.parent >= 0) {
            // More attempts may have died where the parent did since this was queued
            int priority = candidate.base - crowdPenalty(m_nodes[candidate.parent].place);
            if (priority < candidate.priority) {
                candidate.priority = priority;
                pushCandidate(candidate);
                continue;
            }
        }
        if (candidate.parent >= 0 && --m_nodes[candidate.parent].pending == 0) {
            widenWindow(candidate.parent);
        }

        std::vector<uint8_t> plan;
        bool tail;
        buildPlan(candidate.parent, plan, tail);
        bool holdMode = candidate.holdMode;
        if (candidate.block >= 0) flipBlock(plan, tail, candidate.block, holdMode, m_config.flipSpacing);
        setPlan(std::move(plan), tail);
        // With a held tail, where the plan ends matters too
        uint64_t planHash = m_tail ? mix(m_prefix.back() ^ mix(m_plan.size()) ^ kHeldTail) : m_prefix.back();
        if (!m_triedPlans.insert(planHash).second) continue;

        m_node = static_cast<int>(m_nodes.size());
        int depth = candidate.parent >= 0 ? m_nodes[candidate.parent].depth + 1 : 0;
        m_nodes.push_back({ candidate.parent, candidate.block, holdMode, depth });
        m_tailFrom = static_cast<int>(m_plan.size()) * m_config.ticksPerBlock;
        m_lastStateCheck = -1;

        chooseStart();
        return true;
    }
    return false;
}

void Planner::chooseStart() {
    // Resume from the latest snapshot whose inputs so far match this plan
    m_startSnapshot = -1;
    m_startTick = 0;
    for (auto it = m_snapshots.rbegin(); it != m_snapshots.rend() && m_startSnapshot < 0; ++it) {
        uint64_t prefix = prefixHash(it->first);
        for (auto& snapshot : it->second) {
            if (snapshot.prefix == prefix) {
                m_startSnapshot = snapshot.id;
                m_startTick = it->first;
                snapshot.lastUsed = ++m_useClock;
                break;
            }
        }
    }
    m_lastSnapshotTick = m_startTick;
    m_lastStateCheck = -1;
    m_playedFrom = m_startTick / m_config.ticksPerBlock;
    m_holdSpans.clear();
    m_idleSpans.clear();
}

std::vector<int> Planner::snapshotsOnPath(int tick) const {
    std::vector<int> ids;
    auto it = m_snapshots.find(tick);
    if (it == m_snapshots.end()) return ids;
    uint64_t prefix = prefixHash(tick);
    for (auto& snapshot : it->second) {
        if (snapshot.prefix == prefix) ids.push_back(snapshot.id);
    }
    return ids;
}

int Planner::dropBadSnapshot(int id) {
    for (auto it = m_snapshots.begin(); it != m_snapshots.end(); ++it) {
        auto& list = it->second;
        for (size_t i = 0; i < list.size(); i++) {
            if (list[i].id != id) continue;
            int tick = it->first;
            list.erase(list.begin() + i);
            if (list.empty()) m_snapshots.erase(it);
            m_snapshotCount--;
            m_badSnapshotRanges.push_back({ tick - kBadSnapshotMargin, tick + kBadSnapshotMargin });
            return tick;
        }
    }
    return -1;
}

bool Planner::nearBadSnapshot(int tick) const {
    for (auto& [from, to] : m_badSnapshotRanges) {
        if (tick >= from && tick <= to) return true;
    }
    return false;
}

bool Planner::wantSnapshot(int tick, bool holdOk) {
    int perBlock = m_config.ticksPerBlock;
    // Only where normal flips go: restoring on the ticks between seems to
    // send the search somewhere a straight run doesn't go
    if (tick % (perBlock * m_config.flipSpacing) != 0) return false;
    int flipTick = m_node >= 0 && m_nodes[m_node].block >= 0 ? m_nodes[m_node].block * perBlock : -1;
    int interval = tick <= flipTick ? m_config.replaySnapshotInterval : m_config.snapshotInterval;
    if (tick - m_lastSnapshotTick < interval) return false;
    if (nearBadSnapshot(tick)) return false;
    if (!holdOk && held(tick - perBlock)) return false;

    uint64_t prefix = prefixHash(tick);
    auto it = m_snapshots.find(tick);
    if (it != m_snapshots.end()) {
        for (auto& snapshot : it->second) {
            if (snapshot.prefix == prefix) {
                snapshot.lastUsed = ++m_useClock;
                m_lastSnapshotTick = tick;
                return false;
            }
        }
    }
    return true;
}

int Planner::addSnapshot(int tick, std::vector<int>& evicted) {
    int id = m_nextSnapshotId++;
    m_snapshots[tick].push_back({ id, prefixHash(tick), ++m_useClock });
    m_snapshotCount++;
    m_lastSnapshotTick = tick;
    while (m_snapshotCount > m_config.maxSnapshots) {
        evictOldest(evicted);
    }
    return id;
}

void Planner::evictOldest(std::vector<int>& evicted) {
    auto oldestTick = m_snapshots.end();
    size_t oldestIndex = 0;
    for (auto it = m_snapshots.begin(); it != m_snapshots.end(); ++it) {
        for (size_t i = 0; i < it->second.size(); i++) {
            if (oldestTick == m_snapshots.end() || it->second[i].lastUsed < oldestTick->second[oldestIndex].lastUsed) {
                oldestTick = it;
                oldestIndex = i;
            }
        }
    }
    if (oldestTick == m_snapshots.end()) return;

    evicted.push_back(oldestTick->second[oldestIndex].id);
    oldestTick->second.erase(oldestTick->second.begin() + oldestIndex);
    if (oldestTick->second.empty()) m_snapshots.erase(oldestTick);
    m_snapshotCount--;
}

bool Planner::isStateCheckTick(int tick) {
    return tick % kStateCheckInterval == 0;
}

bool Planner::wantStateCheck(int tick) const {
    // Right after a restore the button state isn't settled yet, so skip that tick
    bool dense = tick - m_tailFrom < kDenseCheckTicks && tick % kDenseCheckInterval == 0;
    return (isStateCheckTick(tick) || dense) && tick >= m_tailFrom && tick != m_lastStateCheck && tick != m_startTick;
}

bool Planner::isDuplicate(int tick, uint64_t state) {
    m_lastStateCheck = tick;
    uint64_t key = mix(state ^ mix(static_cast<uint64_t>(tick) + 1) ^ (m_tail ? kHeldTail : 0));
    auto [it, added] = m_seenStates.try_emplace(key, m_node);
    if (added || it->second == m_node) return false;
    m_duplicateOf = it->second;
    m_duplicateTick = tick;
    return true;
}

bool Planner::wasSeen(int tick, uint64_t state) const {
    uint64_t base = state ^ mix(static_cast<uint64_t>(tick) + 1);
    return m_seenStates.contains(mix(base)) || m_seenStates.contains(mix(base ^ kHeldTail));
}

void Planner::reportDuplicate() {
    // An earlier attempt plays out exactly like this one from here, so this
    // one dies where that one did, and expanding it would mostly repeat that
    // one's flips. Except when this one let go of a held jump earlier than
    // that one: in tap modes that changes nothing until the next press, so
    // they all match, and only an early enough let-go leaves time for it.
    Node& node = m_nodes[m_node];
    Node const& other = m_nodes[m_duplicateOf];
    bool letGo = node.block >= 0 && !held(node.block * m_config.ticksPerBlock);
    if (!letGo || other.death <= 0 || other.block <= node.block) return;
    node.death = other.death;
    node.place = other.place;
    node.playedFrom = m_playedFrom;
    node.holdSpans = std::move(m_holdSpans);
    m_holdSpans.clear();
    node.idleSpans = std::move(m_idleSpans);
    m_idleSpans.clear();
    node.lastFlip = (m_duplicateTick - 1) / m_config.ticksPerBlock;
    queueWindow(m_node);
}

void Planner::reportDeath(int tick, uint64_t place) {
    Node& node = m_nodes[m_node];
    node.death = tick;
    auto [it, added] = m_placeIndex.try_emplace(place, static_cast<int>(m_deathsAt.size()));
    if (added) m_deathsAt.push_back(0);
    m_deathsAt[it->second]++;
    node.place = it->second;
    node.playedFrom = m_playedFrom;
    node.holdSpans = std::move(m_holdSpans);
    m_holdSpans.clear();
    node.idleSpans = std::move(m_idleSpans);
    m_idleSpans.clear();
    if (tick > m_bestTick) {
        m_bestTick = tick;
        m_bestNode = m_node;
        m_attemptsSinceBest = 0;
        m_fineMode = false;
    }
    if (tick > 0) queueWindow(m_node);
}

void Planner::queueWindow(int node) {
    Node& n = m_nodes[node];
    int perBlock = m_config.ticksPerBlock;
    int last = (n.death - 1) / perBlock;
    // Flips before this node's own flip belong to its ancestors
    int first = std::max(n.block + 1, (n.death - m_config.windowTicks) / perBlock);
    if (first > last) return;
    n.lowestQueued = first;
    queueFlips(node, first, last, false);
    if (m_fineMode) queueFineFlips(node);
    // The window may hold no normal flips at all
    if (m_nodes[node].pending == 0) widenWindow(node);
}

int Planner::queueFlips(int node, int from, int to, bool fine) {
    int death = m_nodes[node].death;
    int base = death - (m_nodes[node].depth + 1) * m_config.flipCostTicks;
    // A last resort: the normal flips of attempts that died a window earlier go first
    if (fine) base -= m_config.windowTicks;
    int priority = base - crowdPenalty(m_nodes[node].place);
    int last = (death - 1) / m_config.ticksPerBlock;
    int queued = 0;
    to = std::min(to, m_nodes[node].lastFlip);
    for (int block = from; block <= to; block++) {
        if ((block % m_config.flipSpacing == 0) == fine) continue;
        int distance = last - block;
        // Bit-reversed distance spreads the tries over the whole window, coarse
        // to fine. A change in the last few ticks can rarely save an attempt.
        int order = distance * m_config.ticksPerBlock < kTooLateTicks ? kMaxOrder + distance : reverseBits(distance);
        bool holdMode = holdModeIn(m_nodes[node], block);
        // Taps where the player can't do anything would only come back as duplicates
        if (!holdMode && pressDoesNothing(m_nodes[node], block)) continue;
        pushCandidate({ node, block, priority, order, holdMode, base });
        m_nodes[node].pending++;
        queued++;
    }
    return queued;
}

void Planner::widenWindow(int node) {
    int floor = m_nodes[node].block + 1;
    // Keep going if a stretch has no normal flips in it
    while (m_nodes[node].pending == 0 && m_nodes[node].lowestQueued > floor) {
        int lowest = m_nodes[node].lowestQueued;
        int from = std::max(floor, lowest - std::max(1, m_config.windowTicks / m_config.ticksPerBlock));
        m_nodes[node].lowestQueued = from;
        queueFlips(node, from, lowest - 1, false);
    }
}

std::vector<int> Planner::flipsBelowBestParent(int depth) const {
    std::vector<int> flips;
    if (m_bestNode < 0 || m_node < 0) return flips;
    int ancestor = m_nodes[m_bestNode].parent;
    for (int n = m_node; n >= 0 && static_cast<int>(flips.size()) < depth; n = m_nodes[n].parent) {
        flips.insert(flips.begin(), m_nodes[n].block * m_config.ticksPerBlock);
        if (m_nodes[n].parent == ancestor) return flips;
    }
    return {};
}

void Planner::pushCandidate(Candidate const& candidate) {
    m_candidates.push_back(candidate);
    std::push_heap(m_candidates.begin(), m_candidates.end(), CandidateOrder());
}

int Planner::crowdPenalty(int place) const {
    if (place < 0 || m_config.crowdDeaths <= 0) return 0;
    double crowd = static_cast<double>(m_deathsAt[place]) / m_config.crowdDeaths;
    return static_cast<int>(m_config.flipCostTicks * std::log2(1.0 + crowd));
}

bool Planner::nearFront(Node const& node) const {
    return node.death > 0 && node.death >= m_bestTick - m_config.windowTicks;
}

void Planner::queueFineFlips(int node) {
    Node& n = m_nodes[node];
    if (n.finePassed || !nearFront(n)) return;
    n.finePassed = true;
    int perBlock = m_config.ticksPerBlock;
    int last = (n.death - 1) / perBlock;
    int first = std::max(n.block + 1, (n.death - m_config.windowTicks) / perBlock);
    if (first <= last) queueFlips(node, first, last, true);
}

}
