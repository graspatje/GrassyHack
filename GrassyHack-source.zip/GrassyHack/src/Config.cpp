#include "Config.hpp"

#include <map>
#include <string>

using namespace geode::prelude;

namespace {
    // Defaults aren't written to the save, so changing one here also changes
    // it for options that were never touched
    std::map<std::string_view, bool> const kBools = {
        { "noclip", false },
        { "noclip.flash", true },
        { "speedhack", false },
        { "speedhack.audio", true },
        { "safe-mode", true },
        { "safe-mode.always", false },
        { "cheat-indicator", true },
        { "startpos", true },
        { "startpos.hide-ui", false },
        { "confirm-exit", true },
        { "stepper.label", true },
        { "bot.fast-restarts", true },
        { "bot.show-status", true },
        { "menu.rainbow", false },
        { "menu.dim", true },
        { "menu.quick", false },
        { "chat.tools", true },
        { "chat.ai.glow", false },
        { "labels.clock", false },
        { "labels.clock.12h", false },
        { "labels.clock.seconds", false },
        { "labels.session", false },
        { "labels.attempts", false },
        { "labels.attempts.total", false },
        { "labels.percent", false },
        { "labels.noclip-accuracy", false },
        { "labels.noclip-deaths", false },
        { "respawn.instant", false },
        { "respawn.custom", false },
        { "deaths", false },
        { "deaths.markers", true },
        { "deaths.practice", true },
        { "macro.autosave", true },
        { "chests.fast", false },
        { "levels.zoom", false },
        { "confirm-practice", false },
        { "bypass.practice-music", false },
        { "bypass.unlock-all", false },
        { "bypass.main-levels", false },
        { "bypass.slider", false },
        { "bypass.text-length", false },
        { "fps.unlock", false },
        { "labels.custom", false },
        { "labels.fps", false },
        { "labels.cps", false },
        { "labels.cps.best", false },
        { "labels.frame", false },
        { "cosmetic.hide-player", false },
        { "cosmetic.no-trail", false },
        { "cosmetic.no-wave-trail", false },
        { "cosmetic.no-trail-behind-wave", false },
        { "cosmetic.no-dash-fire", false },
        { "cosmetic.no-robot-fire", false },
        { "cosmetic.no-swing-fire", false },
        { "cosmetic.trail-always", false },
        { "cosmetic.icon-on-top", false },
        { "cosmetic.p1-on-top", false },
        { "cosmetic.p2-on-top", false },
        { "cosmetic.icon-randomizer", false },
        { "cosmetic.pitch", false },
        { "cosmetic.startpos-camera", false },
        { "cosmetic.accurate-percent", false },
        { "cosmetic.total-attempts", false },
        { "cosmetic.no-new-best", false },
        { "cosmetic.no-do-not", false },
        { "font", false },
        { "cosmetic.no-glow", false },
        { "cosmetic.no-shake", false },
        { "cosmetic.no-end-shake", false },
        { "cosmetic.no-zoom", false },
        { "cosmetic.no-mirror", false },
        { "cosmetic.stop-triggers", false },
        { "cosmetic.no-death-effect", false },
        { "cosmetic.no-respawn-flash", false },
        { "cosmetic.no-spider-dash", false },
        { "cosmetic.no-ghost-trail", false },
        { "cosmetic.no-orb-ring", false },
        { "cosmetic.no-particles", false },
        { "cosmetic.no-shaders", false },
        { "cosmetic.no-pulse", false },
        { "cosmetic.no-wave-pulse", false },
        { "cosmetic.wave-pulse-size", false },
        { "hitboxes", false },
        { "hitboxes.death", false },
        { "hitboxes.trail", false },
        { "layout", false },
        { "show-triggers", false },
        { "trajectory", false },
        { "deafen", false },
        { "deafen.ctrl", true },
        { "deafen.shift", true },
        { "deafen.alt", false },
        { "jumpscare", false },
        { "practice-complete", false },
        { "autokill", false },
        { "autokill.practice", false },
        { "instant-complete", false },
        { "autoclicker", false },
        { "autoclicker.player2", false },
        { "jump-hack", false },
        { "force-platformer", false },
        { "startpos.smart", false },
        { "click-between-steps", false },
        { "click-on-steps", false },
        { "music-sync", false },
        { "tps.unlock", false },
    };

    std::map<std::string_view, int64_t> const kInts = {
        { "stepper.history", 240 },
        { "bot.search-speed", 100 },
        { "bot.verify-speed", 1 },
        { "bot.precision", 2 },
        { "bot.look-back", 180 },
        { "bot.max-snapshots", 400 },
        { "bot.max-attempts", 0 },
        { "cheat-indicator.ruleset", 0 },
        // macro::Format values, 0 is GDR
        { "macro.format", 0 },
        { "macro.convert-format", 0 },
        { "labels.percent.decimals", 2 },
        { "labels.transparency", 25 },
        // 0 top left, 1 top right
        { "labels.corner", 0 },
        // 0xRRGGBB
        { "menu.accent", 0x3DBE5C },
        { "key.menu", KEY_Tab },
        { "key.noclip", KEY_None },
        { "key.speedhack", KEY_None },
        { "key.safe-mode", KEY_None },
        { "key.cheat-indicator", KEY_None },
        { "key.startpos", KEY_None },
        { "key.startpos.prev", KEY_Q },
        { "key.startpos.next", KEY_E },
        { "key.confirm-exit", KEY_None },
        { "key.stepper", KEY_Down },
        { "key.stepper.step", KEY_Right },
        { "key.stepper.back", KEY_Left },
        { "key.bot", KEY_F8 },
        { "key.menu.rainbow", KEY_None },
        { "key.menu.dim", KEY_None },
        { "key.menu.quick", KEY_None },
        { "key.respawn.instant", KEY_None },
        { "key.respawn.custom", KEY_None },
        { "key.deaths", KEY_None },
        { "key.labels.clock", KEY_None },
        { "key.labels.session", KEY_None },
        { "key.labels.attempts", KEY_None },
        { "key.labels.percent", KEY_None },
        { "key.labels.noclip-accuracy", KEY_None },
        { "key.labels.noclip-deaths", KEY_None },
        { "key.startpos.hide-ui", KEY_None },
        { "key.macro.record", KEY_None },
        { "key.macro.play", KEY_None },
        { "cosmetic.accurate-percent.decimals", 2 },
        { "deafen.percent", 50 },
        { "deafen.key", KEY_None },
        { "jumpscare.percent", 50 },
        { "jumpscare.chance", 100 },
        { "autokill.percent", 90 },
        { "autoclicker.interval", 10 },
        { "autoclicker.hold", 5 },
        { "key.chests.fast", KEY_None },
        { "key.levels.zoom", KEY_None },
        { "key.font", KEY_None },
        { "key.confirm-practice", KEY_None },
        { "key.bypass.practice-music", KEY_None },
        { "key.bypass.unlock-all", KEY_None },
        { "key.bypass.main-levels", KEY_None },
        { "key.bypass.slider", KEY_None },
        { "key.bypass.text-length", KEY_None },
        { "key.fps.unlock", KEY_None },
        { "key.labels.custom", KEY_None },
        { "key.labels.fps", KEY_None },
        { "key.labels.cps", KEY_None },
        { "key.labels.frame", KEY_None },
        { "key.cosmetic.hide-player", KEY_None },
        { "key.cosmetic.no-trail", KEY_None },
        { "key.cosmetic.no-wave-trail", KEY_None },
        { "key.cosmetic.no-trail-behind-wave", KEY_None },
        { "key.cosmetic.no-dash-fire", KEY_None },
        { "key.cosmetic.no-robot-fire", KEY_None },
        { "key.cosmetic.no-swing-fire", KEY_None },
        { "key.cosmetic.trail-always", KEY_None },
        { "key.cosmetic.icon-on-top", KEY_None },
        { "key.cosmetic.p1-on-top", KEY_None },
        { "key.cosmetic.p2-on-top", KEY_None },
        { "key.cosmetic.icon-randomizer", KEY_None },
        { "key.cosmetic.pitch", KEY_None },
        { "key.cosmetic.startpos-camera", KEY_None },
        { "key.cosmetic.accurate-percent", KEY_None },
        { "key.cosmetic.total-attempts", KEY_None },
        { "key.cosmetic.no-new-best", KEY_None },
        { "key.cosmetic.no-do-not", KEY_None },
        { "key.cosmetic.no-glow", KEY_None },
        { "key.cosmetic.no-shake", KEY_None },
        { "key.cosmetic.no-end-shake", KEY_None },
        { "key.cosmetic.no-zoom", KEY_None },
        { "key.cosmetic.no-mirror", KEY_None },
        { "key.cosmetic.stop-triggers", KEY_None },
        { "key.cosmetic.no-death-effect", KEY_None },
        { "key.cosmetic.no-respawn-flash", KEY_None },
        { "key.cosmetic.no-spider-dash", KEY_None },
        { "key.cosmetic.no-ghost-trail", KEY_None },
        { "key.cosmetic.no-orb-ring", KEY_None },
        { "key.cosmetic.no-particles", KEY_None },
        { "key.cosmetic.no-shaders", KEY_None },
        { "key.cosmetic.no-pulse", KEY_None },
        { "key.cosmetic.no-wave-pulse", KEY_None },
        { "key.cosmetic.wave-pulse-size", KEY_None },
        { "key.hitboxes", KEY_None },
        { "key.hitboxes.death", KEY_None },
        { "key.hitboxes.trail", KEY_None },
        { "key.layout", KEY_None },
        { "key.show-triggers", KEY_None },
        { "key.trajectory", KEY_None },
        { "key.deafen", KEY_None },
        { "key.jumpscare", KEY_None },
        { "key.practice-complete", KEY_None },
        { "key.autokill", KEY_None },
        { "key.instant-complete", KEY_None },
        { "key.autoclicker", KEY_None },
        { "key.jump-hack", KEY_None },
        { "key.force-platformer", KEY_None },
        { "key.startpos.smart", KEY_None },
        { "key.click-between-steps", KEY_None },
        { "key.click-on-steps", KEY_None },
        { "key.music-sync", KEY_None },
        { "key.tps.unlock", KEY_None },
        { "key.restart", KEY_None },
        { "key.cbf", KEY_None },
        { "key.vsync", KEY_None },
        { "key.chat", KEY_None },
        // 0 a GD icon, 1 a picture from the PC (chat.ai.image)
        { "chat.ai.picture", 0 },
        // GD's IconType, 5 is the robot
        { "chat.ai.icon-type", 5 },
        { "chat.ai.icon", 1 },
        // 0xRRGGBB
        { "chat.ai.color", 0x00C8FF },
        { "chat.ai.color2", 0xFFFFFF },
        { "chat.ai.glow-color", 0xFFFFFF },
    };

    std::map<std::string_view, double> const kFloats = {
        { "speedhack.value", 1.0 },
        { "menu.scale", 1.0 },
        { "labels.size", 1.0 },
        { "respawn.time", 1.0 },
        { "fps.value", 360.0 },
        { "tps.value", 360.0 },
        { "cosmetic.pitch.value", 1.0 },
        { "cosmetic.wave-pulse-size.value", 1.0 },
        // How big the level list is drawn, 1 is GD's own
        { "levels.zoom.value", 0.6 },
        // How big the custom font's letters are next to GD's own
        { "font.size", 1.0 },
    };

    std::map<std::string_view, std::string> const kStrings = {
        { "labels.custom.text", "GrassyHack" },
        { "jumpscare.image", "" },
        // The player's own Groq key, only ever sent to Groq
        { "chat.key", "" },
        { "chat.model", "openai/gpt-oss-20b" },
        { "chat.ai.image", "" },
        // A .ttf or .otf file
        { "font.file", "" },
    };

    // Hacks read their options every frame (some every tick), so values are
    // kept here instead of going through Geode's save container each time
    std::map<std::string, bool, std::less<>> s_bools;
    std::map<std::string, int64_t, std::less<>> s_ints;
    std::map<std::string, double, std::less<>> s_floats;
    std::map<std::string, std::string, std::less<>> s_strings;

    template <class T>
    T& lookup(std::map<std::string, T, std::less<>>& cache, std::map<std::string_view, T> const& defaults,
            std::string_view key) {
        if (auto it = cache.find(key); it != cache.end()) return it->second;
        T value{};
        if (auto it = defaults.find(key); it != defaults.end()) value = it->second;
        else log::error("Option {} has no default", key);
        auto mod = Mod::get();
        if (mod->hasSavedValue(key)) value = mod->getSavedValue<T>(key, value);
        return cache.emplace(std::string(key), value).first->second;
    }

    template <class T>
    void store(std::map<std::string, T, std::less<>>& cache, std::map<std::string_view, T> const& defaults,
            std::string_view key, T value) {
        lookup(cache, defaults, key) = value;
        Mod::get()->setSavedValue<T>(key, value);
    }
}

namespace grassy::config {
    bool getBool(std::string_view key) { return lookup(s_bools, kBools, key); }
    void setBool(std::string_view key, bool value) { store(s_bools, kBools, key, value); }
    int64_t getInt(std::string_view key) { return lookup(s_ints, kInts, key); }
    void setInt(std::string_view key, int64_t value) { store(s_ints, kInts, key, value); }
    double getFloat(std::string_view key) { return lookup(s_floats, kFloats, key); }
    void setFloat(std::string_view key, double value) { store(s_floats, kFloats, key, value); }
    std::string const& getString(std::string_view key) { return lookup(s_strings, kStrings, key); }
    void setString(std::string_view key, std::string value) { store(s_strings, kStrings, key, std::move(value)); }

    enumKeyCodes getKey(std::string_view key) {
        return static_cast<enumKeyCodes>(getInt(key));
    }

    void setKey(std::string_view key, enumKeyCodes value) {
        setInt(key, static_cast<int64_t>(value));
    }

    void save() {
        if (auto result = Mod::get()->saveData(); result.isErr()) {
            log::warn("Couldn't save options: {}", result.unwrapErr());
        }
    }
}
