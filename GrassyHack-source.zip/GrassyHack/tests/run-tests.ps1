# Builds and runs the planner test (no Geometry Dash needed).
$ErrorActionPreference = "Stop"

$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
$vs = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
Import-Module "$vs\Common7\Tools\Microsoft.VisualStudio.DevShell.dll"
Enter-VsDevShell -VsInstallPath $vs -SkipAutomaticLocation -DevCmdArguments "-arch=x64 -host_arch=x64" | Out-Null

$outDir = Join-Path $env:LOCALAPPDATA "grassyhack-build\tests"
New-Item -ItemType Directory -Force $outDir | Out-Null
$exe = Join-Path $outDir "PlannerTest.exe"

cl /nologo /std:c++20 /O2 /EHsc /W4 /D_CRT_SECURE_NO_WARNINGS"/Fo$outDir\\" "/Fe$exe" (Join-Path $PSScriptRoot "PlannerTest.cpp") (Join-Path $PSScriptRoot "..\src\bot\Planner.cpp")
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $exe
exit $LASTEXITCODE
