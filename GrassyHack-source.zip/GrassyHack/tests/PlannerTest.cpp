// Runs the planner against a tiny fake level so the search can be checked
// without Geometry Dash. Build and run with tests\run-tests.ps1.
#include "../src/bot/Planner.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <unordered_map>

using gdbot::Planner;
using gdbot::PlannerConfig;

namespace {
    constexpr double kEnd = 5400.0;
    constexpr double kShipStart = 1500.0;
    constexpr double kShipEnd = 2500.0;

    // Kills while x is in [from, to] and y is in [bottom, top)
    struct Spike { double from, to, bottom, top; };
    struct Pit { double from, to; };
    // Can be landed on from above
    struct Platform { double from, to, height; };

    const Spike kSpikes[] = {
        { 200, 210, 0, 10 }, { 330, 345, 0, 10 }, { 460, 470, 0, 10 }, { 520, 530, 0, 10 },
        { 700, 715, 0, 12 }, { 900, 905, 0, 8 }, { 960, 970, 0, 10 },
        // A trap: the floor route ends in a pit too wide to jump, and hanging
        // spikes stop you from jumping up to the platform late. You have to jump
        // onto it early (about 0.8 s before the floor route dies), then jump the
        // spike that sits on it.
        { 1150, 1420, 10, 20 }, { 1250, 1260, 20, 30 },
        { 2700, 2710, 0, 10 }, { 2900, 2915, 0, 10 }, { 3000, 3010, 0, 10 },
        // The same trap again, but the floor route dies almost 2 s after the
        // last chance to get on the platform, and the platform has two spikes
        { 3150, 3700, 10, 20 }, { 3300, 3310, 20, 30 }, { 3450, 3462, 20, 30 },
        { 3800, 3812, 0, 10 },
    };
    // A dash orb before a pit too wide to jump: you have to hold through the
    // dash until past the pit, a quick tap only dashes a tick or two
    constexpr double kOrbFrom = 3850.0;
    constexpr double kOrbTo = 3870.0;
    constexpr double kOrbTop = 20.0;
    const Pit kPits[] = { { 600, 630 }, { 1300, 1420 }, { 2800, 2830 }, { 3560, 3700 }, { 3880, 3970 } };
    const Platform kPlatforms[] = { { 1150, 1460, 20 }, { 3150, 3720, 20 } };

    // Ship part like GD's: a floor and ceiling the ship can slide along, and
    // pillars to fly over or under. A quick tap barely lifts the ship off the
    // floor, so getting over a pillar takes holding for a while.
    constexpr double kShipCeiling = 120.0;
    const Spike kPillars[] = {
        { 1600, 1620, 0, 50 }, { 1750, 1770, 70, 120 }, { 1900, 1920, 0, 60 }, { 2050, 2070, 60, 120 },
    };
    // Then a narrow tunnel that weaves up and down, so the ship has to keep
    // switching between holding and letting go
    constexpr double kTunnelStart = 2150.0;
    constexpr double kTunnelEnd = 2450.0;
    constexpr double kTunnelHalfHeight = 18.0;
    double tunnelCenter(double x) {
        return 60 + 30 * std::sin((x - kTunnelStart) / 50.0);
    }

    // Swing part like GD's: every press flips gravity. Like Swing Swing at 3%:
    // after going over a block, staying high gets furthest, but a saw with
    // spikes above it closes that route. The way through is a narrow gap
    // under the saw, and diving for it too fast dies earlier on the spiked floor.
    constexpr double kSwingStart = 4000.0;
    constexpr double kSwingCeiling = 120.0;
    const Spike kSwingSpikes[] = {
        { 4150, 4210, 0, 75 },
        { 4220, 5400, 0, 8 },
        { 4360, 4440, 88, 121 },
        { 4410, 4440, 42, 88 },
        { 4400, 4450, 0, 22 },
        { 4450, 4520, 60, 121 },
        { 4600, 4620, 0, 30 },
        // Like 42%: past a saw, the open space above it ends in a wall. The
        // way on is the narrow lane below it, so the choice comes long before
        // the wall, and missing the lane dies far behind the attempts that
        // went over.
        { 4800, 4830, 50, 80 },
        { 4840, 4930, 45, 60 },
        { 4930, 4960, 30, 121 },
    };

    struct Sim {
        double x = 0, y = 0, vy = 0;
        bool dead = false;
        bool dashing = false, orbUsed = false;
        bool wasHeld = false;
        // Swing gravity: -1 pulls down, 1 pulls up
        int gravity = -1;

        // In GD terms, a mode where holding matters (ship, wave), not just pressing
        bool inShip() const {
            return x >= kShipStart && x < kShipEnd;
        }

        bool inSwing() const {
            return x >= kSwingStart;
        }

        bool touchingOrb() const {
            return !orbUsed && x >= kOrbFrom && x <= kOrbTo && y < kOrbTop;
        }

        // Like GD's ship and wave, and dash orbs: how long jump is held matters
        bool holdMode() const {
            return inShip() || dashing || touchingOrb();
        }

        // In the air, a press only counts if it's still held on landing or at the orb
        bool pressDoesNothing() const {
            return !inShip() && !inSwing() && !dashing && !touchingOrb() && !standing();
        }

        static bool hasGround(double x) {
            for (auto& pit : kPits) if (x >= pit.from && x <= pit.to) return false;
            return true;
        }

        bool standing() const {
            if (y == 0 && hasGround(x)) return true;
            for (auto& platform : kPlatforms) {
                if (y == platform.height && x >= platform.from && x <= platform.to) return true;
            }
            return false;
        }

        void step(bool held) {
            bool pressed = held && !wasHeld;
            wasHeld = held;
            x += 1.0;
            if (inSwing()) {
                dashing = false;
                if (pressed) gravity = -gravity;
                vy = std::clamp(vy + gravity * 0.05, -1.2, 1.2);
                y += vy;
                if (y <= 0) { y = 0; vy = 0; }
                if (y >= kSwingCeiling) { y = kSwingCeiling; vy = 0; }
                for (auto& spike : kSwingSpikes) {
                    if (x >= spike.from && x <= spike.to && y >= spike.bottom && y < spike.top) dead = true;
                }
                return;
            }
            if (inShip()) {
                // Speed keeps changing smoothly like GD's ship, so two attempts
                // that flew differently almost never end up in exactly the same state
                vy = vy * 0.98 + (held ? 0.06 : -0.06);
                y += vy;
                if (y <= 0) { y = 0; vy = 0; }
                if (y >= kShipCeiling) { y = kShipCeiling; vy = 0; }
                for (auto& pillar : kPillars) {
                    if (x >= pillar.from && x <= pillar.to && y >= pillar.bottom && y < pillar.top) dead = true;
                }
                if (x >= kTunnelStart && x <= kTunnelEnd && std::abs(y - tunnelCenter(x)) > kTunnelHalfHeight) dead = true;
                return;
            }
            if (dashing && !held) dashing = false;
            if (touchingOrb() && held) {
                dashing = true;
                orbUsed = true;
            }
            if (dashing) {
                vy = 0;
                for (auto& spike : kSpikes) {
                    if (x >= spike.from && x <= spike.to && y >= spike.bottom && y < spike.top) dead = true;
                }
                return;
            }
            if (standing() && held) vy = 2.0;
            double prevY = y;
            vy -= 0.08;
            y += vy;
            for (auto& platform : kPlatforms) {
                if (x >= platform.from && x <= platform.to && prevY >= platform.height && y <= platform.height) {
                    y = platform.height;
                    vy = 0;
                }
            }
            if (y <= 0 && prevY >= 0 && hasGround(x)) { y = 0; vy = 0; }
            if (y < -30) dead = true;
            for (auto& spike : kSpikes) {
                if (x >= spike.from && x <= spike.to && y >= spike.bottom && y < spike.top) dead = true;
            }
        }

        uint64_t state() const {
            uint64_t hash = 1469598103934665603ull;
            for (double value : { x, y, vy }) {
                uint64_t bits;
                std::memcpy(&bits, &value, sizeof bits);
                hash = (hash ^ bits) * 1099511628211ull;
            }
            if (inSwing()) hash = (hash ^ (gravity + 2 + wasHeld * 4)) * 1099511628211ull;
            return hash * 4 + dashing * 2 + orbUsed;
        }
    };

    // The 30x30 cell the player died in, like the bot uses GD's level blocks
    uint64_t deathPlace(Sim const& sim) {
        auto x = static_cast<int64_t>(std::floor(sim.x / 30.0));
        auto y = static_cast<int64_t>(std::floor(sim.y / 30.0));
        return (static_cast<uint64_t>(x) << 32) ^ static_cast<uint32_t>(y);
    }

    struct Result { bool solved; int attempts; int bestTick; };
    // Every tick simulated across all attempts, the real cost of a search
    long long s_ticksSimulated = 0;

    Result search(PlannerConfig const& config, Planner& planner, int maxAttempts, bool checkStates) {
        planner.reset(config);
        std::unordered_map<int, std::pair<int, Sim>> snapshots;
        int attempts = 0;
        while (attempts < maxAttempts && planner.beginAttempt()) {
            attempts++;
            Sim sim;
            int tick = 0;
            if (planner.startSnapshot() >= 0) {
                auto& [snapTick, snapSim] = snapshots.at(planner.startSnapshot());
                if (snapTick != planner.startTick()) {
                    std::printf("FAIL: snapshot tick mismatch %d vs %d\n", snapTick, planner.startTick());
                    return { false, attempts, planner.bestTick() };
                }
                sim = snapSim;
                tick = snapTick;
            }
            // Like GD, which runs a few updates without physics after every respawn
            int stalledUpdates = 3;
            while (true) {
                planner.noteMode(tick, sim.holdMode(), sim.pressDoesNothing());
                if (planner.wantSnapshot(tick, sim.inShip())) {
                    std::vector<int> evicted;
                    int id = planner.addSnapshot(tick, evicted);
                    snapshots[id] = { tick, sim };
                    for (int gone : evicted) snapshots.erase(gone);
                }
                if (checkStates && planner.wantStateCheck(tick) && planner.isDuplicate(tick, sim.state())) {
                    planner.reportDuplicate();
                    break;
                }
                if (stalledUpdates > 0) {
                    stalledUpdates--;
                    continue;
                }
                sim.step(planner.held(tick));
                tick++;
                s_ticksSimulated++;
                if (sim.dead) {
                    static int traced = 0;
                    if (getenv("TRACE_SHIP") && sim.x >= 1550 && traced++ < 60) {
                        std::printf("  attempt %d: plan %zu blocks, tail %s, start %d, died at x %.0f y %.1f\n",
                            attempts, planner.plan().size(), planner.tail() ? "held" : "released",
                            planner.startTick(), sim.x, sim.y);
                    }
                    planner.reportDeath(tick, deathPlace(sim));
                    break;
                }
                if (sim.x >= kEnd) return { true, attempts, tick };
            }
        }
        return { false, attempts, planner.bestTick() };
    }

    // Plays the plan from the very start with no snapshots, like a real run
    bool replay(Planner const& planner, bool trace = false) {
        Sim sim;
        for (int tick = 0; !sim.dead; tick++) {
            bool held = planner.held(tick);
            bool inTrap = (sim.x >= 1050 && sim.x <= 1500) || (sim.x >= 3050 && sim.x <= 3750);
            if (trace && inTrap && (held || static_cast<int>(sim.x) % 50 == 0)) {
                std::printf("    x %.0f y %.1f%s\n", sim.x, sim.y, held ? " jump held" : "");
            }
            sim.step(held);
            if (sim.x >= kEnd) return true;
        }
        std::printf("  replay died at x=%.0f\n", sim.x);
        return false;
    }
}

int main() {
    int failures = 0;
    struct Case { int perBlock; int spacing; int window; size_t maxSnapshots; bool checkStates; int replayInterval = 60; };
    // Without the duplicate check the search gets stuck at the first trap,
    // which is what happened in GD before
    const Case cases[] = {
        { 1, 1, 120, 400, true }, { 2, 1, 180, 400, true }, { 4, 1, 180, 400, true }, { 2, 1, 180, 20, true },
        // What the bot uses: any tick, normal flips every other tick
        { 1, 2, 180, 400, true },
        // Dense snapshots before each attempt's own flip, as on busy levels
        { 1, 2, 180, 400, true, 8 },
    };
    for (auto& c : cases) {
        PlannerConfig config;
        config.ticksPerBlock = c.perBlock;
        config.flipSpacing = c.spacing;
        config.windowTicks = c.window;
        config.maxSnapshots = c.maxSnapshots;
        config.replaySnapshotInterval = c.replayInterval;
        if (getenv("CROWD")) config.crowdDeaths = atoi(getenv("CROWD"));
        Planner planner;
        s_ticksSimulated = 0;
        auto result = search(config, planner, 50000, c.checkStates);
        bool replayed = result.solved && replay(planner);
        std::printf("precision %d, spacing %d, window %d, snapshots %zu (gap before flips %d), duplicate check %s: %s after %d attempts, "
            "%.0f s of game time at 240 ticks/s (best x %d), replay %s\n",
            c.perBlock, c.spacing, c.window, c.maxSnapshots, c.replayInterval, c.checkStates ? "on" : "off",
            result.solved ? "solved" : "NOT solved", result.attempts, s_ticksSimulated / 240.0,
            result.bestTick, replayed ? "ok" : "FAILED");
        if (!replayed) failures++;
    }
    if (getenv("TUNE")) {
        for (int perBlock : { 1, 2 }) {
            for (int cost : { 0, 8, 16, 24, 48 }) {
                PlannerConfig config;
                config.ticksPerBlock = perBlock;
                config.windowTicks = perBlock == 1 ? 120 : 180;
                config.flipCostTicks = cost;
                Planner planner;
                s_ticksSimulated = 0;
                auto result = search(config, planner, 50000, true);
                std::printf("  tune: precision %d, flip cost %d: %s, %d attempts, %.0f s of game time\n",
                    perBlock, cost, result.solved ? "solved" : "NOT solved", result.attempts, s_ticksSimulated / 240.0);
            }
        }
    }
    if (getenv("TRACE")) {
        PlannerConfig config;
        Planner planner;
        search(config, planner, 50000, true);
        replay(planner, true);
    }
    std::printf(failures ? "%d case(s) failed\n" : "all passed\n", failures);
    return failures ? 1 : 0;
}
