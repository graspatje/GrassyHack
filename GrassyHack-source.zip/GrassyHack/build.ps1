# Builds the mod with the Visual Studio toolchain. Usage: .\build.ps1 [-Install]
# -Install also copies the built .geode into your Geometry Dash mods folder.
param([switch]$Install)
$ErrorActionPreference = "Stop"

$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
$vs = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
Import-Module "$vs\Common7\Tools\Microsoft.VisualStudio.DevShell.dll"
Enter-VsDevShell -VsInstallPath $vs -SkipAutomaticLocation -DevCmdArguments "-arch=x64 -host_arch=x64" | Out-Null

$env:Path = [Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [Environment]::GetEnvironmentVariable("Path","User") + ";" + $env:Path
if (-not $env:GEODE_SDK) { $env:GEODE_SDK = [Environment]::GetEnvironmentVariable("GEODE_SDK","User") }

# MSVC can't handle object paths over ~250 chars, so build in a short folder
$buildDir = Join-Path $env:LOCALAPPDATA "grassyhack-build"
$dontInstall = if ($Install) { "OFF" } else { "ON" }

# Reuse libraries the Practice Tools build already downloaded instead of downloading them again
$extra = @()
$sharedBuild = Join-Path $env:LOCALAPPDATA "practice-tools-build"
$sharedDeps = Join-Path $sharedBuild "_deps"
if (Test-Path $sharedDeps) {
    Get-ChildItem $sharedDeps -Directory -Filter "*-src" | ForEach-Object {
        $name = $_.Name -replace "-src$", ""
        $extra += "-DCPM_${name}_SOURCE=$($_.FullName -replace '\\', '/')"
    }
    # The code generator has to match those bindings, so use the one built alongside them
    $sharedCodegen = Join-Path $sharedBuild "bindings\codegen\Codegen.exe"
    if (Test-Path $sharedCodegen) {
        $codegenDir = Join-Path $buildDir "bindings\codegen"
        New-Item -ItemType Directory -Force $codegenDir | Out-Null
        Copy-Item $sharedCodegen $codegenDir -Force
        $extra += "-DSKIP_BUILDING_CODEGEN=ON"
    }
}

cmake -S $PSScriptRoot -B $buildDir -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DGEODE_DONT_INSTALL_MODS=$dontInstall @extra
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
cmake --build $buildDir
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

New-Item -ItemType Directory -Force (Join-Path $PSScriptRoot "out") | Out-Null
Copy-Item (Join-Path $buildDir "*.geode") (Join-Path $PSScriptRoot "out") -Force
